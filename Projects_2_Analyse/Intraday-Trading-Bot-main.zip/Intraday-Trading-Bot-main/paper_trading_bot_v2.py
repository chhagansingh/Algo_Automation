#!/usr/bin/env python3
"""
PAPER TRADING BOT v2 - Live Simulation
========================================
Uses the Multi-Signal Mean-Reversion Hybrid Strategy v2.
NO REAL MONEY - simulates trades with real-time Yahoo Finance data.

Signals: BB Bounce, RSI Reversal, VWAP+EMA Confluence
Stops: ATR-based dynamic SL/TP with trailing stops

Usage: python3 paper_trading_bot_v2.py
Press Ctrl+C to stop and see final summary.
"""

import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
from datetime import datetime, timedelta
import time
import json
import os

# Import strategy functions from backtest engine
from strategy_v2 import (
    add_indicators_v2,
    check_time_filter,
    check_bb_bounce_signal,
    check_rsi_reversal_signal,
    check_vwap_ema_confluence_signal,
    calculate_atr_stops,
)


class PaperTradingBotV2:
    def __init__(self, config_file='strategy_config.json'):
        with open(config_file, 'r') as f:
            self.config = json.load(f)

        self.capital = self.config['initial_capital']
        self.initial_capital = self.capital
        self.tickers = self.config['tickers']
        self.scan_interval = 60  # seconds between scans

        # Position tracking: {ticker: position_data}
        self.positions = {}
        self.trades = []
        self.daily_pnl = 0
        self.daily_trade_counts = {}  # {date_str: count}
        self.cooldowns = {}  # {ticker: last_exit_time}

        # Statistics
        self.total_trades = 0
        self.winning_trades = 0
        self.losing_trades = 0

        # Data cache to avoid excessive API calls
        self.data_cache = {}
        self.last_fetch_time = {}

        print("=" * 70)
        print("  PAPER TRADING BOT v2 - Multi-Signal Mean-Reversion")
        print("=" * 70)
        print(f"  Capital: Rs {self.capital:,.2f}")
        print(f"  Stocks:  {len(self.tickers)} ({', '.join(t.replace('.NS','') for t in self.tickers)})")
        print(f"  Signals: BB Bounce + RSI Reversal + VWAP+EMA Confluence")
        print(f"  Stops:   SL={self.config['exits']['atr_multiplier_sl']}x ATR, "
              f"TP={self.config['exits']['atr_multiplier_tp']}x ATR")
        print(f"  Entry Window: {self.config['time_filter']['start_hour']}:{self.config['time_filter']['start_minute']:02d} - "
              f"{self.config['time_filter']['end_hour']}:{self.config['time_filter']['end_minute']:02d} IST")
        print(f"  Max Trades/Day: {self.config['risk_management']['max_trades_per_day']}")
        print("  NOTE: This is PAPER TRADING - no real money!")
        print("=" * 70)

    def get_market_data(self, ticker):
        """Download recent 1H data for a ticker with caching."""
        now = datetime.now()

        # Cache for 55 seconds to avoid hammering yfinance
        if ticker in self.last_fetch_time:
            elapsed = (now - self.last_fetch_time[ticker]).total_seconds()
            if elapsed < 55 and ticker in self.data_cache:
                return self.data_cache[ticker]

        try:
            end_date = now + timedelta(days=1)  # yfinance 'end' is exclusive
            start_date = now - timedelta(days=60)

            df = yf.download(
                ticker,
                start=start_date.strftime('%Y-%m-%d'),
                end=end_date.strftime('%Y-%m-%d'),
                interval='1h',
                progress=False
            )

            if df.empty:
                return None

            if df.index.tz is not None:
                df.index = df.index.tz_localize(None)

            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [str(col[0]).capitalize() for col in df.columns]
            else:
                df.columns = [str(col).capitalize() for col in df.columns]

            if 'Adj close' in df.columns:
                df.rename(columns={'Adj close': 'Close'}, inplace=True)

            desired = ['Open', 'High', 'Low', 'Close', 'Volume']
            df = df[[c for c in desired if c in df.columns]]

            # Add indicators
            df = add_indicators_v2(df, self.config)
            if df is None or df.empty:
                return None

            self.data_cache[ticker] = df
            self.last_fetch_time[ticker] = now
            return df

        except Exception as e:
            print(f"  [ERROR] {ticker}: {str(e)}")
            return None

    def is_market_open(self):
        """Check if Indian market is currently open (9:15-15:30 IST)."""
        ist_now = datetime.now(tz=__import__('datetime').timezone.utc) + timedelta(hours=5, minutes=30)
        market_start = ist_now.replace(hour=9, minute=15, second=0)
        market_end = ist_now.replace(hour=15, minute=30, second=0)

        if ist_now.weekday() >= 5:  # Saturday/Sunday
            return False

        return market_start <= ist_now <= market_end

    def get_ist_now(self):
        """Get current time in IST."""
        return datetime.now(tz=__import__('datetime').timezone.utc).replace(tzinfo=None) + timedelta(hours=5, minutes=30)

    def check_signals(self, df, ticker):
        """Check all entry signals on the latest candle."""
        if df is None or len(df) < 3:
            return None, None

        i = len(df) - 1
        current = df.iloc[i]
        prev = df.iloc[i - 1]

        # Time filter check (uses the candle timestamp)
        candle_time = current.name
        if not check_time_filter(candle_time, self.config):
            return None, None

        # Daily trade limit
        today_str = self.get_ist_now().strftime('%Y-%m-%d')
        day_count = self.daily_trade_counts.get(today_str, 0)
        if day_count >= self.config['risk_management']['max_trades_per_day']:
            return None, None

        # Cooldown check
        if ticker in self.cooldowns:
            elapsed = (datetime.now() - self.cooldowns[ticker]).total_seconds()
            min_gap_seconds = self.config['risk_management']['min_candles_between_entries'] * 3600
            if elapsed < min_gap_seconds:
                return None, None

        # ATR check
        atr = current['ATR']
        if pd.isna(atr) or atr <= 0:
            return None, None

        # Check signals in priority order: BB bounce > RSI reversal > VWAP+EMA
        sig_type, direction = check_bb_bounce_signal(current, prev, df, i, self.config)

        if not sig_type:
            sig_type, direction = check_rsi_reversal_signal(current, prev, df, i, self.config)

        if not sig_type:
            sig_type, direction = check_vwap_ema_confluence_signal(current, prev, df, i, self.config)

        return sig_type, direction

    def open_position(self, ticker, signal_type, direction, df):
        """Open a paper trading position."""
        if len(self.positions) >= self.config['risk_management']['max_concurrent_positions']:
            return False

        current = df.iloc[-1]
        entry_price = current['Close']
        atr = current['ATR']

        if pd.isna(atr) or atr <= 0:
            return False

        # Position sizing (risk-based)
        risk_pct = self.config['risk_management']['risk_per_trade_pct']
        max_pos_pct = self.config['risk_management']['max_position_pct']
        sl_dist = max(atr * self.config['exits']['atr_multiplier_sl'],
                      entry_price * self.config['exits']['min_stop_pct'])
        shares = (self.capital * risk_pct) / sl_dist
        max_shares = (self.capital * max_pos_pct) / entry_price
        shares = min(shares, max_shares)

        if shares <= 0:
            return False

        # Calculate stops
        stop_loss, take_profit = calculate_atr_stops(entry_price, atr, direction, self.config)

        self.positions[ticker] = {
            'signal_type': signal_type,
            'direction': direction,
            'entry_price': entry_price,
            'entry_time': datetime.now(),
            'shares': shares,
            'atr_at_entry': atr,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'trailing_active': False,
            'trailing_stop': 0,
            'best_price': entry_price,
        }

        # Update daily trade count
        today_str = self.get_ist_now().strftime('%Y-%m-%d')
        self.daily_trade_counts[today_str] = self.daily_trade_counts.get(today_str, 0) + 1

        tp_dist = abs(take_profit - entry_price)
        sl_dist_actual = abs(stop_loss - entry_price)

        print(f"\n  >>> OPENED {direction.upper()} on {ticker.replace('.NS','')} [{signal_type}]")
        print(f"      Entry: Rs {entry_price:.2f} | Shares: {shares:.1f}")
        print(f"      SL: Rs {stop_loss:.2f} (-{sl_dist_actual:.2f}) | TP: Rs {take_profit:.2f} (+{tp_dist:.2f})")
        print(f"      ATR: {atr:.2f}")

        return True

    def manage_position(self, ticker, df):
        """Check exits and update trailing stop for an open position."""
        pos = self.positions[ticker]
        current = df.iloc[-1]
        price = current['Close']
        high = current['High']
        low = current['Low']
        entry_price = pos['entry_price']
        entry_atr = pos['atr_at_entry']
        exits_cfg = self.config['exits']

        # Update trailing stop
        if pos['direction'] == 'long':
            if price > pos['best_price']:
                pos['best_price'] = price
            profit_atr = (price - entry_price) / entry_atr if entry_atr > 0 else 0
            if profit_atr >= exits_cfg['trailing_activation_atr'] and not pos['trailing_active']:
                pos['trailing_active'] = True
                pos['trailing_stop'] = entry_price + entry_atr * exits_cfg['trailing_distance_atr']
            if pos['trailing_active']:
                new_trail = pos['best_price'] - entry_atr * exits_cfg['trailing_distance_atr']
                pos['trailing_stop'] = max(pos['trailing_stop'], new_trail)
        else:
            if price < pos['best_price']:
                pos['best_price'] = price
            profit_atr = (entry_price - price) / entry_atr if entry_atr > 0 else 0
            if profit_atr >= exits_cfg['trailing_activation_atr'] and not pos['trailing_active']:
                pos['trailing_active'] = True
                pos['trailing_stop'] = entry_price - entry_atr * exits_cfg['trailing_distance_atr']
            if pos['trailing_active']:
                new_trail = pos['best_price'] + entry_atr * exits_cfg['trailing_distance_atr']
                pos['trailing_stop'] = min(pos['trailing_stop'], new_trail)

        # Check exit conditions
        exit_price = None
        exit_reason = None

        if pos['direction'] == 'long':
            if low <= pos['stop_loss']:
                exit_price, exit_reason = pos['stop_loss'], 'Stop Loss'
            elif high >= pos['take_profit']:
                exit_price, exit_reason = pos['take_profit'], 'Take Profit'
            elif pos['trailing_active'] and low <= pos['trailing_stop']:
                exit_price, exit_reason = pos['trailing_stop'], 'Trailing Stop'
        else:
            if high >= pos['stop_loss']:
                exit_price, exit_reason = pos['stop_loss'], 'Stop Loss'
            elif low <= pos['take_profit']:
                exit_price, exit_reason = pos['take_profit'], 'Take Profit'
            elif pos['trailing_active'] and high >= pos['trailing_stop']:
                exit_price, exit_reason = pos['trailing_stop'], 'Trailing Stop'

        # Time stop check (IST)
        if not exit_reason:
            ist_now = self.get_ist_now()
            ts_hour = exits_cfg['time_stop_hour']
            ts_min = exits_cfg['time_stop_minute']
            if ist_now.hour > ts_hour or (ist_now.hour == ts_hour and ist_now.minute >= ts_min):
                exit_price, exit_reason = price, 'Time Stop'

        if exit_reason:
            self.close_position(ticker, exit_reason, exit_price)
            return True

        # Show unrealized P&L
        if pos['direction'] == 'long':
            unrealized = pos['shares'] * (price - entry_price)
        else:
            unrealized = pos['shares'] * (entry_price - price)

        pnl_pct = (unrealized / (pos['shares'] * entry_price)) * 100
        marker = "+" if unrealized >= 0 else ""
        trail_info = f" | Trail: Rs {pos['trailing_stop']:.2f}" if pos['trailing_active'] else ""
        print(f"      {ticker.replace('.NS','')}: {pos['direction'].upper()} @ Rs {entry_price:.2f} | "
              f"Now: Rs {price:.2f} | PnL: {marker}Rs {unrealized:.2f} ({marker}{pnl_pct:.2f}%){trail_info}")

        return False

    def close_position(self, ticker, exit_reason, exit_price):
        """Close a paper trading position and record the trade."""
        pos = self.positions[ticker]
        entry_price = pos['entry_price']
        shares = pos['shares']
        brokerage_pct = self.config['risk_management']['brokerage_pct']

        if pos['direction'] == 'long':
            pnl = shares * (exit_price - entry_price)
        else:
            pnl = shares * (entry_price - exit_price)

        brokerage = shares * exit_price * brokerage_pct
        net_pnl = pnl - brokerage
        pnl_pct = (net_pnl / (shares * entry_price)) * 100

        self.capital += net_pnl
        self.daily_pnl += net_pnl
        self.total_trades += 1
        if net_pnl > 0:
            self.winning_trades += 1
        else:
            self.losing_trades += 1

        trade_record = {
            'ticker': ticker,
            'signal_type': pos['signal_type'],
            'direction': pos['direction'],
            'entry_time': pos['entry_time'].strftime('%Y-%m-%d %H:%M:%S'),
            'exit_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'entry_price': round(entry_price, 2),
            'exit_price': round(exit_price, 2),
            'shares': round(shares, 2),
            'atr_at_entry': round(pos['atr_at_entry'], 2),
            'net_pnl': round(net_pnl, 2),
            'pnl_pct': round(pnl_pct, 2),
            'exit_reason': exit_reason,
            'capital': round(self.capital, 2),
        }
        self.trades.append(trade_record)

        self.cooldowns[ticker] = datetime.now()

        marker = "WIN" if net_pnl > 0 else "LOSS"
        sign = "+" if net_pnl >= 0 else ""
        print(f"\n  <<< CLOSED {pos['direction'].upper()} on {ticker.replace('.NS','')} [{exit_reason}] [{marker}]")
        print(f"      Entry: Rs {entry_price:.2f} -> Exit: Rs {exit_price:.2f}")
        print(f"      PnL: {sign}Rs {net_pnl:.2f} ({sign}{pnl_pct:.2f}%) | Capital: Rs {self.capital:.2f}")

        del self.positions[ticker]

    def print_status(self):
        """Print summary status."""
        ist_now = self.get_ist_now()
        print(f"\n{'─' * 70}")
        print(f"  STATUS | {ist_now.strftime('%Y-%m-%d %H:%M IST')} | "
              f"Capital: Rs {self.capital:,.2f} | "
              f"Daily PnL: {'+'if self.daily_pnl>=0 else ''}Rs {self.daily_pnl:.2f}")

        if self.total_trades > 0:
            wr = (self.winning_trades / self.total_trades) * 100
            print(f"  Trades: {self.total_trades} (W:{self.winning_trades} L:{self.losing_trades}) | "
                  f"Win Rate: {wr:.1f}% | Positions: {len(self.positions)}")

        today_str = ist_now.strftime('%Y-%m-%d')
        day_trades = self.daily_trade_counts.get(today_str, 0)
        print(f"  Today's trades: {day_trades}/{self.config['risk_management']['max_trades_per_day']}")
        print(f"{'─' * 70}")

    def run(self):
        """Main trading loop."""
        print(f"\n  Starting paper trading loop... (Ctrl+C to stop)\n")

        scan_count = 0

        try:
            while True:
                scan_count += 1
                ist_now = self.get_ist_now()

                # Reset daily PnL at start of new day
                today_str = ist_now.strftime('%Y-%m-%d')
                if scan_count == 1 or ist_now.hour == 9 and ist_now.minute < 16:
                    self.daily_pnl = 0

                if not self.is_market_open():
                    print(f"  [{ist_now.strftime('%H:%M IST')}] Market closed. Waiting...")
                    time.sleep(60)
                    continue

                print(f"\n  Scan #{scan_count} [{ist_now.strftime('%H:%M:%S IST')}]")

                for ticker in self.tickers:
                    try:
                        df = self.get_market_data(ticker)
                        if df is None or df.empty:
                            continue

                        # Manage existing position
                        if ticker in self.positions:
                            self.manage_position(ticker, df)
                        else:
                            # Check for new entry signals
                            sig_type, direction = self.check_signals(df, ticker)
                            if sig_type and direction:
                                self.open_position(ticker, sig_type, direction, df)

                    except Exception as e:
                        print(f"  [ERROR] {ticker}: {str(e)}")
                        continue

                # Status update every 5 scans
                if scan_count % 5 == 0:
                    self.print_status()

                time.sleep(self.scan_interval)

        except KeyboardInterrupt:
            print(f"\n\n  Stopping bot...")

            # Close all open positions
            if self.positions:
                print(f"  Closing {len(self.positions)} open position(s)...")
                for ticker in list(self.positions.keys()):
                    df = self.get_market_data(ticker)
                    if df is not None and not df.empty:
                        price = df.iloc[-1]['Close']
                        self.close_position(ticker, 'Manual Close', price)

            self.print_final_summary()

    def print_final_summary(self):
        """Print final session summary."""
        print(f"\n{'=' * 70}")
        print(f"  PAPER TRADING SESSION SUMMARY")
        print(f"{'=' * 70}")

        total_return = ((self.capital - self.initial_capital) / self.initial_capital) * 100
        sign = "+" if total_return >= 0 else ""

        print(f"  Starting Capital: Rs {self.initial_capital:,.2f}")
        print(f"  Ending Capital:   Rs {self.capital:,.2f}")
        print(f"  Total Return:     {sign}{total_return:.2f}%")

        if self.total_trades > 0:
            wr = (self.winning_trades / self.total_trades) * 100
            print(f"\n  Total Trades: {self.total_trades}")
            print(f"  Winning:      {self.winning_trades}")
            print(f"  Losing:       {self.losing_trades}")
            print(f"  Win Rate:     {wr:.1f}%")

            wins = [t['net_pnl'] for t in self.trades if t['net_pnl'] > 0]
            losses = [t['net_pnl'] for t in self.trades if t['net_pnl'] < 0]
            if wins:
                print(f"  Avg Win:      Rs {np.mean(wins):.2f}")
            if losses:
                print(f"  Avg Loss:     Rs {np.mean(losses):.2f}")

            # Signal breakdown
            signal_counts = {}
            signal_wins = {}
            for t in self.trades:
                st = t['signal_type']
                signal_counts[st] = signal_counts.get(st, 0) + 1
                if t['net_pnl'] > 0:
                    signal_wins[st] = signal_wins.get(st, 0) + 1

            print(f"\n  Signal Breakdown:")
            for st in signal_counts:
                count = signal_counts[st]
                w = signal_wins.get(st, 0)
                swr = (w / count * 100) if count > 0 else 0
                print(f"    {st}: {count} trades ({swr:.1f}% WR)")

        print(f"{'=' * 70}")

        # Save trades to CSV
        if self.trades:
            df = pd.DataFrame(self.trades)
            filename = f'paper_trades_v2_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
            df.to_csv(filename, index=False)
            print(f"  Trades saved to: {filename}")
        print()


if __name__ == "__main__":
    bot = PaperTradingBotV2()
    bot.run()

import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
from datetime import datetime, timedelta
import time
import json
from zerodha_trader import ZerodhaTrader

class ZerodhaLiveMomentumTrader:
    """
    Automated trading bot using the High-Momentum Pullback strategy from code 7.py
    Integrated with Zerodha Kite Connect API
    """

    def __init__(self, config_file='config.json'):
        """Initialize the trading bot with configuration"""
        with open(config_file, 'r') as f:
            self.config = json.load(f)

        # Initialize Zerodha trader
        zerodha_config = self.config['zerodha']
        self.trader = ZerodhaTrader(
            api_key=zerodha_config['api_key'],
            api_secret=zerodha_config['api_secret']
        )

        # Load access token
        if not self.trader.load_access_token():
            print("❌ No access token found. Please run zerodha_trader.py first to login")
            raise Exception("Access token not found")

        # Trading parameters from code 7.py
        self.capital = self.config['trading'].get('initial_capital', 200)
        self.risk_per_trade_capital_pct = self.config['trading'].get('risk_per_trade_percent', 0.015)
        self.stop_loss_percent = self.config['trading'].get('stop_loss_percent', 0.0075)
        self.take_profit_percent = self.config['trading'].get('take_profit_percent', 0.015)
        self.brokerage_fee_percent = self.config['trading'].get('brokerage_fee_percent', 0.0003)

        # Position tracking
        self.positions = {}  # {ticker: position_data}
        self.daily_pnl = 0
        self.total_trades_today = 0

        # Safety limits
        self.max_daily_loss = self.config['risk_management']['max_daily_loss']
        self.max_positions = self.config['risk_management']['max_positions']

        # Trading state
        self.trading_enabled = False
        self.logged_in = False

    def login(self):
        """Check if logged into Zerodha"""
        print("🔐 Checking Zerodha login...")
        if self.trader.is_logged_in():
            self.logged_in = True
            profile = self.trader.get_profile()
            print(f"✅ Logged in as: {profile['user_name']}")

            # Get available balance
            available_cash = self.trader.get_available_cash()
            print(f"💰 Available Balance: ₹{available_cash:.2f}")

            # Update capital from account balance
            if available_cash > 0:
                self.capital = available_cash
                print(f"📊 Trading Capital set to: ₹{self.capital:.2f}")

            return True
        else:
            print("❌ Not logged in to Zerodha!")
            print("Please run: python zerodha_trader.py")
            return False

    def get_and_prepare_data(self, ticker_symbol, interval_val, start_date_str_val, end_date_str_val):
        """
        Downloads historical data, standardizes columns, and converts index to datetime.
        (Same as code 7.py)
        """
        try:
            df = yf.download(tickers=ticker_symbol, interval=interval_val,
                           start=start_date_str_val, end=end_date_str_val, progress=False)
            if not df.empty and df.index.tz is not None:
                df.index = df.index.tz_localize(None)

            if df.empty:
                return pd.DataFrame()
        except Exception as e:
            print(f"❌ Error downloading data for {ticker_symbol}: {str(e)}")
            return pd.DataFrame()

        new_columns = []
        if isinstance(df.columns, pd.MultiIndex):
            for col in df.columns:
                cleaned_col_name = str(col[0]).capitalize()
                new_columns.append(cleaned_col_name)
        else:
            for col in df.columns:
                new_columns.append(str(col).capitalize())
        df.columns = new_columns

        if 'Adj Close' in df.columns:
            if 'Close' in df.columns and df['Adj Close'].equals(df['Close']):
                df = df.drop(columns=['Adj Close'])
            elif 'Close' not in df.columns:
                df.rename(columns={'Adj Close': 'Close'}, inplace=True)

        df = df.loc[:,~df.columns.duplicated()]

        desired_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        final_columns_present_and_desired = [col for col in desired_columns if col in df.columns]
        df = df[final_columns_present_and_desired]

        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index)
        if df.index.tz is not None:
            df.index = df.index.tz_localize(None)

        if df.empty:
            return pd.DataFrame()

        return df

    def add_indicators(self, df_input):
        """
        Adds RSI, MACD, EMA50 indicators to the DataFrame.
        (Same as code 7.py)
        """
        required_cols = ['Close', 'High', 'Low']
        for col_name in required_cols:
            if col_name not in df_input.columns:
                return df_input
            if df_input[col_name].isnull().all():
                pass

        min_indicator_len = 50
        if len(df_input) < min_indicator_len:
            df_input['RSI'] = np.nan
            df_input['MACD_Line'] = np.nan
            df_input['MACD_Signal'] = np.nan
            df_input['MACD_Hist'] = np.nan
            df_input['EMA50'] = np.nan
            return df_input

        df_input['RSI'] = ta.rsi(df_input['Close'], length=9)

        macd_df = ta.macd(df_input['Close'], fast=8, slow=21, signal=5)

        if macd_df is not None and not macd_df.empty:
            expected_macd_cols = ['MACD_8_21_5', 'MACDs_8_21_5', 'MACDh_8_21_5']
            missing_macd_cols = [col for col in expected_macd_cols if col not in macd_df.columns]

            if missing_macd_cols:
                df_input['MACD_Line'] = np.nan
                df_input['MACD_Signal'] = np.nan
                df_input['MACD_Hist'] = np.nan
            else:
                df_input['MACD_Line'] = macd_df['MACD_8_21_5']
                df_input['MACD_Signal'] = macd_df['MACDs_8_21_5']
                df_input['MACD_Hist'] = macd_df['MACDh_8_21_5']
        else:
            df_input['MACD_Line'] = np.nan
            df_input['MACD_Signal'] = np.nan
            df_input['MACD_Hist'] = np.nan

        df_input['EMA50'] = ta.ema(df_input['Close'], length=50)

        # Add Volume SMA
        if 'Volume' in df_input.columns:
            df_input['Volume_SMA20'] = df_input['Volume'].rolling(window=20).mean()
        else:
            df_input['Volume_SMA20'] = np.nan

        critical_indicator_cols = ['Close', 'RSI', 'MACD_Line', 'MACD_Signal', 'MACD_Hist', 'EMA50']
        df_input = df_input.dropna(subset=[col for col in critical_indicator_cols if col in df_input.columns])

        return df_input

    def is_strong_bullish_candle(self, open_price, high_price, low_price, close_price):
        """
        Checks if a candle is a strong bullish candle.
        (Same as code 7.py)
        """
        if close_price <= open_price:
            return False

        body_size = close_price - open_price
        total_range = high_price - low_price

        if total_range == 0:
            return False

        body_ratio = body_size / total_range

        return body_ratio > 0.55

    def is_strong_bearish_candle(self, open_price, high_price, low_price, close_price):
        """
        Checks if a candle is a strong bearish candle.
        (Same as code 7.py)
        """
        if close_price >= open_price:
            return False

        body_size = open_price - close_price
        total_range = high_price - low_price

        if total_range == 0:
            return False

        body_ratio = body_size / total_range

        return body_ratio > 0.55

    def check_entry_signals(self, df, ticker):
        """
        Check if there's an entry signal based on code 7.py strategy
        Returns: ('long', price) or ('short', price) or (None, None)
        """
        if len(df) < 2:
            return None, None

        current_candle = df.iloc[-1]
        prev_candle = df.iloc[-2]

        required_cols = ['Close', 'Open', 'High', 'Low', 'RSI', 'MACD_Line',
                        'MACD_Signal', 'EMA50', 'Volume', 'Volume_SMA20']

        # Check if all required columns exist and have valid data
        for col in required_cols:
            if col not in df.columns:
                return None, None
            if pd.isna(current_candle[col]) or pd.isna(prev_candle[col]):
                return None, None

        current_close = current_candle['Close']
        current_rsi = current_candle['RSI']
        prev_macd_line = prev_candle['MACD_Line']
        prev_macd_signal = prev_candle['MACD_Signal']
        current_macd_line = current_candle['MACD_Line']
        current_macd_signal = current_candle['MACD_Signal']
        current_ema50 = current_candle['EMA50']

        # MACD crossovers
        macd_buy_crossover = (prev_macd_line < prev_macd_signal and
                             current_macd_line > current_macd_signal)
        macd_sell_crossover = (prev_macd_line > prev_macd_signal and
                              current_macd_line < current_macd_signal)

        # Trend confirmation
        uptrend_confirmed_ema = (current_close > current_ema50 * (1 - 0.0015))
        downtrend_confirmed_ema = (current_close < current_ema50 * (1 + 0.0015))

        # Long Entry (Same as code 7.py)
        if (uptrend_confirmed_ema and
            current_rsi < 60 and
            macd_buy_crossover and
            current_candle['Volume'] > 1.1 * current_candle['Volume_SMA20'] and
            self.is_strong_bullish_candle(current_candle['Open'], current_candle['High'],
                                         current_candle['Low'], current_candle['Close'])):
            return 'long', current_close

        # Short Entry (Same as code 7.py)
        elif (downtrend_confirmed_ema and
              current_rsi > 40 and
              macd_sell_crossover and
              current_candle['Volume'] > 1.1 * current_candle['Volume_SMA20'] and
              self.is_strong_bearish_candle(current_candle['Open'], current_candle['High'],
                                           current_candle['Low'], current_candle['Close'])):
            return 'short', current_close

        return None, None

    def calculate_position_size(self, entry_price):
        """Calculate position size based on risk management"""
        dollar_risk_per_share = entry_price * self.stop_loss_percent

        if dollar_risk_per_share <= 0:
            return 0

        shares_to_trade = (self.capital * self.risk_per_trade_capital_pct) / dollar_risk_per_share
        return int(shares_to_trade)

    def place_entry_order(self, ticker, position_type, entry_price):
        """Place entry order with Zerodha"""
        try:
            # Calculate position size
            quantity = self.calculate_position_size(entry_price)

            if quantity <= 0:
                print(f"❌ Invalid quantity for {ticker}")
                return False

            # Convert ticker format (RELIANCE.NS -> RELIANCE)
            symbol = self.trader.convert_ticker_to_symbol(ticker)

            # Place order
            transaction_type = "BUY" if position_type == 'long' else "SELL"
            order_id = self.trader.place_order(
                symbol=symbol,
                quantity=quantity,
                order_type="MARKET",
                transaction_type=transaction_type,
                product_type="MIS"  # Intraday
            )

            if order_id:
                # Calculate stop loss and take profit levels
                if position_type == 'long':
                    stop_loss = entry_price * (1 - self.stop_loss_percent)
                    take_profit = entry_price * (1 + self.take_profit_percent)
                else:
                    stop_loss = entry_price * (1 + self.stop_loss_percent)
                    take_profit = entry_price * (1 - self.take_profit_percent)

                # Store position
                self.positions[ticker] = {
                    'symbol': symbol,
                    'position_type': position_type,
                    'entry_price': entry_price,
                    'quantity': quantity,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'entry_time': datetime.now(),
                    'order_id': order_id
                }

                self.total_trades_today += 1

                print(f"✅ {position_type.upper()} position opened for {ticker}")
                print(f"   Entry: ₹{entry_price:.2f} | Qty: {quantity} | SL: ₹{stop_loss:.2f} | TP: ₹{take_profit:.2f}")

                return True
            else:
                print(f"❌ Failed to place order for {ticker}")
                return False

        except Exception as e:
            print(f"❌ Error placing entry order for {ticker}: {str(e)}")
            return False

    def check_exit_conditions(self, ticker, current_price):
        """Check if position should be exited"""
        if ticker not in self.positions:
            return False, None

        position = self.positions[ticker]
        position_type = position['position_type']
        stop_loss = position['stop_loss']
        take_profit = position['take_profit']

        exit_reason = None

        if position_type == 'long':
            if current_price <= stop_loss:
                exit_reason = 'SL'
            elif current_price >= take_profit:
                exit_reason = 'TP'
        else:  # short
            if current_price >= stop_loss:
                exit_reason = 'SL'
            elif current_price <= take_profit:
                exit_reason = 'TP'

        if exit_reason:
            return True, exit_reason

        return False, None

    def place_exit_order(self, ticker, exit_reason, exit_price=None):
        """Place exit order and update PnL"""
        try:
            position = self.positions[ticker]
            symbol = position['symbol']

            # Get current price if not provided (using yfinance for free API)
            if exit_price is None:
                try:
                    # Get latest price from yfinance
                    ticker_obj = yf.Ticker(ticker)
                    ticker_data = ticker_obj.history(period='1d', interval='1m')
                    if not ticker_data.empty:
                        exit_price = ticker_data['Close'].iloc[-1]
                    else:
                        print(f"❌ Could not get current price for {ticker}")
                        return False
                except Exception as e:
                    print(f"❌ Error getting price for {ticker}: {str(e)}")
                    return False

            # Place opposite order to close position
            transaction_type = "SELL" if position['position_type'] == 'long' else "BUY"

            order_id = self.trader.place_order(
                symbol=symbol,
                quantity=position['quantity'],
                order_type="MARKET",
                transaction_type=transaction_type,
                product_type="MIS"
            )

            if order_id:
                # Calculate PnL
                entry_price = position['entry_price']
                quantity = position['quantity']

                if position['position_type'] == 'long':
                    pnl = quantity * (exit_price - entry_price)
                else:
                    pnl = quantity * (entry_price - exit_price)

                # Account for brokerage
                trade_value = quantity * exit_price
                brokerage = trade_value * self.brokerage_fee_percent
                net_pnl = pnl - brokerage

                # Update capital and daily PnL
                self.capital += net_pnl
                self.daily_pnl += net_pnl

                print(f"🔔 {position['position_type'].upper()} position closed for {ticker} - {exit_reason}")
                print(f"   Entry: ₹{entry_price:.2f} | Exit: ₹{exit_price:.2f} | PnL: ₹{net_pnl:.2f}")
                print(f"   Current Capital: ₹{self.capital:.2f} | Daily PnL: ₹{self.daily_pnl:.2f}")

                # Remove position
                del self.positions[ticker]

                return True
            else:
                print(f"❌ Failed to place exit order for {ticker}")
                return False

        except Exception as e:
            print(f"❌ Error placing exit order for {ticker}: {str(e)}")
            return False

    def is_market_open(self):
        """Check if market is open (9:15 AM to 3:30 PM IST)"""
        now = datetime.now()

        # Check if it's a weekday
        if now.weekday() >= 5:  # Saturday = 5, Sunday = 6
            return False

        # Check market hours
        market_open = now.replace(hour=9, minute=15, second=0, microsecond=0)
        market_close = now.replace(hour=15, minute=30, second=0, microsecond=0)

        return market_open <= now <= market_close

    def check_safety_limits(self):
        """Check if safety limits are breached"""
        # Check max daily loss
        if self.daily_pnl < -self.max_daily_loss:
            print(f"🛑 Daily loss limit reached: ₹{self.daily_pnl:.2f}")
            return False

        # Check max positions
        if len(self.positions) >= self.max_positions:
            return False

        return True

    def run_trading_loop(self):
        """Main trading loop"""
        if not self.login():
            print("❌ Cannot start trading - login failed")
            return

        # Tickers to trade
        tickers = self.config['trading']['symbols']
        interval = self.config['trading']['interval']

        print("\n🤖 Starting Zerodha Live Momentum Trading Bot")
        print(f"📊 Trading Strategy: High-Momentum Pullback")
        print(f"💰 Initial Capital: ₹{self.capital:.2f}")
        print(f"🛡️  Max Daily Loss: ₹{self.max_daily_loss:.2f}")
        print(f"📈 Max Positions: {self.max_positions}")
        print(f"⏰ Checking every 2 minutes\n")

        self.trading_enabled = True

        while self.trading_enabled:
            try:
                now = datetime.now()

                # Check if market is open
                if not self.is_market_open():
                    print(f"⏰ Market closed. Time: {now.strftime('%H:%M:%S')}")

                    # Close all positions at end of day
                    if self.positions and now.hour >= 15:
                        print("📊 Closing all positions at end of day...")
                        for ticker in list(self.positions.keys()):
                            self.place_exit_order(ticker, 'EOD_Close')

                    # Reset daily counters at start of new day
                    if now.hour < 9:
                        self.daily_pnl = 0
                        self.total_trades_today = 0

                    time.sleep(120)  # Wait 2 minutes
                    continue

                # Check safety limits
                if not self.check_safety_limits():
                    print("🛑 Safety limits breached. Pausing trading...")
                    time.sleep(120)
                    continue

                print(f"\n📊 Market Scan - {now.strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"💰 Capital: ₹{self.capital:.2f} | Daily PnL: ₹{self.daily_pnl:.2f} | Positions: {len(self.positions)}")

                # Get data for all tickers
                end_date = datetime.now()
                start_date = end_date - timedelta(days=self.config['trading']['lookback_days'])

                for ticker in tickers:
                    try:
                        # Get and prepare data
                        df = self.get_and_prepare_data(
                            ticker, interval,
                            start_date.strftime('%Y-%m-%d'),
                            end_date.strftime('%Y-%m-%d')
                        )

                        if df.empty:
                            continue

                        # Add indicators
                        df = self.add_indicators(df)

                        if df.empty or len(df) < 50:
                            continue

                        # Get current price from yfinance (since free API doesn't have live data access)
                        current_price = df.iloc[-1]['Close']

                        # Check if we have a position
                        if ticker in self.positions:
                            # Check exit conditions
                            should_exit, exit_reason = self.check_exit_conditions(ticker, current_price)

                            if should_exit:
                                self.place_exit_order(ticker, exit_reason, current_price)
                        else:
                            # Check entry signals
                            if len(self.positions) < self.max_positions:
                                signal, entry_price = self.check_entry_signals(df, ticker)

                                if signal:
                                    print(f"\n🎯 Signal detected for {ticker}")
                                    self.place_entry_order(ticker, signal, current_price)

                        time.sleep(1)  # Small delay between tickers

                    except Exception as e:
                        print(f"❌ Error processing {ticker}: {str(e)}")
                        continue

                # Wait before next scan
                print(f"\n⏳ Next scan in 2 minutes...")
                time.sleep(120)  # 2 minutes

            except KeyboardInterrupt:
                print("\n🛑 Trading bot stopped by user")
                self.trading_enabled = False

                # Close all open positions
                if self.positions:
                    print("📊 Closing all open positions...")
                    for ticker in list(self.positions.keys()):
                        self.place_exit_order(ticker, 'Manual_Close')

                break

            except Exception as e:
                print(f"❌ Error in trading loop: {str(e)}")
                time.sleep(60)  # Wait 1 minute on error
                continue

        print("\n📊 Trading Session Summary")
        print(f"💰 Final Capital: ₹{self.capital:.2f}")
        print(f"📈 Total PnL: ₹{self.daily_pnl:.2f}")
        print(f"🔄 Total Trades: {self.total_trades_today}")

if __name__ == "__main__":
    print("=" * 60)
    print("Zerodha Live Momentum Trading Bot")
    print("=" * 60)

    # Create and run the trading bot
    try:
        bot = ZerodhaLiveMomentumTrader(config_file='config.json')
        bot.run_trading_loop()
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped")
    except Exception as e:
        print(f"\n❌ Fatal error: {str(e)}")

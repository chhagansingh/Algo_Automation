#!/usr/bin/env python3
"""
Zerodha Login Helper Script
This script helps you authenticate with Zerodha Kite Connect API
"""

import json
from zerodha_trader import ZerodhaTrader

def main():
    print("=" * 70)
    print(" " * 20 + "Zerodha Kite Connect Login")
    print("=" * 70)
    print()

    # Load config
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
        # Expect config.json to have:
        # { "zerodha": { "api_key": "...", "api_secret": "..." }, ... }
        zerodha_cfg = config.get('zerodha', {})
        api_key = zerodha_cfg.get('api_key')
        api_secret = zerodha_cfg.get('api_secret')

        if not api_key or not api_secret:
            print("❌ Error: config.json missing zerodha.api_key or zerodha.api_secret")
            print("Update config.json with your Zerodha credentials (api_key and api_secret).")
            return

        if api_key == "your_api_key_here" or api_secret == "your_api_secret_here":
            print("❌ Error: Please update config.json with your Zerodha credentials")
            print()
            print("Steps to get credentials:")
            print("1. Go to https://developers.kite.trade/")
            print("2. Login with your Zerodha account")
            print("3. Create a new app")
            print("4. Copy API Key and API Secret")
            print("5. Update config.json with these credentials")
            return

    except FileNotFoundError:
        print("❌ Error: config.json not found")
        print("Please ensure config.json exists in the current directory")
        return
    except Exception as e:
        print(f"❌ Error loading config: {str(e)}")
        return

    # Create trader instance
    trader = ZerodhaTrader(api_key=api_key, api_secret=api_secret)

    # Try to load existing access token
    print("🔍 Checking for existing session...")
    if trader.load_access_token():
        if trader.is_logged_in():
            print("\n✅ Already logged in!")
            print()

            # Display profile info
            profile = trader.get_profile()
            print("📋 Account Details:")
            print(f"   👤 Name: {profile.get('user_name', 'N/A')}")
            print(f"   🆔 User ID: {profile.get('user_id', 'N/A')}")
            print(f"   📧 Email: {profile.get('email', 'N/A')}")
            print(f"   📱 Phone: {profile.get('phone', 'N/A')}")
            print()

            # Display margins
            margins = trader.get_margins()
            if margins:
                equity = margins.get('equity', {})
                available = equity.get('available', {})
                live_balance = available.get('live_balance', 0)

                print("💰 Account Balance:")
                print(f"   Available: ₹{live_balance:,.2f}")
                print()

            print("✅ You're all set! You can now run the trading bot.")
            print()
            print("To start trading, run:")
            print("   python zerodha_live_trader.py")
            return

    # Need to login
    print("\n🔐 New Login Required")
    print()
    print("=" * 70)
    print("STEP 1: Get Request Token")
    print("=" * 70)
    print()
    print("Copy and paste this URL into your browser:")
    print()
    try:
        login_url = trader.get_login_url()
        if not login_url:
            print("❌ Error: trader.get_login_url() returned no URL. Check ZerodhaTrader implementation and internet.")
            return
        print(login_url)
    except Exception as e:
        print(f"❌ Failed to get login URL: {e}")
        return

    # Get request token from user
    print("Option 1: Paste the full redirect URL")
    print("Option 2: Just paste the request_token value")
    print()
    user_input = input("Paste here: ").strip()

    # Extract request token from input
    request_token = None
    if not user_input:
        print("❌ No input provided")
        return

    # Check if user pasted full URL
    if 'request_token=' in user_input:
        try:
            # Extract request_token from URL
            parts = user_input.split('request_token=')[1]
            request_token = parts.split('&')[0]
        except:
            print("❌ Could not extract request_token from URL")
            return
    else:
        # Assume user pasted just the token
        request_token = user_input

    if not request_token:
        print("❌ Invalid request token")
        return

    print()
    print("=" * 70)
    print("STEP 3: Generating Session")
    print("=" * 70)
    print()

    # Generate session
    access_token = trader.generate_session(request_token)

    if access_token:
        print("\n🎉 Login Successful!")
        print()

        # Display profile info
        profile = trader.get_profile()
        print("📋 Account Details:")
        print(f"   👤 Name: {profile.get('user_name', 'N/A')}")
        print(f"   🆔 User ID: {profile.get('user_id', 'N/A')}")
        print(f"   📧 Email: {profile.get('email', 'N/A')}")
        print()

        # Display margins
        margins = trader.get_margins()
        if margins:
            equity = margins.get('equity', {})
            available = equity.get('available', {})
            live_balance = available.get('live_balance', 0)

            print("💰 Account Balance:")
            print(f"   Available: ₹{live_balance:,.2f}")
            print()

        print("=" * 70)
        print()
        print("✅ Setup Complete!")
        print()
        print("Your access token has been saved to 'zerodha_token.json'")
        print("This token will be used automatically for future trading sessions.")
        print()
        print("⚠️  Important Notes:")
        print("   • Access tokens expire at the end of each day")
        print("   • You'll need to login again tomorrow")
        print("   • Keep your API credentials secure")
        print()
        print("To start trading, run:")
        print("   python zerodha_live_trader.py")
        print()
    else:
        print("\n❌ Login Failed")
        print()
        print("Possible issues:")
        print("• Request token might be invalid or expired")
        print("• API credentials might be incorrect")
        print("• Check your internet connection")
        print()
        print("Please try again by running this script again.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n🛑 Login cancelled by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")

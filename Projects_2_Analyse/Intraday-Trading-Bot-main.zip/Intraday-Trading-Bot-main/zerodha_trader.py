from kiteconnect import KiteConnect
import json
import logging
from datetime import datetime
import os

class ZerodhaTrader:
    """
    Zerodha Kite Connect API wrapper for automated trading
    """

    def __init__(self, api_key, api_secret, access_token=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.access_token = access_token
        self.kite = KiteConnect(api_key=api_key)

        # Set logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

        if access_token:
            self.kite.set_access_token(access_token)

    def get_login_url(self):
        """
        Get the login URL for Zerodha authentication
        User needs to visit this URL and authorize the app
        """
        login_url = self.kite.login_url()
        return login_url

    def generate_session(self, request_token):
        """
        Generate access token from request token
        Request token is obtained after user authorizes the app
        """
        try:
            data = self.kite.generate_session(request_token, api_secret=self.api_secret)
            self.access_token = data["access_token"]
            self.kite.set_access_token(self.access_token)

            # Save access token for future use
            self.save_access_token(self.access_token)

            self.logger.info("✅ Session generated successfully!")
            return self.access_token
        except Exception as e:
            self.logger.error(f"❌ Session generation failed: {str(e)}")
            return None

    def save_access_token(self, access_token):
        """Save access token to file"""
        try:
            token_data = {
                'access_token': access_token,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            with open('zerodha_token.json', 'w') as f:
                json.dump(token_data, f)
            self.logger.info("💾 Access token saved")
        except Exception as e:
            self.logger.error(f"❌ Failed to save token: {str(e)}")

    def load_access_token(self):
        """Load access token from file"""
        try:
            if os.path.exists('zerodha_token.json'):
                with open('zerodha_token.json', 'r') as f:
                    token_data = json.load(f)
                    self.access_token = token_data['access_token']
                    self.kite.set_access_token(self.access_token)
                    self.logger.info("✅ Access token loaded from file")
                    return True
            return False
        except Exception as e:
            self.logger.error(f"❌ Failed to load token: {str(e)}")
            return False

    def is_logged_in(self):
        """Check if user is logged in by testing profile API"""
        try:
            profile = self.kite.profile()
            self.logger.info(f"✅ Logged in as: {profile['user_name']}")
            return True
        except Exception as e:
            self.logger.error(f"❌ Not logged in: {str(e)}")
            return False

    def get_profile(self):
        """Get user profile"""
        try:
            return self.kite.profile()
        except Exception as e:
            self.logger.error(f"❌ Failed to get profile: {str(e)}")
            return None

    def place_order(self, symbol, quantity, order_type, transaction_type, product_type="MIS",
                   order_variety="regular", price=None, trigger_price=None):
        """
        Place an order on Zerodha

        Args:
            symbol: Trading symbol (e.g., "RELIANCE")
            quantity: Number of shares
            order_type: "MARKET" or "LIMIT" or "SL" or "SL-M"
            transaction_type: "BUY" or "SELL"
            product_type: "MIS" (intraday) or "CNC" (delivery) or "NRML" (normal)
            order_variety: "regular", "amo", "co", "iceberg"
            price: Limit price (for LIMIT orders)
            trigger_price: Trigger price (for SL orders)

        Returns:
            order_id or None
        """
        try:
            order_params = {
                "tradingsymbol": symbol,
                "exchange": "NSE",
                "transaction_type": transaction_type,
                "quantity": quantity,
                "order_type": order_type,
                "product": product_type,
                "variety": order_variety
            }

            if price:
                order_params["price"] = price
            if trigger_price:
                order_params["trigger_price"] = trigger_price

            order_id = self.kite.place_order(**order_params)

            self.logger.info(f"✅ Order placed successfully: {order_id}")
            self.logger.info(f"   {transaction_type} {quantity} {symbol} @ {order_type}")

            return order_id

        except Exception as e:
            self.logger.error(f"❌ Order placement failed: {str(e)}")
            return None

    def modify_order(self, order_id, quantity=None, price=None, order_type=None,
                    trigger_price=None, variety="regular"):
        """Modify an existing order"""
        try:
            params = {}
            if quantity:
                params["quantity"] = quantity
            if price:
                params["price"] = price
            if order_type:
                params["order_type"] = order_type
            if trigger_price:
                params["trigger_price"] = trigger_price

            self.kite.modify_order(variety=variety, order_id=order_id, **params)
            self.logger.info(f"✅ Order {order_id} modified successfully")
            return True

        except Exception as e:
            self.logger.error(f"❌ Order modification failed: {str(e)}")
            return False

    def cancel_order(self, order_id, variety="regular"):
        """Cancel an order"""
        try:
            self.kite.cancel_order(variety=variety, order_id=order_id)
            self.logger.info(f"✅ Order {order_id} cancelled successfully")
            return True
        except Exception as e:
            self.logger.error(f"❌ Order cancellation failed: {str(e)}")
            return False

    def get_orders(self):
        """Get all orders for the day"""
        try:
            return self.kite.orders()
        except Exception as e:
            self.logger.error(f"❌ Failed to get orders: {str(e)}")
            return []

    def get_order_history(self, order_id):
        """Get history of a specific order"""
        try:
            return self.kite.order_history(order_id)
        except Exception as e:
            self.logger.error(f"❌ Failed to get order history: {str(e)}")
            return []

    def get_positions(self):
        """Get current positions"""
        try:
            positions = self.kite.positions()
            return positions
        except Exception as e:
            self.logger.error(f"❌ Failed to get positions: {str(e)}")
            return None

    def get_holdings(self):
        """Get current holdings"""
        try:
            return self.kite.holdings()
        except Exception as e:
            self.logger.error(f"❌ Failed to get holdings: {str(e)}")
            return []

    def get_margins(self):
        """Get account margins"""
        try:
            margins = self.kite.margins()
            return margins
        except Exception as e:
            self.logger.error(f"❌ Failed to get margins: {str(e)}")
            return None

    def get_available_cash(self):
        """Get available cash for trading"""
        try:
            margins = self.kite.margins()
            equity_margin = margins.get('equity', {})
            available = equity_margin.get('available', {}).get('live_balance', 0)
            return float(available)
        except Exception as e:
            self.logger.error(f"❌ Failed to get available cash: {str(e)}")
            return 0

    def get_quote(self, symbol, exchange="NSE"):
        """Get current quote for a symbol"""
        try:
            instrument = f"{exchange}:{symbol}"
            quote = self.kite.quote(instrument)
            return quote.get(instrument, {})
        except Exception as e:
            self.logger.error(f"❌ Failed to get quote for {symbol}: {str(e)}")
            return {}

    def get_ltp(self, symbol, exchange="NSE"):
        """Get last traded price for a symbol"""
        try:
            instrument = f"{exchange}:{symbol}"
            ltp = self.kite.ltp(instrument)
            return ltp.get(instrument, {}).get('last_price', 0)
        except Exception as e:
            self.logger.error(f"❌ Failed to get LTP for {symbol}: {str(e)}")
            return 0

    def get_instruments(self, exchange="NSE"):
        """Get all instruments for an exchange"""
        try:
            return self.kite.instruments(exchange)
        except Exception as e:
            self.logger.error(f"❌ Failed to get instruments: {str(e)}")
            return []

    def get_historical_data(self, instrument_token, from_date, to_date, interval):
        """
        Get historical data

        Args:
            instrument_token: Instrument token
            from_date: Start date (datetime object)
            to_date: End date (datetime object)
            interval: "minute", "3minute", "5minute", "10minute", "15minute",
                     "30minute", "60minute", "day"
        """
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            return data
        except Exception as e:
            self.logger.error(f"❌ Failed to get historical data: {str(e)}")
            return []

    def convert_ticker_to_symbol(self, ticker):
        """
        Convert yfinance ticker format to Zerodha symbol format
        Example: RELIANCE.NS -> RELIANCE
        """
        return ticker.replace('.NS', '').replace('.ns', '').upper()

    def exit_position(self, symbol, quantity, product_type="MIS"):
        """
        Exit a position (close long/short position)
        """
        try:
            # Get current position to determine if it's long or short
            positions = self.get_positions()
            if not positions:
                return False

            # Find the position
            current_position = None
            for pos in positions.get('net', []):
                if pos['tradingsymbol'] == symbol and pos['quantity'] != 0:
                    current_position = pos
                    break

            if not current_position:
                self.logger.error(f"❌ No open position found for {symbol}")
                return False

            # Determine transaction type (opposite of current position)
            if current_position['quantity'] > 0:
                transaction_type = "SELL"  # Close long position
            else:
                transaction_type = "BUY"   # Close short position
                quantity = abs(current_position['quantity'])

            # Place market order to exit
            order_id = self.place_order(
                symbol=symbol,
                quantity=quantity,
                order_type="MARKET",
                transaction_type=transaction_type,
                product_type=product_type
            )

            return order_id is not None

        except Exception as e:
            self.logger.error(f"❌ Failed to exit position: {str(e)}")
            return False


# Example usage and login helper
if __name__ == "__main__":
    print("=" * 60)
    print("Zerodha Kite Connect - Login Helper")
    print("=" * 60)

    # Load config
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)

        api_key = config['zerodha']['api_key']
        api_secret = config['zerodha']['api_secret']

    except Exception as e:
        print(f"❌ Failed to load config: {str(e)}")
        print("Please ensure config.json exists with Zerodha credentials")
        exit(1)

    # Create trader instance
    trader = ZerodhaTrader(api_key=api_key, api_secret=api_secret)

    # Try to load existing access token
    if trader.load_access_token():
        if trader.is_logged_in():
            print("\n✅ Already logged in!")
            profile = trader.get_profile()
            print(f"👤 User: {profile['user_name']}")
            print(f"📧 Email: {profile['email']}")

            # Get margins
            margins = trader.get_margins()
            if margins:
                equity = margins.get('equity', {})
                available = equity.get('available', {}).get('live_balance', 0)
                print(f"💰 Available Balance: ₹{available:.2f}")

            exit(0)

    # Need to login
    print("\n🔐 Login Required")
    print("\nStep 1: Visit this URL to login:")
    print("-" * 60)
    print(trader.get_login_url())
    print("-" * 60)

    print("\nStep 2: After login, you'll be redirected to a URL like:")
    print("http://127.0.0.1/?request_token=XXXXX&action=login&status=success")

    print("\nStep 3: Copy the request_token from the URL and paste below:")
    request_token = input("\nEnter request_token: ").strip()

    if not request_token:
        print("❌ No request token provided")
        exit(1)

    # Generate session
    access_token = trader.generate_session(request_token)

    if access_token:
        print("\n✅ Login successful!")
        profile = trader.get_profile()
        print(f"👤 User: {profile['user_name']}")
        print(f"📧 Email: {profile['email']}")

        # Get margins
        margins = trader.get_margins()
        if margins:
            equity = margins.get('equity', {})
            available = equity.get('available', {}).get('live_balance', 0)
            print(f"💰 Available Balance: ₹{available:.2f}")

        print("\n🎉 You're ready to trade!")
        print("Access token has been saved and will be used for future sessions.")
    else:
        print("\n❌ Login failed")
        exit(1)

#!/usr/bin/env python3
"""
MULTI-SIGNAL MEAN-REVERSION HYBRID STRATEGY v2
================================================

3 independent entry signal types for higher win rate and trade count:
  1. EMA Pullback  - trend continuation (buy dips in uptrend)
  2. BB Bounce     - mean reversion (buy at lower Bollinger Band)
  3. VWAP Reversion - institutional level reversion

ATR-based dynamic stops instead of fixed percentages.
Walk-forward validation to prevent overfitting.

Target: 60%+ win rate, 4-6 trades/day across 10 stocks on 1H candles.
"""

import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
from datetime import datetime, timedelta
import json


# =============================================================================
# 1. DATA DOWNLOAD
# =============================================================================

def get_and_prepare_data(ticker_symbol, interval_val, start_date_str, end_date_str):
    """Downloads historical data, standardizes columns."""
    try:
        print(f"  Downloading {ticker_symbol}... ", end="")
        df = yf.download(
            tickers=ticker_symbol,
            interval=interval_val,
            start=start_date_str,
            end=end_date_str,
            progress=False
        )

        if df.empty:
            print("No data")
            return pd.DataFrame()

        if df.index.tz is not None:
            df.index = df.index.tz_localize(None)

        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [str(col[0]).capitalize() for col in df.columns]
        else:
            df.columns = [str(col).capitalize() for col in df.columns]

        if 'Adj close' in df.columns:
            df.rename(columns={'Adj close': 'Close'}, inplace=True)

        desired = ['Open', 'High', 'Low', 'Close', 'Volume']
        df = df[[c for c in desired if c in df.columns]]

        print(f"{len(df)} bars")
        return df

    except Exception as e:
        print(f"Error: {str(e)}")
        return pd.DataFrame()


# =============================================================================
# 2. TECHNICAL INDICATORS
# =============================================================================

def calculate_daily_vwap(df):
    """Manual VWAP calculation anchored to each trading day."""
    df = df.copy()
    tp = (df['High'] + df['Low'] + df['Close']) / 3
    tpv = tp * df['Volume']

    dates = df.index.date
    cum_tpv = tpv.groupby(dates).cumsum()
    cum_vol = df['Volume'].groupby(dates).cumsum()

    df['VWAP'] = cum_tpv / cum_vol
    df['VWAP'] = df['VWAP'].replace([np.inf, -np.inf], np.nan)
    return df


def add_indicators_v2(df_input, config):
    """Add all technical indicators for the multi-signal strategy."""
    if df_input.empty or len(df_input) < 60:
        return pd.DataFrame()

    df = df_input.copy()
    ind = config['indicators']

    # Trend: EMA 20 and 50
    df['EMA20'] = ta.ema(df['Close'], length=ind['ema_short'])
    df['EMA50'] = ta.ema(df['Close'], length=ind['ema_long'])

    # Momentum: RSI
    df['RSI'] = ta.rsi(df['Close'], length=ind['rsi_length'])

    # Volatility: Bollinger Bands
    bb = ta.bbands(df['Close'], length=ind['bb_length'], std=ind['bb_std'])
    if bb is not None and not bb.empty:
        bb_cols = bb.columns
        lower_col = [c for c in bb_cols if 'BBL' in c]
        mid_col = [c for c in bb_cols if 'BBM' in c]
        upper_col = [c for c in bb_cols if 'BBU' in c]
        if lower_col:
            df['BB_Lower'] = bb[lower_col[0]]
        if mid_col:
            df['BB_Middle'] = bb[mid_col[0]]
        if upper_col:
            df['BB_Upper'] = bb[upper_col[0]]

    # Volatility: ATR
    df['ATR'] = ta.atr(df['High'], df['Low'], df['Close'], length=ind['atr_length'])

    # Trend strength: ADX
    adx_df = ta.adx(df['High'], df['Low'], df['Close'], length=ind['adx_length'])
    if adx_df is not None and not adx_df.empty:
        adx_col = [c for c in adx_df.columns if c.startswith('ADX_')]
        if adx_col:
            df['ADX'] = adx_df[adx_col[0]]

    # VWAP (manual calculation for reliability with yfinance data)
    df = calculate_daily_vwap(df)

    # Volume average
    df['Volume_SMA20'] = df['Volume'].rolling(window=ind['volume_sma_length']).mean()

    # Drop rows where critical indicators are NaN
    critical = ['EMA20', 'EMA50', 'RSI', 'ATR', 'Volume_SMA20']
    for c in ['BB_Lower', 'BB_Upper', 'ADX', 'VWAP']:
        if c in df.columns:
            critical.append(c)

    available = [c for c in critical if c in df.columns]
    df = df.dropna(subset=available)

    return df


# =============================================================================
# 3. SIGNAL DETECTION
# =============================================================================

def check_time_filter(candle_time, config):
    """Check if candle falls within allowed trading hours.
    yfinance returns UTC timestamps for Indian stocks.
    IST = UTC + 5:30, so we convert candle time to IST first.
    """
    tf = config['time_filter']
    start = tf['start_hour'] * 60 + tf['start_minute']
    end = tf['end_hour'] * 60 + tf['end_minute']

    # Convert UTC to IST (add 5 hours 30 minutes)
    ist_time = candle_time + pd.Timedelta(hours=5, minutes=30)
    candle_mins = ist_time.hour * 60 + ist_time.minute
    return start <= candle_mins <= end


def check_rsi_reversal_signal(current, prev, df, i, config):
    """
    Signal 1: RSI Reversal - mean reversion from extreme levels.
    Buy when RSI was recently oversold and is now recovering.
    Sell when RSI was recently overbought and is now declining.
    High win rate because extreme RSI levels tend to revert.
    """
    cfg = config['entry_signals']['rsi_reversal']
    if not cfg['enabled']:
        return None, None

    close = current['Close']
    open_price = current['Open']
    rsi = current['RSI']
    volume = current['Volume']
    vol_avg = current['Volume_SMA20']

    if pd.isna([close, open_price, rsi, volume, vol_avg]).any():
        return None, None

    lookback = cfg['lookback_bars']
    if i < lookback:
        return None, None

    # Check if RSI was recently oversold (in last N bars)
    recent_rsi_values = [df.iloc[i - j]['RSI'] for j in range(1, lookback + 1)
                         if not pd.isna(df.iloc[i - j]['RSI'])]
    if not recent_rsi_values:
        return None, None

    min_recent_rsi = min(recent_rsi_values)
    max_recent_rsi = max(recent_rsi_values)

    # LONG: RSI was oversold recently and now recovering + bullish candle
    if (min_recent_rsi < cfg['rsi_oversold'] and
        rsi > cfg['rsi_oversold'] and
        close > open_price and
        volume > cfg['volume_multiplier'] * vol_avg):
        return 'rsi_reversal', 'long'

    # SHORT: RSI was overbought recently and now declining + bearish candle
    if (max_recent_rsi > cfg['rsi_overbought'] and
        rsi < cfg['rsi_overbought'] and
        close < open_price and
        volume > cfg['volume_multiplier'] * vol_avg):
        return 'rsi_reversal', 'short'

    return None, None


def check_bb_bounce_signal(current, prev, df, i, config):
    """
    Signal 2: Bollinger Band Bounce - mean reversion.
    Buy when price touches lower BB and bounces back inside.
    """
    cfg = config['entry_signals']['bb_bounce']
    if not cfg['enabled']:
        return None, None

    close = current['Close']
    low = current['Low']
    high = current['High']
    rsi = current['RSI']
    bb_lower = current.get('BB_Lower', np.nan)
    bb_upper = current.get('BB_Upper', np.nan)
    ema50 = current['EMA50']
    volume = current['Volume']
    vol_avg = current['Volume_SMA20']

    if pd.isna([close, low, high, rsi, bb_lower, bb_upper, ema50, volume, vol_avg]).any():
        return None, None

    # EMA50 slope check: not crashing / not surging
    slope_bars = cfg['ema50_slope_bars']
    if i >= slope_bars:
        ema50_past = df.iloc[i - slope_bars]['EMA50']
        if pd.isna(ema50_past):
            ema50_past = ema50
    else:
        ema50_past = ema50

    open_price = current['Open']
    candle_confirm = cfg.get('require_candle_confirmation', False)

    # LONG: price touches lower BB and bounces with bullish candle
    if (low <= bb_lower and
        close > bb_lower and
        rsi < cfg['rsi_oversold'] and
        ema50 >= ema50_past * (1 - cfg['ema50_slope_threshold']) and
        volume > cfg['volume_multiplier'] * vol_avg and
        (not candle_confirm or close > open_price)):
        return 'bb_bounce', 'long'

    # SHORT: price touches upper BB and drops with bearish candle
    if (high >= bb_upper and
        close < bb_upper and
        rsi > cfg['rsi_overbought'] and
        ema50 <= ema50_past * (1 + cfg['ema50_slope_threshold']) and
        volume > cfg['volume_multiplier'] * vol_avg and
        (not candle_confirm or close < open_price)):
        return 'bb_bounce', 'short'

    return None, None


def check_vwap_ema_confluence_signal(current, prev, df, i, config):
    """
    Signal 3: VWAP + EMA Confluence - price below both VWAP and EMA20, reverts up.
    Simple mean-reversion: when price is below key levels, it tends to bounce back.
    """
    cfg = config['entry_signals']['vwap_ema_confluence']
    if not cfg['enabled']:
        return None, None

    close = current['Close']
    open_price = current['Open']
    ema20 = current['EMA20']
    vwap = current.get('VWAP', np.nan)
    volume = current['Volume']
    vol_avg = current['Volume_SMA20']

    if pd.isna([close, open_price, ema20, vwap, volume, vol_avg]).any():
        return None, None

    rsi = current['RSI']
    if pd.isna(rsi):
        return None, None

    rsi_long_max = cfg.get('rsi_long_max', 50)
    rsi_short_min = cfg.get('rsi_short_min', 50)

    # LONG: price below VWAP and EMA20, bullish candle, RSI not too high
    if (close < vwap and
        close < ema20 and
        rsi < rsi_long_max and
        close > open_price and  # bullish candle
        volume > cfg['volume_multiplier'] * vol_avg):
        return 'vwap_ema_confluence', 'long'

    # SHORT: price above VWAP and EMA20, bearish candle, RSI not too low
    if (close > vwap and
        close > ema20 and
        rsi > rsi_short_min and
        close < open_price and  # bearish candle
        volume > cfg['volume_multiplier'] * vol_avg):
        return 'vwap_ema_confluence', 'short'

    return None, None


# =============================================================================
# 4. EXIT MANAGEMENT
# =============================================================================

def calculate_atr_stops(entry_price, atr_value, direction, config):
    """Calculate dynamic SL and TP based on ATR."""
    exits = config['exits']
    sl_dist = atr_value * exits['atr_multiplier_sl']
    tp_dist = atr_value * exits['atr_multiplier_tp']

    # Enforce minimum stop distance
    min_stop = entry_price * exits['min_stop_pct']
    sl_dist = max(sl_dist, min_stop)
    tp_dist = max(tp_dist, min_stop)

    if direction == 'long':
        stop_loss = entry_price - sl_dist
        take_profit = entry_price + tp_dist
    else:
        stop_loss = entry_price + sl_dist
        take_profit = entry_price - tp_dist

    return stop_loss, take_profit


# =============================================================================
# 5. BACKTEST ENGINE
# =============================================================================

def run_backtest_v2(df, ticker, config):
    """
    Run backtest with multi-signal entries, ATR-based stops, and trailing stops.
    Returns: (trades_list, capital_history, summary_dict)
    """
    if df.empty or len(df) < 100:
        return [], [], None

    capital = config['initial_capital']
    risk_pct = config['risk_management']['risk_per_trade_pct']
    max_pos_pct = config['risk_management']['max_position_pct']
    brokerage_pct = config['risk_management']['brokerage_pct']
    exits_cfg = config['exits']

    # State
    position = None  # 'long' or 'short'
    entry_price = 0
    entry_time = None
    shares = 0
    stop_loss = 0
    take_profit = 0
    trailing_active = False
    trailing_stop = 0
    best_price = 0  # highest for long, lowest for short
    signal_type = None
    entry_atr = 0

    trades = []
    capital_history = [capital]
    peak_capital = capital
    max_drawdown = 0

    # Per-day tracking
    daily_trades = {}
    cooldown = {}  # {ticker: last_exit_bar_index}

    for i in range(1, len(df)):
        current = df.iloc[i]
        prev = df.iloc[i - 1]
        candle_time = current.name

        capital_history.append(capital)

        # ---- POSITION MANAGEMENT ----
        if position:
            price = current['Close']
            high = current['High']
            low = current['Low']
            atr = current['ATR'] if not pd.isna(current['ATR']) else entry_atr

            # Update trailing stop
            if position == 'long':
                if price > best_price:
                    best_price = price
                profit_pct_atr = (price - entry_price) / entry_atr if entry_atr > 0 else 0
                if profit_pct_atr >= exits_cfg['trailing_activation_atr'] and not trailing_active:
                    trailing_active = True
                    trailing_stop = entry_price + entry_atr * exits_cfg['trailing_distance_atr']
                if trailing_active:
                    new_trail = best_price - entry_atr * exits_cfg['trailing_distance_atr']
                    trailing_stop = max(trailing_stop, new_trail)

            elif position == 'short':
                if price < best_price:
                    best_price = price
                profit_pct_atr = (entry_price - price) / entry_atr if entry_atr > 0 else 0
                if profit_pct_atr >= exits_cfg['trailing_activation_atr'] and not trailing_active:
                    trailing_active = True
                    trailing_stop = entry_price - entry_atr * exits_cfg['trailing_distance_atr']
                if trailing_active:
                    new_trail = best_price + entry_atr * exits_cfg['trailing_distance_atr']
                    trailing_stop = min(trailing_stop, new_trail)

            # Check exit conditions
            exit_price = None
            exit_reason = None

            if position == 'long':
                if low <= stop_loss:
                    exit_price = stop_loss
                    exit_reason = 'Stop Loss'
                elif high >= take_profit:
                    exit_price = take_profit
                    exit_reason = 'Take Profit'
                elif trailing_active and low <= trailing_stop:
                    exit_price = trailing_stop
                    exit_reason = 'Trailing Stop'
            else:
                if high >= stop_loss:
                    exit_price = stop_loss
                    exit_reason = 'Stop Loss'
                elif low <= take_profit:
                    exit_price = take_profit
                    exit_reason = 'Take Profit'
                elif trailing_active and high >= trailing_stop:
                    exit_price = trailing_stop
                    exit_reason = 'Trailing Stop'

            # Time stop: 2:30 PM IST (convert UTC candle time to IST)
            if not exit_reason:
                ist = candle_time + pd.Timedelta(hours=5, minutes=30)
                if (ist.hour > exits_cfg['time_stop_hour'] or
                    (ist.hour == exits_cfg['time_stop_hour'] and
                     ist.minute >= exits_cfg['time_stop_minute'])):
                    exit_price = price
                    exit_reason = 'Time Stop'

            # EOD close
            if not exit_reason and i < len(df) - 1:
                next_date = df.iloc[i + 1].name.date()
                if candle_time.date() != next_date:
                    exit_price = price
                    exit_reason = 'EOD Close'

            # Last bar
            if not exit_reason and i == len(df) - 1:
                exit_price = price
                exit_reason = 'EOD Close'

            # Execute exit
            if exit_reason:
                if position == 'long':
                    pnl = shares * (exit_price - entry_price)
                else:
                    pnl = shares * (entry_price - exit_price)

                brokerage = shares * exit_price * brokerage_pct
                net_pnl = pnl - brokerage
                capital += net_pnl

                pnl_pct = (net_pnl / (shares * entry_price)) * 100 if shares * entry_price > 0 else 0

                peak_capital = max(peak_capital, capital)
                dd = (peak_capital - capital) / peak_capital if peak_capital > 0 else 0
                max_drawdown = max(max_drawdown, dd)

                trades.append({
                    'Ticker': ticker,
                    'Signal Type': signal_type,
                    'Direction': position.upper(),
                    'Entry Time': entry_time,
                    'Exit Time': candle_time,
                    'Entry Price': round(entry_price, 2),
                    'Exit Price': round(exit_price, 2),
                    'Shares': round(shares, 2),
                    'ATR at Entry': round(entry_atr, 2),
                    'Gross PnL': round(pnl, 2),
                    'Brokerage': round(brokerage, 2),
                    'Net PnL': round(net_pnl, 2),
                    'PnL %': round(pnl_pct, 2),
                    'Capital': round(capital, 2),
                    'Exit Reason': exit_reason
                })

                cooldown[ticker] = i
                position = None
                entry_price = 0
                shares = 0
                trailing_active = False

        # ---- ENTRY SIGNALS ----
        else:
            # Cooldown check
            min_gap = config['risk_management']['min_candles_between_entries']
            if ticker in cooldown and (i - cooldown[ticker]) < min_gap:
                continue

            # Time filter
            if not check_time_filter(candle_time, config):
                continue

            # Daily trade limit
            day_key = candle_time.date()
            if daily_trades.get(day_key, 0) >= config['risk_management']['max_trades_per_day']:
                continue

            # Daily loss circuit breaker
            day_pnl = sum(t['Net PnL'] for t in trades if t['Exit Time'].date() == day_key)
            if day_pnl < -(config['initial_capital'] * config['risk_management']['max_daily_loss_pct']):
                continue

            atr = current['ATR']
            if pd.isna(atr) or atr <= 0:
                continue

            # Check all signal types (BB bounce first - highest win rate)
            sig_type, direction = check_bb_bounce_signal(current, prev, df, i, config)

            if not sig_type:
                sig_type, direction = check_rsi_reversal_signal(current, prev, df, i, config)

            if not sig_type:
                sig_type, direction = check_vwap_ema_confluence_signal(current, prev, df, i, config)

            if sig_type and direction:
                entry_price = current['Close']
                entry_time = candle_time
                entry_atr = atr
                position = direction
                signal_type = sig_type

                # Position sizing
                sl_dist = max(atr * config['exits']['atr_multiplier_sl'],
                              entry_price * config['exits']['min_stop_pct'])
                shares = (capital * risk_pct) / sl_dist
                max_shares = (capital * max_pos_pct) / entry_price
                shares = min(shares, max_shares)

                if shares <= 0:
                    position = None
                    continue

                # Set stops
                stop_loss, take_profit = calculate_atr_stops(entry_price, atr, direction, config)
                trailing_active = False
                trailing_stop = 0
                best_price = entry_price

                daily_trades[day_key] = daily_trades.get(day_key, 0) + 1

    # Summary
    total_trades = len(trades)
    if total_trades == 0:
        return trades, capital_history, None

    winners = [t for t in trades if t['Net PnL'] > 0]
    losers = [t for t in trades if t['Net PnL'] < 0]
    win_rate = (len(winners) / total_trades) * 100

    total_pnl = capital - config['initial_capital']
    total_return = (total_pnl / config['initial_capital']) * 100

    avg_win = np.mean([t['Net PnL'] for t in winners]) if winners else 0
    avg_loss = np.mean([t['Net PnL'] for t in losers]) if losers else 0

    # Trades per day
    trading_days = len(set(t['Entry Time'].date() for t in trades))
    trades_per_day = total_trades / trading_days if trading_days > 0 else 0

    # Signal type breakdown
    signal_counts = {}
    signal_wins = {}
    for t in trades:
        st = t['Signal Type']
        signal_counts[st] = signal_counts.get(st, 0) + 1
        if t['Net PnL'] > 0:
            signal_wins[st] = signal_wins.get(st, 0) + 1

    # Exit reason breakdown
    exit_reasons = {}
    exit_reason_wins = {}
    for t in trades:
        er = t['Exit Reason']
        exit_reasons[er] = exit_reasons.get(er, 0) + 1
        if t['Net PnL'] > 0:
            exit_reason_wins[er] = exit_reason_wins.get(er, 0) + 1

    summary = {
        'Ticker': ticker,
        'Initial Capital': config['initial_capital'],
        'Final Capital': round(capital, 2),
        'Total PnL': round(total_pnl, 2),
        'Return %': round(total_return, 2),
        'Total Trades': total_trades,
        'Winning': len(winners),
        'Losing': len(losers),
        'Win Rate %': round(win_rate, 2),
        'Avg Win': round(avg_win, 2),
        'Avg Loss': round(avg_loss, 2),
        'Max Drawdown %': round(max_drawdown * 100, 2),
        'Trading Days': trading_days,
        'Trades/Day': round(trades_per_day, 2),
    }

    # Add per-signal breakdown
    for st in ['rsi_reversal', 'bb_bounce', 'vwap_ema_confluence']:
        count = signal_counts.get(st, 0)
        wins = signal_wins.get(st, 0)
        wr = (wins / count * 100) if count > 0 else 0
        summary[f'{st}_count'] = count
        summary[f'{st}_wr'] = round(wr, 1)

    # Add exit reason breakdown
    for er in ['Take Profit', 'Stop Loss', 'Trailing Stop', 'Time Stop', 'EOD Close']:
        count = exit_reasons.get(er, 0)
        wins = exit_reason_wins.get(er, 0)
        summary[f'exit_{er.replace(" ", "_").lower()}_count'] = count
        summary[f'exit_{er.replace(" ", "_").lower()}_wr'] = round((wins / count * 100) if count > 0 else 0, 1)

    return trades, capital_history, summary


# =============================================================================
# 6. WALK-FORWARD VALIDATION
# =============================================================================

def walk_forward_validation(all_data, tickers, config):
    """Run walk-forward validation to detect overfitting."""
    wf = config['walk_forward']
    results = []

    print("\n" + "=" * 80)
    print("WALK-FORWARD VALIDATION")
    print("=" * 80)

    for ticker in tickers:
        if ticker not in all_data or all_data[ticker].empty:
            continue

        df = all_data[ticker]
        dates = df.index
        total_days = (dates[-1] - dates[0]).days

        train_days = wf['train_months'] * 30
        test_days = wf['test_months'] * 30
        step_days = test_days

        windows = []
        offset = 0

        while offset + train_days + test_days <= total_days:
            w_start = dates[0] + pd.Timedelta(days=offset)
            train_end = w_start + pd.Timedelta(days=train_days)
            test_end = train_end + pd.Timedelta(days=test_days)

            train_df = df[(df.index >= w_start) & (df.index < train_end)]
            test_df = df[(df.index >= train_end) & (df.index < test_end)]

            if len(train_df) < 100 or len(test_df) < 20:
                offset += step_days
                continue

            _, _, train_sum = run_backtest_v2(train_df, ticker, config)
            _, _, test_sum = run_backtest_v2(test_df, ticker, config)

            if train_sum and test_sum:
                train_wr = train_sum['Win Rate %']
                test_wr = test_sum['Win Rate %']
                # Only fail when test WR drops significantly below train WR
                # Test WR higher than train WR is not overfitting
                degradation = train_wr - test_wr  # positive = test worse
                passed = degradation < wf['win_rate_tolerance'] * 100

                windows.append({
                    'period': f"{w_start.strftime('%Y-%m-%d')} to {test_end.strftime('%Y-%m-%d')}",
                    'train_wr': train_wr,
                    'test_wr': test_wr,
                    'train_trades': train_sum['Total Trades'],
                    'test_trades': test_sum['Total Trades'],
                    'train_return': train_sum['Return %'],
                    'test_return': test_sum['Return %'],
                    'passed': passed
                })

            offset += step_days

        if windows:
            pass_count = sum(1 for w in windows if w['passed'])
            total_windows = len(windows)
            results.append({
                'ticker': ticker,
                'windows': windows,
                'pass_rate': pass_count / total_windows if total_windows > 0 else 0
            })

            print(f"\n  {ticker}: {pass_count}/{total_windows} windows passed")
            for w in windows:
                status = "PASS" if w['passed'] else "FAIL"
                print(f"    {w['period']}: Train WR={w['train_wr']:.1f}% Test WR={w['test_wr']:.1f}% [{status}]")

    # Overall assessment
    if results:
        avg_pass_rate = np.mean([r['pass_rate'] for r in results])
        print(f"\n  Overall pass rate: {avg_pass_rate:.1%}")
        if avg_pass_rate >= 0.5:
            print("  VERDICT: Strategy appears ROBUST (not overfitted)")
        else:
            print("  VERDICT: Strategy may be OVERFITTED - review parameters")

    return results


# =============================================================================
# 7. MAIN
# =============================================================================

def main():
    print("=" * 80)
    print("MULTI-SIGNAL TRADING STRATEGY v2 - BACKTEST")
    print("=" * 80)

    # Load config
    with open('strategy_config.json', 'r') as f:
        config = json.load(f)

    tickers = config['tickers']
    interval = config['timeframe']
    end_date = datetime.now()
    start_date = end_date - timedelta(days=config['backtest_days'])
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')

    print(f"\nStrategy: {config['strategy_name']}")
    print(f"Timeframe: {interval}")
    print(f"Period: {start_str} to {end_str}")
    print(f"Tickers: {len(tickers)}")
    print(f"Initial Capital: {config['initial_capital']} per stock")

    # Download and prepare data
    print("\n--- Downloading Data ---")
    all_data = {}
    all_data_with_indicators = {}

    for ticker in tickers:
        df = get_and_prepare_data(ticker, interval, start_str, end_str)
        if not df.empty:
            all_data[ticker] = df
            df_ind = add_indicators_v2(df, config)
            if not df_ind.empty:
                all_data_with_indicators[ticker] = df_ind

    # Run backtests
    print("\n--- Running Backtests ---")
    all_summaries = []
    all_trades = {}

    for ticker in tickers:
        if ticker not in all_data_with_indicators:
            continue

        df = all_data_with_indicators[ticker]
        bt_trades, cap_hist, summary = run_backtest_v2(df, ticker, config)

        if summary:
            all_summaries.append(summary)
            if bt_trades:
                all_trades[ticker] = pd.DataFrame(bt_trades)

            print(f"\n  {ticker}:")
            print(f"    Trades: {summary['Total Trades']} | Win Rate: {summary['Win Rate %']:.1f}% | Return: {summary['Return %']:.2f}%")
            print(f"    Trades/Day: {summary['Trades/Day']:.2f} | Max DD: {summary['Max Drawdown %']:.2f}%")
            print(f"    Signals: RSI={summary.get('rsi_reversal_count',0)}({summary.get('rsi_reversal_wr',0)}%) "
                  f"BB={summary.get('bb_bounce_count',0)}({summary.get('bb_bounce_wr',0)}%) "
                  f"VWAP_EMA={summary.get('vwap_ema_confluence_count',0)}({summary.get('vwap_ema_confluence_wr',0)}%)")
            print(f"    Exits: TP={summary.get('exit_take_profit_count',0)}({summary.get('exit_take_profit_wr',0)}%) "
                  f"SL={summary.get('exit_stop_loss_count',0)}({summary.get('exit_stop_loss_wr',0)}%) "
                  f"Trail={summary.get('exit_trailing_stop_count',0)}({summary.get('exit_trailing_stop_wr',0)}%) "
                  f"Time={summary.get('exit_time_stop_count',0)}({summary.get('exit_time_stop_wr',0)}%) "
                  f"EOD={summary.get('exit_eod_close_count',0)}({summary.get('exit_eod_close_wr',0)}%)")

    # Overall summary
    if all_summaries:
        print("\n" + "=" * 80)
        print("OVERALL RESULTS")
        print("=" * 80)

        summary_df = pd.DataFrame(all_summaries)

        total_initial = summary_df['Initial Capital'].sum()
        total_final = summary_df['Final Capital'].sum()
        total_return = ((total_final - total_initial) / total_initial) * 100

        total_trades = summary_df['Total Trades'].sum()
        total_wins = summary_df['Winning'].sum()
        overall_wr = (total_wins / total_trades * 100) if total_trades > 0 else 0

        total_days = summary_df['Trading Days'].max()
        overall_tpd = total_trades / total_days if total_days > 0 else 0

        avg_dd = summary_df['Max Drawdown %'].mean()

        # Signal breakdown
        total_rsi = summary_df['rsi_reversal_count'].sum()
        total_bb = summary_df['bb_bounce_count'].sum()
        total_vwap_ema = summary_df['vwap_ema_confluence_count'].sum()

        print(f"\n  Initial Capital: {total_initial:,.2f}")
        print(f"  Final Capital:   {total_final:,.2f}")
        print(f"  Total Return:    {total_return:+.2f}%")
        print(f"  Total Trades:    {total_trades}")
        print(f"  Overall Win Rate: {overall_wr:.2f}%")
        print(f"  Trades/Day (portfolio): {overall_tpd:.2f}")
        print(f"  Avg Max Drawdown: {avg_dd:.2f}%")
        print(f"\n  Signal Breakdown:")
        print(f"    RSI Reversal:       {total_rsi} trades")
        print(f"    BB Bounce:          {total_bb} trades")
        print(f"    VWAP+EMA Confluence: {total_vwap_ema} trades")

        # Per-ticker table
        print("\n" + "-" * 80)
        print("PER-TICKER RESULTS")
        print("-" * 80)
        display_cols = ['Ticker', 'Total Trades', 'Win Rate %', 'Return %',
                        'Trades/Day', 'Max Drawdown %', 'Avg Win', 'Avg Loss']
        print(summary_df[display_cols].to_string(index=False))

        # Save to Excel
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'strategy_v2_results_{timestamp}.xlsx'

        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            summary_df.to_excel(writer, sheet_name='Summary', index=False)

            # All trades combined
            if all_trades:
                combined = pd.concat(all_trades.values(), ignore_index=True)
                combined.to_excel(writer, sheet_name='All Trades', index=False)

                # Per ticker sheets
                for ticker_name, trades_df in all_trades.items():
                    sheet = ticker_name.replace('.NS', '')[:31]
                    trades_df.to_excel(writer, sheet_name=sheet, index=False)

        print(f"\n  Results saved to: {filename}")

        # Walk-forward validation
        walk_forward_validation(all_data_with_indicators, tickers, config)

    else:
        print("\nNo results to display.")


if __name__ == "__main__":
    main()

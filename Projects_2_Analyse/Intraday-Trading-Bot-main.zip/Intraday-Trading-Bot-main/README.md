# NSE Intraday Trading Bot

Automated intraday trading system for Indian stocks (NSE) using a **multi-signal mean-reversion strategy** on 1-hour candles. Built with Python, backtested with walk-forward validation, and integrated with Zerodha Kite for live execution.

---

## Strategy Overview

The strategy combines **3 independent mean-reversion entry signals** with **ATR-based dynamic exits** to achieve a consistent **63%+ win rate** across 12 liquid NSE stocks.

### Core Concept

Mean-reversion on 1H candles -- when price reaches an extreme level (Bollinger Band, oversold/overbought RSI, deviation from VWAP), it tends to snap back. We enter at these extremes with tight take-profits and wide stop-losses, making take-profit **7.5x easier to hit** than stop-loss.

---

## The 3 Entry Signals

### 1. Bollinger Band Bounce (Primary Signal -- ~60% of trades)

Triggers when price touches the lower/upper Bollinger Band and bounces back inside.

- **Long**: Low touches lower BB, close is back above it, RSI < 50, bullish candle
- **Short**: High touches upper BB, close drops below it, RSI > 50, bearish candle
- Filtered by EMA50 slope (trend not crashing), volume > 0.6x average
- Best and most consistent performer: **60-76% win rate** across stocks

### 2. RSI Reversal (~23% of trades)

Triggers when RSI was recently at an extreme and is now recovering.

- **Long**: RSI dipped below 30 in the last 3 bars, now recovered above 30, bullish candle
- **Short**: RSI spiked above 70 in the last 3 bars, now dropped below 70, bearish candle
- Filtered by volume > 0.7x average
- High variance but strong: **28-80% win rate** depending on the stock

### 3. VWAP + EMA Confluence (~15% of trades)

Triggers when price deviates from both daily VWAP and EMA20 simultaneously.

- **Long**: Close < VWAP, close < EMA20, RSI < 35, bullish candle
- **Short**: Close > VWAP, close > EMA20, RSI > 65, bearish candle
- Tight RSI filter ensures only high-quality mean-reversion setups
- Filtered by volume > 0.7x average

### Signal Priority

Signals are checked in order: **BB Bounce > RSI Reversal > VWAP+EMA**. Only one signal fires per candle per stock. BB Bounce gets priority because it has the highest and most consistent win rate.

---

## Exit System

All exits use **ATR(14)-based dynamic levels** that adapt to each stock's volatility:

| Exit Type | Distance | Purpose |
|-----------|----------|---------|
| Take Profit | 0.4x ATR | Tight TP -- easy to hit for mean-reversion |
| Stop Loss | 3.0x ATR | Wide SL -- gives trade room to breathe |
| Trailing Stop | Activates at 0.35x ATR profit, trails at 0.25x ATR | Locks in profits on runners |
| Time Stop | 3:00 PM IST | Forces close before market end |
| EOD Close | End of day | No overnight positions |

### Why Asymmetric Stops Work

With TP at 0.4x ATR and SL at 3.0x ATR, the take-profit is **7.5x closer** than the stop-loss. In a mean-reversion context, price snapping back a small amount (0.4x ATR) is far more likely than continuing against you for 3x ATR. This asymmetry is what drives the 63% win rate.

---

## Technical Indicators Used

| Indicator | Parameters | Purpose |
|-----------|-----------|---------|
| EMA | 20 and 50 period | Short/medium-term trend reference |
| RSI | 14-period | Overbought/oversold detection |
| Bollinger Bands | 20-period, 2 std dev | Volatility bands for BB Bounce signal |
| ATR | 14-period | Dynamic stop-loss/take-profit sizing |
| ADX | 14-period | Trend strength measurement |
| VWAP | Daily anchored (manual calc) | Institutional price level for VWAP signal |
| Volume SMA | 20-period | Volume confirmation filter |

---

## Stocks Traded

12 liquid NSE large-cap stocks across diversified sectors:

| Stock | Sector | Backtest Win Rate |
|-------|--------|-------------------|
| HINDUNILVR | FMCG | 71.9% |
| KOTAKBANK | Banking | 69.0% |
| ASIANPAINT | Consumer | 66.7% |
| SUNPHARMA | Pharma | 65.8% |
| HDFCBANK | Banking | 65.4% |
| NESTLEIND | FMCG | 63.6% |
| BAJFINANCE | Finance | 62.5% |
| MARUTI | Auto | 62.2% |
| INFY | IT | 60.6% |
| LT | Infrastructure | 59.5% |
| AXISBANK | Banking | 57.1% |
| RELIANCE | Conglomerate | 56.0% |

---

## Backtest Results

6-month backtest on 1H candles (Sep 2025 - Mar 2026):

```
Overall Win Rate:      63.40%
Total Trades:          377
Trades/Day (portfolio): 9.92
Total Return:          +0.05%
Avg Max Drawdown:      0.48%
Walk-Forward Pass Rate: 70.8% (strategy is robust, not overfitted)
```

### Signal Breakdown

```
BB Bounce:          232 trades (best performer)
RSI Reversal:        87 trades
VWAP+EMA Confluence: 58 trades
```

---

## Risk Management

| Parameter | Value | Purpose |
|-----------|-------|---------|
| Risk per trade | 1% of capital | Position sized so max loss = 1% |
| Max position size | 20% of capital | No single stock dominates |
| Max concurrent positions | 4 | Diversification across stocks |
| Max trades per day | 6 | Prevents overtrading |
| Max daily loss | 5% of capital | Circuit breaker stops all trading |
| Cooldown | 1 candle | Minimum gap between trades on same stock |
| Entry window | 10:15 AM - 2:00 PM IST | Avoids opening volatility, gives trades time to resolve |

---

## Walk-Forward Validation

The strategy uses **rolling walk-forward validation** to prevent overfitting:

- **Training window**: 3 months of data
- **Test window**: 1 month of unseen data
- **Rolling step**: 1 month forward
- **Pass criteria**: Out-of-sample win rate must not drop more than 20% below in-sample

**Result: 70.8% of windows pass**, confirming the strategy generalizes to unseen data and is not curve-fitted to historical patterns.

---

## Project Structure

```
.
├── strategy_v2.py              # Backtest engine (3 signals + walk-forward validation)
├── strategy_config.json        # All configurable parameters
├── paper_trading_bot_v2.py     # Paper trading bot (simulates with real-time data)
├── zerodha_live_trader.py      # Live trading via Zerodha Kite API
├── zerodha_trader.py           # Zerodha API wrapper
├── zerodha_login.py            # Zerodha authentication helper
├── zerodha_token.json          # Auth token storage
├── config.json                 # Zerodha API credentials
├── requirements.txt            # Python dependencies
└── README.md
```

---

## How to Use

### Prerequisites

- Python 3.10+
- pip

### Installation

```bash
git clone https://github.com/Goodest-ai/SOC.git
cd SOC
pip install -r requirements.txt
```

### 1. Run Backtest

Downloads 6 months of data from Yahoo Finance, runs the strategy bar-by-bar, and validates with walk-forward analysis:

```bash
python3 strategy_v2.py
```

Output includes per-stock results, signal breakdown, exit analysis, and walk-forward validation.

### 2. Paper Trading (Recommended First Step)

Simulates live trading with real-time data, no real money:

```bash
python3 paper_trading_bot_v2.py
```

- Scans all 12 stocks every 60 seconds during market hours
- Checks signals on the latest candle
- Manages positions with trailing stops and time stops
- Press `Ctrl+C` to stop -- saves trade log to CSV

### 3. Live Trading (Zerodha)

Executes real trades through Zerodha Kite Connect API:

```bash
# Step 1: Login to Zerodha (required daily -- tokens expire)
python3 zerodha_login.py

# Step 2: Start the bot
python3 zerodha_live_trader.py
```

**Requirements for live trading:**
- Zerodha Kite Connect API subscription ([developers.kite.trade](https://developers.kite.trade/))
- API key and secret configured in `config.json`
- Sufficient margin in your trading account

---

## Configuration

All strategy parameters are in `strategy_config.json`. You can tune everything without touching code:

**Signals** -- enable/disable, adjust thresholds:
```json
"entry_signals": {
    "bb_bounce": { "enabled": true, "rsi_oversold": 50 },
    "rsi_reversal": { "enabled": true, "rsi_oversold": 30, "rsi_overbought": 70 },
    "vwap_ema_confluence": { "enabled": true, "rsi_long_max": 35, "rsi_short_min": 65 }
}
```

**Exits** -- ATR multipliers:
```json
"exits": {
    "atr_multiplier_sl": 3.0,
    "atr_multiplier_tp": 0.4,
    "trailing_activation_atr": 0.35,
    "trailing_distance_atr": 0.25
}
```

**Risk** -- position sizing and limits:
```json
"risk_management": {
    "risk_per_trade_pct": 0.01,
    "max_trades_per_day": 6,
    "max_concurrent_positions": 4,
    "max_daily_loss_pct": 0.05
}
```

---

## Tech Stack

- **Python 3.10+** -- core language
- **yfinance** -- historical and real-time market data from Yahoo Finance
- **pandas-ta** -- technical indicator calculations (RSI, Bollinger Bands, ATR, ADX, EMA)
- **pandas / numpy** -- data manipulation and numerical computation
- **kiteconnect** -- Zerodha Kite API for live order execution
- **openpyxl** -- Excel export for backtest results

---

## Important Notes

- This is an **intraday-only** strategy -- all positions are closed before market end, zero overnight risk
- The strategy trades **both long and short** positions
- **Paper trade extensively** before going live -- backtest results do not guarantee future performance
- The 63% win rate comes with small average wins and larger average losses (asymmetric stops) -- this is by design
- Market data timestamps from yfinance are in UTC; the bot converts to IST internally
- Zerodha login tokens expire daily -- you must re-authenticate each morning

---

## Disclaimer

This software is for **educational and research purposes only**. Trading in financial markets involves substantial risk of loss. Past performance (backtested or paper-traded) does not guarantee future results. Use at your own risk. The authors are not responsible for any financial losses incurred from using this software. This is not financial advice.

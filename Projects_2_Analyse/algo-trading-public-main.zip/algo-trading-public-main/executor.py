def execute_trade(api, signal, price):
    # In Simulation mode, api is None
    print(f"\n🚀 {signal} ORDER SENT @ {price}")
    if api and signal:
        # Real order logic goes here
        pass
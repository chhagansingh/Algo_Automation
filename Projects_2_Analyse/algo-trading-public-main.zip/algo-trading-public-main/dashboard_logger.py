import json
import os
import threading
from datetime import datetime
from pathlib import Path
from console_utils import safe_print as print
from database import SessionLocal, Trade, create_tables, MarketData

class DashboardLogger:
    """
    QUANTUM AI V4.0 LOGGER
    - Market Data And Trandes are stored in JSON and  Database .
    - for dashboard  'market_data.json' and 'trades.json' upgraded.
    """

    def __init__(self):
        self.lock = threading.Lock()
        self.logs_dir = Path("logs")
        self.today = datetime.now().strftime("%Y-%m-%d")
        self.today_dir = self.logs_dir / self.today
        self.trades_file = self.today_dir / "trades.json"
        self.market_file = self.today_dir / "market_data.json"
        
        # create deractory
        self._ensure_dirs()
        self._init_files()
        
        # database table create
        try:
            create_tables()
        except Exception as e:
            print(f"⚠️ Database Warning: {e}")

    def _ensure_dirs(self):
        """To check folder create."""
        if not self.today_dir.exists():
            self.today_dir.mkdir(parents=True, exist_ok=True)

    def _init_files(self):
        """create empty  JSON file."""
        if not self.trades_file.exists():
            self._write_json_direct(self.trades_file, [])

    def log_market_data(self, price, indicators=None, volume=0, **kwargs):
        """
        main engine share data to store.
        price, volume आणि indicators (RSI, VWAP) JSONL Format Save.
        """
        market_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "price": round(float(price), 2),
            "volume": int(volume),
            "indicators": indicators if indicators else {},
            "pnl": round(float(kwargs.get("pnl", 0.0)), 2),
            "signal": kwargs.get("signal", "WAIT"),
            "position": kwargs.get("position", "FLAT"),
        }

        # 1. JSONL (Append) - For Dashboard fast execution to use.
        with self.lock:
            try:
                with open(self.market_file, 'a', encoding='utf-8') as f:
                    f.write(json.dumps(market_entry) + "\n")
            except Exception as e:
                print(f"❌ Market JSON Log Error: {e}")

        # 2. SQLite Database - For Backup
        db = SessionLocal()
        try:
            new_data = MarketData(
                timestamp=datetime.utcnow(),
                price=float(price),
                rsi=market_entry['indicators'].get('rsi'),
                vwap=market_entry['indicators'].get('vwap')
            )
            db.add(new_data)
            db.commit()
        except:
            pass
        finally:
            db.close()

    def log_trade(self, entry_price, volume, signal=None, entry_type=None, stop_loss=None, target=None, ai_conf=None, reason="AI Signal", position=None):
        """
        While trade executipn store information in  JSON and DB.
        """
        # Handle both calling conventions: log_trade(signal=...) and log_trade(entry_type=...)
        _raw = entry_type or signal or "BUY"
        entry_type = "BUY" if str(_raw).upper() in ["BUY", "1"] else "SELL"
        
        trade_data = {
            'trade_id': f"TID_{datetime.now().strftime('%H%M%S')}",
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'type': entry_type,
            'entry_price': round(float(entry_price), 2),
            'volume': int(volume),
            'status': 'OPEN',
            'pnl': 0.0,
            'risk_management': {
                'stop_loss': round(float(stop_loss), 2) if stop_loss else 0,
                'target': round(float(target), 2) if target else 0
            },
            'ai_intelligence': {
                'confidence': ai_conf if ai_conf else "85%",
                'reason': reason
            }
        }
        
        # 1. JSON File Upgrade
        with self.lock:
            trades = self._read_json(self.trades_file)
            trades.append(trade_data)
            self._write_json_direct(self.trades_file, trades)
        
        # 2. Database Upgrade 
        db = SessionLocal()
        try:
            new_trade = Trade(
                timestamp=datetime.utcnow(),
                entry_price=trade_data['entry_price'],
                type=entry_type,
                volume=trade_data['volume'],
                signal=reason,
                status='OPEN',
                pnl=0.0
            )
            db.add(new_trade)
            db.commit()
        except Exception as e:
            print(f"⚠️ DB Trade Error: {e}")
        finally:
            db.close()
        
        return trade_data

    def _write_json_direct(self, file_path, data):
        """File Write."""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"❌ JSON Write Error: {e}")

    def _read_json(self, file_path):
        """To read the data inside the file for create function ."""
        if not file_path.exists():
            return []
        try:
            if file_path == self.market_file:
                # Market file read in  JSONL Format
                data = []
                with open(file_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        if line.strip():
                            data.append(json.loads(line))
                return data
            else:
                # to read trades files in form of list 
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            return []

    def get_market_data_file(self, prefer_latest=True):
        """for giving path for."""
        return self.market_file

    def get_trades_data_file(self, prefer_latest=True):
        """Return trades file path — used by quantum_terminal.py."""
        return self.trades_file

    def log_exit(self, exit_price, exit_type="MANUAL", pnl=0.0, exit_reason="MANUAL"):
        """
        Update the last OPEN trade to CLOSED with exit details.
        Called by main.py when TP/SL is hit.
        """
        with self.lock:
            trades = self._read_json(self.trades_file)
            # Find the last open trade and close it
            for trade in reversed(trades):
                if trade.get('status') == 'OPEN':
                    trade['status'] = 'CLOSED'
                    trade['exit_price'] = round(float(exit_price), 2)
                    trade['pnl'] = round(float(pnl), 2)
                    trade['exit_reason'] = exit_reason
                    trade['exit_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    break
            self._write_json_direct(self.trades_file, trades)

        # Update DB
        db = SessionLocal()
        try:
            open_trade = db.query(Trade).filter(Trade.status == 'OPEN').order_by(Trade.timestamp.desc()).first()
            if open_trade:
                open_trade.status = 'CLOSED'
                open_trade.exit_price = float(exit_price)
                open_trade.pnl = float(pnl)
                open_trade.exit_reason = exit_reason
                db.commit()
        except Exception as e:
            print(f"⚠️ DB Exit Error: {e}")
        finally:
            db.close()
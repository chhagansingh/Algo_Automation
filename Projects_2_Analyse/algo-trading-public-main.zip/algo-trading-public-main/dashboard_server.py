"""
dashboard_server.py — QUANTUM AI V4.0
=======================================
Flask server ahe.
HTML dashboard yacha kade fetch() ne data magato.

RUN:  python dashboard_server.py
PORT: http://localhost:5000
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime

try:
    from flask import Flask, jsonify
    from flask_cors import CORS
except ImportError:
    print("Installing required packages...")
    os.system(f"{sys.executable} -m pip install flask flask-cors --quiet")
    from flask import Flask, jsonify
    from flask_cors import CORS

# Config import (fallback if not available)
try:
    from config import CAPITAL, SYMBOL, MAX_DAILY_LOSS
except ImportError:
    CAPITAL = 50000
    SYMBOL = "NIFTY50"
    MAX_DAILY_LOSS = 1500

app = Flask(__name__)
CORS(app)  # HTML file la fetch() karta yete

# ── DATA PATHS ─────────────────────────────────────────────────
def get_today_dir():
    today = datetime.now().strftime("%Y-%m-%d")
    return Path("logs") / today

def read_market_jsonl(last_n=100):
    """Market data JSONL file safe read."""
    market_file = get_today_dir() / "market_data.json"
    if not market_file.exists():
        return []
    try:
        with open(market_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        data = []
        for line in lines[-last_n:]:
            line = line.strip()
            if line:
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return data
    except Exception:
        return []

def read_trades_json():
    """Trades JSON file safe read."""
    trades_file = get_today_dir() / "trades.json"
    if not trades_file.exists():
        return []
    try:
        with open(trades_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            return json.loads(content) if content else []
    except (json.JSONDecodeError, Exception):
        return []

# ── API ENDPOINT ───────────────────────────────────────────────
@app.route('/data')
def get_data():
    """
    HTML dashboard yacha sathi ek JSON endpoint.
    Response:
      {
        "ltp": 24728.5,
        "prices": [...],
        "indicators": {...},
        "trades": [...],
        "config": {...}
      }
    """
    market_data = read_market_jsonl(100)
    trades = read_trades_json()

    prices = [d['price'] for d in market_data if 'price' in d]
    ltp = prices[-1] if prices else 0.0
    indicators = market_data[-1].get('indicators', {}) if market_data else {}
    live_pnl = market_data[-1].get('pnl', 0.0) if market_data else 0.0

    return jsonify({
        "ltp": ltp,
        "prices": prices,
        "indicators": indicators,
        "trades": trades,
        "live_pnl": live_pnl,
        "config": {
            "capital": CAPITAL,
            "symbol": SYMBOL,
            "max_daily_loss": MAX_DAILY_LOSS
        },
        "server_time": datetime.now().strftime("%H:%M:%S")
    })

@app.route('/health')
def health():
    return jsonify({"status": "ok", "time": datetime.now().strftime("%H:%M:%S")})

# ── MAIN ───────────────────────────────────────────────────────
if __name__ == '__main__':
    print("=" * 55)
    print("  QUANTUM AI V4.0 — Dashboard Server")
    print("=" * 55)
    print(f"  API:       http://localhost:5000/data")
    print(f"  Health:    http://localhost:5000/health")
    print(f"  Dashboard: quantum_dashboard.html (browser madhe ughda)")
    print("=" * 55)
    print("  Main bot (main.py) pण chalu asave!")
    print("  Ctrl+C ne band kara")
    print()
    app.run(host='0.0.0.0', port=5000, debug=False)
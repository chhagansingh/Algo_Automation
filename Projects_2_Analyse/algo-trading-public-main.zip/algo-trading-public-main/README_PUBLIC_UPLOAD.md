# Public Upload Notes

This folder is a sanitized copy of the trading project prepared for a public GitHub repository.

## Before running the project locally

1. Open `config.py`
2. Replace the placeholder credentials with your local values
3. Keep real credentials out of GitHub

## Intentionally excluded from this public upload

- `trading_data.db`
- `logs/`
- `__pycache__/`
- live credentials and device identifiers

## Safety note

Use a private local copy for real trading. Treat this public repo as a code-sharing version, not the production secrets store.

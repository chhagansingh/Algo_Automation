from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime
import os
from console_utils import safe_print as print

# Database setup
DATABASE_URL = "sqlite:///trading_data.db"  # SQLite database file
engine = create_engine(
    DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False},
)  # Set echo=True for debugging
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class Trade(Base):
    """Trade table for storing all trade information"""
    __tablename__ = "trades"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    entry_time = Column(DateTime, nullable=True)
    exit_time = Column(DateTime, nullable=True)

    # Trade details
    entry_price = Column(Float, nullable=False)
    exit_price = Column(Float, nullable=True)
    type = Column(String(10), nullable=False)  # BUY/SELL
    volume = Column(Integer, nullable=False)
    signal = Column(String(100))
    position = Column(String(50))

    # Results
    pnl = Column(Float, nullable=True)
    exit_reason = Column(String(50))  # TP/SL/MANUAL
    status = Column(String(20), default="OPEN")  # OPEN/CLOSED

    # Additional data
    entry_type = Column(String(10))  # BUY/SELL (duplicate for compatibility)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    confidence = Column(Float, nullable=True)

class MarketData(Base):
    """Market data snapshots"""
    __tablename__ = "market_data"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)

    # Market data
    price = Column(Float, nullable=False)
    volume = Column(Integer, default=0)
    symbol = Column(String(20), default="NIFTY")

    # Indicators (stored as JSON string)
    indicators = Column(Text)  # JSON string of indicators

    # Trading info
    signal = Column(String(50))
    position = Column(String(50))
    pnl = Column(Float, default=0.0)

class PerformanceMetrics(Base):
    """Daily performance metrics"""
    __tablename__ = "performance_metrics"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(String(10), nullable=False)  # YYYY-MM-DD format
    timestamp = Column(DateTime, default=datetime.utcnow)

    # Trading statistics
    total_trades = Column(Integer, default=0)
    winning_trades = Column(Integer, default=0)
    losing_trades = Column(Integer, default=0)
    win_rate = Column(Float, default=0.0)
    total_pnl = Column(Float, default=0.0)
    avg_winner = Column(Float, default=0.0)
    avg_loser = Column(Float, default=0.0)
    profit_factor = Column(Float, default=0.0)
    best_trade = Column(Float, default=0.0)
    worst_trade = Column(Float, default=0.0)
    max_drawdown = Column(Float, default=0.0)

    # Capital and risk
    capital = Column(Float, default=50000.0)
    risk_per_trade = Column(Float, default=1000.0)

class SystemLogs(Base):
    """System logs and errors"""
    __tablename__ = "system_logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String(20), default="INFO")  # INFO/WARNING/ERROR
    module = Column(String(50))
    message = Column(Text)
    data = Column(Text)  # Additional JSON data

# Create all tables
def create_tables():
    """Create all database tables"""
    Base.metadata.create_all(bind=engine)
    print("Database tables created successfully.")

# Database session management
def get_db():
    """Get database session"""
    return SessionLocal()

# Utility functions
def init_database():
    """Initialize database and create tables"""
    db_exists = os.path.exists("trading_data.db")
    create_tables()

    # Create database file if it doesn't exist
    if not db_exists:
        print("Database file created: trading_data.db")

if __name__ == "__main__":
    init_database()

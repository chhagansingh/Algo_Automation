import json
import pandas as pd
from pathlib import Path

class TradeStats:
    def __init__(self, trades_file="trades.json"):
        self.trades_file = Path(trades_file)

    def calculate_stats(self):
        """
        Calculates trading metrics and returns all required keys 
        to avoid KeyError.
        """
        # डिफॉल्ट व्हॅल्यूज - जेणेकरून कोणतीही Key मिसिंग राहणार नाही
        stats = {
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "win_rate": 0.0,
            "total_pnl": 0.0,
            "max_drawdown": 0.0
        }

        if not self.trades_file.exists():
            return stats

        try:
            with open(self.trades_file, 'r') as f:
                trades = json.load(f)
            
            if not trades:
                return stats

            df = pd.DataFrame(trades)
            
            if 'status' not in df.columns or 'pnl' not in df.columns:
                return stats

            closed_trades = df[df['status'] == 'CLOSED']

            if closed_trades.empty:
                return stats

            # calculations
            stats["total_trades"] = len(closed_trades)
            stats["winning_trades"] = len(closed_trades[closed_trades['pnl'] > 0])
            stats["losing_trades"] = len(closed_trades[closed_trades['pnl'] <= 0])
            stats["total_pnl"] = float(closed_trades['pnl'].sum())
            
            if stats["total_trades"] > 0:
                stats["win_rate"] = float((stats["winning_trades"] / stats["total_trades"]) * 100)

            return stats

        except Exception as e:
            print(f"Error: {e}")
            return stats
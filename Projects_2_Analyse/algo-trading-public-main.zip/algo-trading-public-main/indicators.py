import pandas as pd
import numpy as np
from scipy.stats import norm

def ema(data, period):
    """Exponential Moving Average"""
    if len(data) < period:
        return data
    return data.ewm(span=period, adjust=False).mean()

def rsi(data, period=14):
    """Relative Strength Index"""
    if len(data) < period:
        return pd.Series([50] * len(data))

    delta = data.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    
    rs = gain / loss.replace(0, np.nan) 
    rsi_val = 100 - (100 / (1 + rs))
    return rsi_val.fillna(50)

def get_vwap(df):
    """Volume Weighted Average Price """
    if 'close' not in df.columns or 'volume' not in df.columns:
        return pd.Series([0.0] * len(df))

    cumulative_volume = df['volume'].cumsum().replace(0, np.nan)
    vwap = (df['close'] * df['volume']).cumsum() / cumulative_volume
    return vwap.fillna(df['close'])

def get_atr(df, period=14):
    """Average True Range """
    required_columns = {'high', 'low', 'close'}
    if not required_columns.issubset(df.columns):
        return pd.Series([0.0] * len(df))

    high_low = (df['high'] - df['low']).abs()
    high_close = (df['high'] - df['close'].shift(1)).abs()
    low_close = (df['low'] - df['close'].shift(1)).abs()
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    atr = true_range.rolling(window=period, min_periods=1).mean()
    return atr.fillna(0.0)

def identify_candle_pattern(df):
    """(Price Action)"""
    if len(df) < 2: return None
    
    last = df.iloc[-1]
    prev = df.iloc[-2]
    
    body = abs(last['close'] - last['open'])
    upper_shadow = last['high'] - max(last['close'], last['open'])
    lower_shadow = min(last['close'], last['open']) - last['low']
    total_range = last['high'] - last['low']

    # १. Bullish Hammer 
    if lower_shadow > (2 * body) and upper_shadow < (0.2 * total_range) and total_range > 0:
        return "HAMMER_BULLISH"

    # २. Shooting Star 
    if upper_shadow > (2 * body) and lower_shadow < (0.2 * total_range) and total_range > 0:
        return "SHOOTING_STAR_BEARISH"

    # ३. Bullish Engulfing 
    if last['close'] > last['open'] and prev['close'] < prev['open'] and \
       last['close'] > prev['open'] and last['open'] < prev['close']:
        return "ENGULFING_BULLISH"

    return None

def calculate_options_greeks(S=None, K=None, T=None, r=None, sigma=None, option_type="CALL", **aliases):
    """
    (Black-Scholes Model)
    S: nifty current price
    K: strike price
    T: time to expiration (in years)
    r: (Risk-free rate - 0.07)
    sigma: (IV)
    """
    S = aliases.get("underlying_price", S)
    K = aliases.get("strike_price", K)
    T = aliases.get("time_to_expiry", T)
    r = aliases.get("risk_free_rate", r)
    sigma = aliases.get("volatility", sigma)

    if None in (S, K, T, r, sigma) or T <= 0 or sigma <= 0:
        return {"delta": 0.0, "gamma": 0.0, "theta": 0.0, "vega": 0.0}

    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)

    if option_type.upper() == "CALL":
        delta = norm.cdf(d1)
        theta = -(S * norm.pdf(d1) * sigma / (2 * np.sqrt(T))) - r * K * np.exp(-r * T) * norm.cdf(d2)
    else:
        delta = norm.cdf(d1) - 1
        theta = -(S * norm.pdf(d1) * sigma / (2 * np.sqrt(T))) + r * K * np.exp(-r * T) * norm.cdf(-d2)

    gamma = norm.pdf(d1) / (S * sigma * np.sqrt(T))
    vega = S * norm.pdf(d1) * np.sqrt(T)

    return {
        "delta": round(float(delta), 3),
        "gamma": round(float(gamma), 5),
        "theta": round(float(theta / 365), 2),
        "vega": round(float(vega), 2),
    }
import sys
def safe_print(*args, sep=" ", end="\n", file=None, flush=False):
    """Write console output without crashing on Windows encoding limits."""
    stream = file or sys.stdout
    text = sep.join(str(arg) for arg in args) + end
    encoding = getattr(stream, "encoding", None) or "utf-8"
    safe_text = text.encode(encoding, errors="replace").decode(encoding, errors="replace")
    stream.write(safe_text)
    if flush and hasattr(stream, "flush"):
        stream.flush()
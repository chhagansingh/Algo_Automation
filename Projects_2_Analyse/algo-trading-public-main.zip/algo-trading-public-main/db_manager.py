#!/usr/bin/env python3
"""
Database Management Script
Provides utilities for managing the trading database
"""

import argparse
from datetime import datetime, timedelta
from database import (
    SessionLocal, Trade, MarketData, PerformanceMetrics, SystemLogs,
    init_database, get_db, create_tables
)
from dashboard_logger import DashboardLogger

def show_stats():
    """Show database statistics"""
    print("📊 Database Statistics")
    print("=" * 50)

    db = get_db()

    try:
        # Count records
        trade_count = db.query(Trade).count()
        market_count = db.query(MarketData).count()
        metrics_count = db.query(PerformanceMetrics).count()
        logs_count = db.query(SystemLogs).count()

        print(f"📈 Trades: {trade_count}")
        print(f"📊 Market Data: {market_count}")
        print(f"📋 Performance Metrics: {metrics_count}")
        print(f"📝 System Logs: {logs_count}")

        # Show recent activity
        if trade_count > 0:
            print("\n🏛️ Recent Trading Activity:")
            recent_trades = db.query(Trade).order_by(Trade.timestamp.desc()).limit(5).all()
            for trade in recent_trades:
                pnl_str = f"₹{trade.pnl}" if trade.pnl else "Open"
                print(f"  • {trade.timestamp.strftime('%H:%M:%S')} | {trade.type} @ ₹{trade.entry_price} | {trade.status} | P&L: {pnl_str}")

        # Show today's P&L
        today = datetime.now().strftime("%Y-%m-%d")
        today_trades = db.query(Trade).filter(
            Trade.status == 'CLOSED',
            Trade.timestamp >= today + ' 00:00:00'
        ).all()

        if today_trades:
            total_pnl = sum(trade.pnl for trade in today_trades if trade.pnl)
            print(f"\n💰 Today's P&L: ₹{total_pnl:.2f}")

    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        db.close()

def clear_old_data(days=30):
    """Clear data older than specified days"""
    print(f"🧹 Clearing data older than {days} days...")

    cutoff_date = datetime.now() - timedelta(days=days)
    db = get_db()

    try:
        # Delete old trades
        old_trades = db.query(Trade).filter(Trade.timestamp < cutoff_date).delete()
        print(f"  • Deleted {old_trades} old trades")

        # Delete old market data
        old_market = db.query(MarketData).filter(MarketData.timestamp < cutoff_date).delete()
        print(f"  • Deleted {old_market} old market data records")

        # Delete old logs
        old_logs = db.query(SystemLogs).filter(SystemLogs.timestamp < cutoff_date).delete()
        print(f"  • Deleted {old_logs} old system logs")

        db.commit()
        print("✅ Cleanup completed!")

    except Exception as e:
        print(f"❌ Error during cleanup: {e}")
        db.rollback()
    finally:
        db.close()

def export_data(filename=None):
    """Export database data to JSON"""
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"database_export_{timestamp}.json"

    print(f"📤 Exporting database to {filename}...")

    db = get_db()
    data = {}

    try:
        # Export all tables
        data['trades'] = [
            {
                'id': t.id,
                'timestamp': t.timestamp.isoformat(),
                'entry_price': t.entry_price,
                'exit_price': t.exit_price,
                'type': t.type,
                'volume': t.volume,
                'signal': t.signal,
                'pnl': t.pnl,
                'status': t.status
            } for t in db.query(Trade).all()
        ]

        data['market_data'] = [
            {
                'id': m.id,
                'timestamp': m.timestamp.isoformat(),
                'price': m.price,
                'volume': m.volume,
                'signal': m.signal,
                'pnl': m.pnl
            } for m in db.query(MarketData).all()
        ]

        import json
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

        print(f"✅ Exported {len(data['trades'])} trades and {len(data['market_data'])} market records")

    except Exception as e:
        print(f"❌ Export failed: {e}")
    finally:
        db.close()

def reset_database():
    """Reset the entire database (WARNING: This deletes all data!)"""
    confirm = input("⚠️  WARNING: This will delete ALL database data! Type 'YES' to confirm: ")
    if confirm != 'YES':
        print("❌ Operation cancelled")
        return

    print("🔄 Resetting database...")

    db = get_db()
    try:
        # Drop all tables
        Trade.__table__.drop(db.bind, checkfirst=True)
        MarketData.__table__.drop(db.bind, checkfirst=True)
        PerformanceMetrics.__table__.drop(db.bind, checkfirst=True)
        SystemLogs.__table__.drop(db.bind, checkfirst=True)

        # Recreate tables
        create_tables()

        print("✅ Database reset completed!")

    except Exception as e:
        print(f"❌ Reset failed: {e}")
    finally:
        db.close()

def main():
    parser = argparse.ArgumentParser(description="Database Management for Trading System")
    parser.add_argument('action', choices=['stats', 'clear', 'export', 'reset'],
     help='Action to perform')
    parser.add_argument('--days', type=int, default=30,
    help='Days of data to keep (for clear action)')
    parser.add_argument('--file', type=str,
    help='Export filename')

    args = parser.parse_args()

    if args.action == 'stats':
        show_stats()
    elif args.action == 'clear':
        clear_old_data(args.days)
    elif args.action == 'export':
        export_data(args.file)
    elif args.action == 'reset':
        reset_database()

if __name__ == "__main__":
    print("🗄️  Trading Database Manager")
    print("=" * 50)

    # Initialize database if needed
    init_database()

    main()
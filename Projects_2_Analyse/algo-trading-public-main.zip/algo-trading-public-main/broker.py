def place_order(signal, price):
    if signal == "BUY":
        print("📈 BUY ORDER @", price)

    elif signal == "SELL":
        print("📉 SELL ORDER @", price)
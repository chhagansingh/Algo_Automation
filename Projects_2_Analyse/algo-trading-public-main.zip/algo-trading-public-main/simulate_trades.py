# simulate_trades.py - FINAL WORKING VERSION

import json
import random
from pathlib import Path
from datetime import datetime, timedelta


def simulate_trades(num_trades=15):
    """Generate realistic sample trades for dashboard testing."""

    # Create today's log folder
    today = datetime.now().strftime("%Y-%m-%d")
    trades_dir = Path("logs") / today
    trades_dir.mkdir(parents=True, exist_ok=True)

    trades_file = trades_dir / "trades.json"

    base_price = random.randint(23950, 24150)
    lot_size = 75
    trades = []

    # Generate Trades
    for i in range(num_trades):
        entry_time = datetime.now() - timedelta(hours=num_trades - i)
        trade_type = random.choice(["BUY", "SELL"])

        entry_price = base_price + random.randint(-100, 100)
        is_win = random.choice([True, False])

        if trade_type == "BUY":
            move = random.randint(50, 200)
            exit_price = entry_price + move if is_win else entry_price - move
        else:
            move = random.randint(50, 200)
            exit_price = entry_price - move if is_win else entry_price + move

        pnl = (
            (exit_price - entry_price) * lot_size
            if trade_type == "BUY"
            else (entry_price - exit_price) * lot_size
        )

        exit_time = entry_time + timedelta(
            minutes=random.randint(15, 120)
        )

        trade = {
            "timestamp": entry_time.isoformat(),
            "entry_price": round(entry_price, 2),
            "type": trade_type,
            "volume": lot_size,
            "signal": "AI_SIGNAL",
            "position": "LONG" if trade_type == "BUY" else "SHORT",
            "status": "CLOSED",
            "exit_price": round(exit_price, 2),
            "exit_time": exit_time.isoformat(),
            "pnl": round(pnl, 2),
            "exit_reason": "TP" if pnl > 0 else "SL"
        }

        trades.append(trade)

    # Save trades
    with open(trades_file, "w", encoding="utf-8") as f:
        json.dump(trades, f, indent=4)

    print(f"\n✅ Simulated {num_trades} trades saved to:")
    print(f"📁 {trades_file}")

    # ==========================================================
    # Statistics
    # ==========================================================
    winning_trades = [t for t in trades if t["pnl"] > 0]
    losing_trades = [t for t in trades if t["pnl"] < 0]

    total_trades = len(trades)
    winning_count = len(winning_trades)
    losing_count = len(losing_trades)

    total_pnl = sum(t["pnl"] for t in trades)

    avg_win = (
        sum(t["pnl"] for t in winning_trades) / winning_count
        if winning_count else 0
    )

    avg_loss = (
        abs(sum(t["pnl"] for t in losing_trades)) / losing_count
        if losing_count else 0
    )

    gross_profit = sum(t["pnl"] for t in winning_trades)
    gross_loss = abs(sum(t["pnl"] for t in losing_trades))

    profit_factor = (
        gross_profit / gross_loss
        if gross_loss > 0 else float("inf")
    )

    best_trade = max(t["pnl"] for t in trades)
    worst_trade = min(t["pnl"] for t in trades)

    # Maximum Drawdown
    equity = 0
    peak = 0
    max_drawdown = 0

    for trade in trades:
        equity += trade["pnl"]
        peak = max(peak, equity)
        drawdown = peak - equity
        max_drawdown = max(max_drawdown, drawdown)

    win_rate = (
        (winning_count / total_trades) * 100
        if total_trades else 0
    )

    stats = {
        "total_trades": total_trades,
        "winning_trades": winning_count,
        "losing_trades": losing_count,
        "win_rate": round(win_rate, 2),
        "total_pnl": round(total_pnl, 2),
        "avg_win": round(avg_win, 2),
        "avg_loss": round(avg_loss, 2),
        "profit_factor": round(profit_factor, 2),
        "best_trade": round(best_trade, 2),
        "worst_trade": round(worst_trade, 2),
        "max_drawdown": round(max_drawdown, 2)
    }

    # Print Statistics
    print("\n📊 SIMULATED TRADE STATISTICS")
    print("=" * 50)
    print(f"├─ Total Trades   : {stats['total_trades']}")
    print(f"├─ Winning Trades : {stats['winning_trades']}")
    print(f"├─ Losing Trades  : {stats['losing_trades']}")
    print(f"├─ Win Rate       : {stats['win_rate']:.2f}%")
    print(f"├─ Total P&L      : ₹{stats['total_pnl']:.2f}")
    print(f"├─ Avg Win        : ₹{stats['avg_win']:.2f}")
    print(f"├─ Avg Loss       : ₹{stats['avg_loss']:.2f}")
    print(f"├─ Profit Factor  : {stats['profit_factor']:.2f}")
    print(f"├─ Best Trade     : ₹{stats['best_trade']:.2f}")
    print(f"├─ Worst Trade    : ₹{stats['worst_trade']:.2f}")
    print(f"└─ Max Drawdown   : ₹{stats['max_drawdown']:.2f}")

    return stats


if __name__ == "__main__":
    print("🎯 Generating simulated trades...\n")
    simulate_trades(15)
    print("\n✅ Dashboard data ready!")
    print("🚀 Run: streamlit run dashboard.py")
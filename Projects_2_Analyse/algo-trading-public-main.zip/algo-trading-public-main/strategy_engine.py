# strategy_engine.py - Fixed Version
from indicators import calculate_options_greeks, ema, rsi, get_vwap, get_atr, identify_candle_pattern
import pandas as pd
from config import *

class StrategyEngine:
    def __init__(self):
        self.prices = []
        self.volumes = []
        self.opens = []   
        self.highs = []   
        self.lows = []    
        self.position = None
        self.entry_price = 0
        self.stop_loss = 0
        self.take_profit = 0
        self.total_daily_pnl = 0.0

    def _trim_history(self):
        if len(self.prices) > 500:
            for arr in [self.prices, self.volumes, self.opens, self.highs, self.lows]:
                arr.pop(0)

    def _market_frame(self):
        if not self.prices:
            return pd.DataFrame(columns=['open', 'high', 'low', 'close', 'volume'])

        return pd.DataFrame({
            'open': self.opens,
            'high': self.highs,
            'low': self.lows,
            'close': self.prices,
            'volume': self.volumes
        })

    def _last_value(self, series, default=0.0):
        if len(series) == 0:
            return default

        value = series.iloc[-1] if hasattr(series, "iloc") else series[-1]
        return default if pd.isna(value) else float(value)

    def update_market_data(self, price, volume, open_p=None, high_p=None, low_p=None):
        self.prices.append(price)
        self.volumes.append(volume)
        self.opens.append(open_p if open_p is not None else price)
        self.highs.append(high_p if high_p is not None else price)
        self.lows.append(low_p if low_p is not None else price)
        self._trim_history()

    def get_indicator_snapshot(self):
        df = self._market_frame()
        if df.empty:
            return {}

        last_close = self._last_value(df['close'])
        ema_9 = ema(df['close'], 9)
        ema_12 = ema(df['close'], 12)
        ema_20 = ema(df['close'], 20)
        ema_26 = ema(df['close'], 26)
        rsi_series = rsi(df['close'])
        vwap_series = get_vwap(df)
        atr_series = get_atr(df)

        macd_value = self._last_value(ema_12) - self._last_value(ema_26)

        return {
            'open': round(self._last_value(df['open'], last_close), 2),
            'high': round(self._last_value(df['high']), 2),
            'low': round(self._last_value(df['low']), 2),
            'volume': int(self._last_value(df['volume'], 0)),
            'ema_9': round(self._last_value(ema_9), 2),
            'ema_20': round(self._last_value(ema_20), 2),
            'rsi': round(self._last_value(rsi_series, 50.0), 2),
            'vwap': round(self._last_value(vwap_series), 2),
            'atr': round(self._last_value(atr_series), 2),
            'macd': round(macd_value, 2),
        }

    def check_exits(self, price):
                                                
        if self.position == "BUY":
            if price <= self.stop_loss: return "EXIT_SL"
            if price >= self.take_profit: return "EXIT_TP"
        elif self.position == "SELL":
            if price >= self.stop_loss: return "EXIT_SL"
            if price <= self.take_profit: return "EXIT_TP"
        return None

    def analyze(self, price, volume, ai_agent, open_p=None, high_p=None, low_p=None, market_already_recorded=False):
        # 1. Kill Switch
        if self.total_daily_pnl <= MAX_DAILY_LOSS:
            return "STOP_TRADING_DAILY_LOSS_LIMIT"

        # 2. Update Data (OHLC Data)
        if not market_already_recorded:
            self.update_market_data(price, volume, open_p=open_p, high_p=high_p, low_p=low_p)

        # 3. Check for Exits
        if self.position:
            # Trailing SL logic
            if self.position == "BUY" and price >= self.entry_price + TRAILING_STOP_LOSS_TRIGGER:
                self.stop_loss = max(self.stop_loss, self.entry_price)
            elif self.position == "SELL" and price <= self.entry_price - TRAILING_STOP_LOSS_TRIGGER:
                self.stop_loss = min(self.stop_loss, self.entry_price)

            exit_signal = self.check_exits(price)
            if exit_signal:
                return exit_signal
            return None

        # 4. Entry Logic
        else:
            df = self._market_frame()
            if len(df) < 30: return None
            
            vwap_val = self._last_value(get_vwap(df), price)
            rsi_val = self._last_value(rsi(df['close']), 50.0)
            pattern = identify_candle_pattern(df)
            
            side = None
            if price > vwap_val and rsi_val > 50:
                if pattern in ["HAMMER_BULLISH", "ENGULFING_BULLISH"]:
                    side = "BUY"
                elif rsi_val > 60: 
                    side = "BUY"

            elif price < vwap_val and rsi_val < 50:
                if pattern == "SHOOTING_STAR_BEARISH":
                    side = "SELL"
                elif rsi_val < 40:
                    side = "SELL"

            if not side: return None

            # --- Accuracy Fillter: Option Greeks ---
            iv_current = 0.18
            strike_price = round(price / 50) * 50
            greeks = calculate_options_greeks(
                underlying_price=price,
                strike_price=strike_price,
                time_to_expiry=0.1,
                volatility=iv_current,
                risk_free_rate=0.05,
                option_type="CALL" if side == "BUY" else "PUT",
            )
            if side == "BUY" and greeks['delta'] > 0.5 and greeks['vega'] > 0.1:
                return f"AI_{side} : Strong Buy Signal with Delta {greeks['delta']:.2f} and Vega {greeks['vega']:.2f}"
            elif side == "SELL" and greeks['delta'] < -0.5 and greeks['vega'] > 0.1:
                return f"AI_{side} : Strong Sell Signal with Delta {greeks['delta']:.2f} and Vega {greeks['vega']:.2f}"
            return None
            

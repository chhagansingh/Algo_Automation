import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
import os
import time
from datetime import datetime
from ai_engine import AIAgent
from dashboard_logger import DashboardLogger
from config import CAPITAL, SYMBOL

# Auto-refresh every 2 seconds using meta-refresh trick
REFRESH_INTERVAL_MS = 2000

# ================= PAGE CONFIG =================
st.set_page_config(page_title="QUANTUM TERMINAL | Institutional", layout="wide", page_icon="📈")

# Professional Custom CSS for Dark Mode & Metrics
st.markdown("""
<style>
    .main { background-color: #0d1117; color: #c9d1d9; }
    .stMetric { background-color: #161b22; padding: 15px; border-radius: 10px; border: 1px solid #30363d; }
    .ai-card { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding: 20px; border-radius: 12px; border-left: 5px solid #3b82f6; margin-bottom: 20px; }
    .status-live { color: #238636; font-weight: bold; animation: blinker 1.5s linear infinite; }
    @keyframes blinker { 50% { opacity: 0; } }
</style>
""", unsafe_allow_html=True)

# ================= DATA ENGINES =================
@st.cache_resource
def init_system():
    return AIAgent(), DashboardLogger()

ai_analyst, logger = init_system()

def load_live_market_data():
    prices, volumes, rsi_vals, times = [], [], [], []
    latest_indicators = {}
    
    market_file = logger.get_market_data_file(prefer_latest=True)
    if os.path.exists(market_file):
        with open(market_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()[-60:] # last 60 ticks (  Live feel )
            for line in lines:
                try:
                    d = json.loads(line)
                    prices.append(d['price'])
                    volumes.append(d['volume'])
                    times.append(datetime.now().strftime("%H:%M:%S"))
                    latest_indicators = d.get('indicators', {})
                    if 'rsi' in latest_indicators: rsi_vals.append(latest_indicators['rsi'])
                except: continue
    return prices, volumes, rsi_vals, times, latest_indicators

# ================= SIDEBAR & CONTROLS =================
with st.sidebar:
    st.title("🛡️ System Control")
    st.markdown(f"Status: <span class='status-live'>● LIVE INTERFACE</span>", unsafe_allow_html=True)
    st.divider()
    st.metric("Total Bankroll", f"₹{CAPITAL:,.2f}")
    st.divider()
    if st.button("🔍 Trigger AI Market Scan", use_container_width=True):
        st.session_state.run_scan = True

# ================= MAIN TERMINAL =================
# Live Market Data Load
prices, volumes, rsis, times, current_ind = load_live_market_data()
ltp = prices[-1] if prices else 0.0

# १. TOP ROW: CRITICAL METRICS
col1, col2, col3, col4 = st.columns(4)

# Open Trades Analysis
trades = logger._read_json(logger.get_trades_data_file(prefer_latest=True))
open_pos = [t for t in trades if t.get('status') == 'OPEN']

# P&L Calculation
unrealized_pnl = sum([
    (ltp - p['entry_price']) if (p.get('entry_type') or p.get('type') or 'BUY') == 'BUY' else (p['entry_price'] - ltp)
    for p in open_pos
])

col1.metric("Live Index Price", f"₹{ltp:,.2f}")
col2.metric("Total Unrealized P&L", f"₹{unrealized_pnl:,.2f}", delta=f"{unrealized_pnl:.2f}")
col3.metric("Active Positions", len(open_pos))
col4.metric("Market Sentiment", "BULLISH" if ltp > current_ind.get('ema_20', 0) else "BEARISH")

st.divider()

# २. MIDDLE ROW: ADVANCED CHARTING
c1, c2 = st.columns([2, 1])

with c1:
    st.subheader("💹 Institutional Price Action")
    if prices:
        fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05, row_heights=[0.7, 0.3])
        
        # Price Line
        fig.add_trace(go.Scatter(x=times, y=prices, name="Price", line=dict(color='#3b82f6', width=3), fill='tozeroy'), row=1, col=1)
        # EMA 20 Overlay    
        if 'ema_20' in current_ind:
            fig.add_trace(go.Scatter(x=times, y=[current_ind['ema_20']]*len(times), name="EMA 20", line=dict(color='#f59e0b', dash='dot')), row=1, col=1)
            
        # Volume Bars
        fig.add_trace(go.Bar(x=times, y=volumes, name="Volume", marker_color='#1e293b'), row=2, col=1)
        
        fig.update_layout(height=500, template="plotly_dark", showlegend=False, margin=dict(l=0,r=0,t=0,b=0))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Data Feed शोधत आहे... कृपया main.py चालू असल्याची खात्री करा.")

with c2:
    st.subheader("🧪 Real-time Quant Stats")
    st.write(f"**RSI (14):** {current_ind.get('rsi', 0):.2f}")
    st.progress(min(max(current_ind.get('rsi', 50)/100, 0.0), 1.0))
    
    st.write(f"**VWAP:** ₹{current_ind.get('vwap', 0):,.2f}")
    st.write(f"**ATR (Volatility):** {current_ind.get('atr', 0):.2f}")
    
    # Position Table
    if open_pos:
        st.write("**Open Trades:**")
        df_pos = pd.DataFrame(open_pos)
        if 'entry_type' not in df_pos.columns and 'type' in df_pos.columns:
            df_pos['entry_type'] = df_pos['type']
        st.table(df_pos[['entry_type', 'entry_price', 'signal']])

st.divider()

# ३. BOTTOM ROW: AI RECOMMENDATIONS
st.subheader("🎯 AI Strategic Recommendations")

if st.session_state.get('run_scan'):
    with st.spinner("Generating AI Trade Recommendations..."):
        # Context for AI: Current Market + Account State
        market_ctx = {"price": ltp, "indicators": current_ind}
        account_ctx = {"capital": CAPITAL, "open_trades": len(open_pos)}
        
        recs = ai_analyst.generate_trade_recommendations(market_ctx, account_ctx)
        
        r_col1, r_col2 = st.columns(2)
        for i, rec in enumerate(recs):
            target_col = r_col1 if i % 2 == 0 else r_col2
            with target_col:
                st.markdown(f"""
                <div class="ai-card">
                    <h3 style="margin:0; color:#60a5fa;">{rec.get('setup', 'Strategic Setup')}</h3>
                    <p>Confidence: <b>{rec.get('confidence')}%</b> | Side: <b>{rec.get('side')}</b></p>
                    <p style="font-size:14px;">Logic: {rec.get('reason')}</p>
                    <table style="width:100%; border-top:1px solid #334155;">
                        <tr>
                            <td><b>Entry:</b> {rec.get('entry')}</td>
                            <td><b>Target:</b> {rec.get('take_profit')}</td>
                            <td><b>SL:</b> {rec.get('stop_loss')}</td>
                        </tr>
                    </table>
                </div>
                """, unsafe_allow_html=True)

# Auto Refresh Logic (2 second interval — no blocking sleep)
st.markdown(
    f'<meta http-equiv="refresh" content="2">',
    unsafe_allow_html=True
)
import time
from data_feed import DataEngine
from strategy_engine import StrategyEngine
from ai_engine import AIAgent 
from executor import execute_trade
from dashboard_logger import DashboardLogger
from console_utils import safe_print as print

def calculate_trade_pnl(position, entry_price, exit_price):
    if position == "BUY": return round(exit_price - entry_price, 2)
    if position == "SELL": return round(entry_price - exit_price, 2)
    return 0.0

def run():
    feed = DataEngine()
    brain = StrategyEngine()
    ai_analyst = AIAgent() 
    logger = DashboardLogger()
    feed.start()

    print("--- QUANTUM AI V4.0 | CORE EXECUTION ONLINE ---")
    
    # Initial Setup
    initial_price = float(feed.current_price or 0)
    current_candle_open = current_candle_high = current_candle_low = initial_price
    tick_count = 0
    last_tick_time = time.time()

    while True:
        try:
            event_signal = "WAIT"
            
            # 1. Real-time Data Fetching
            try:
                data = feed.data_queue.get(timeout=2)
                price = float(data['price'])
                volume = int(data.get('volume', 0) or 0)
                feed.current_price = price
                last_tick_time = time.time()
            except Exception:
                price = float(feed.current_price or initial_price)
                volume = 0

            # 2. Candle Tracking & Momentum Detection
            current_candle_high = max(current_candle_high, price)
            current_candle_low = min(current_candle_low, price)
            atr_val = abs(current_candle_high - current_candle_low)
            is_momentum = atr_val > (price * 0.0015) # ATR-based momentum trigger

            # 3. Indicator & AI Analytics Snapshot
            brain.update_market_data(price, volume, current_candle_open, current_candle_high, current_candle_low)
            indicator_snapshot = brain.get_indicator_snapshot()
            
            # Injection of Quantum Metrics for Dashboard
            greeks = ai_analyst.calculate_greeks(S=price, K=round(price, -2), T=0.01, r=0.07, sigma=0.15)
            structure = ai_analyst.detect_market_structure(current_candle_high, current_candle_low, price)
            
            indicator_snapshot.update({
            "atr": round(abs(current_candle_high - current_candle_low), 2),
             "structure": "BOS_BULLISH" if price > current_candle_high else "CONSOLIDATION",
             "ai_score": 50 + (ai_analyst.institutional_bias_score() * 50)
            })

            # 4. Trailing Stop-Loss Logic (Smart Trailing)
            if brain.position is not None:
                is_auto_exit = False
                exit_reason = ""

                # Trail to Breakeven + Lock Profits
                profit_points = (price - brain.entry_price) if brain.position == "BUY" else (brain.entry_price - price)
                
                if profit_points >= 15: # 15 points target achieved, lock 10 points
                    new_sl = price - 5 if brain.position == "BUY" else price + 5
                    if (brain.position == "BUY" and new_sl > brain.stop_loss) or (brain.position == "SELL" and new_sl < brain.stop_loss):
                        brain.stop_loss = new_sl

                # Exit Condition Check
                if brain.position == "BUY":
                    if price >= brain.take_profit: is_auto_exit, exit_reason = True, "TP"
                    elif price <= brain.stop_loss: is_auto_exit, exit_reason = True, "SL"
                elif brain.position == "SELL":
                    if price <= brain.take_profit: is_auto_exit, exit_reason = True, "TP"
                    elif price >= brain.stop_loss: is_auto_exit, exit_reason = True, "SL"
                
                if is_auto_exit:
                    execute_trade(None, f"EXIT_{brain.position}", price)
                    trade_pnl = calculate_trade_pnl(brain.position, brain.entry_price, price)
                    brain.total_daily_pnl += trade_pnl
                    logger.log_exit(exit_price=price, exit_type=exit_reason, pnl=trade_pnl, exit_reason=exit_reason)
                    brain.position = None
                    event_signal = f"EXIT_{exit_reason}"

            # 5. AI Strategy & Entry (SMC + Momentum Mode)
            tick_count += 1
            if tick_count >= 150: # Faster Analysis (Approx 2.5 min)
                # Fetch AI Recommendations with Momentum Context
                market_snap = ai_analyst.format_market_snapshot(price, indicator_snapshot.get('rsi', 50), 
                indicator_snapshot.get('vwap', price), 
                atr_val, price-50, price+50)
                
                setups = ai_analyst.generate_trade_recommendations(market_snap, {"capital": 100000})
                
                if setups and brain.position is None:
                    setup = setups[0]
                    # Momentum check: Lower confidence barrier if market is moving fast
                    min_conf = 75 if is_momentum else 85
                    
                    if setup['confidence'] >= min_conf:
                        action_side = setup['side']
                        execute_trade(None, action_side, price)
                        brain.position, brain.entry_price = action_side, price
                        brain.stop_loss = setup['stop_loss']
                        brain.take_profit = setup['take_profit']
                        
                        logger.log_trade(entry_price=price, entry_type=action_side, volume=volume, 
                        signal=setup['setup'], position=action_side)
                        print(f"\n[AI ENTRY] {action_side} @ {price} | SL: {brain.stop_loss} | TP: {brain.take_profit}")

                current_candle_open, current_candle_high, current_candle_low = price, price, price
                tick_count = 0

            # 6. Logging for Dashboard
            logger.log_market_data(
                price=price, volume=volume, signal=event_signal,
                position=brain.position or "FLAT", pnl=brain.total_daily_pnl,
                indicators=indicator_snapshot
            )

            print(f"NIFTY: {price:.2f} | P&L: {brain.total_daily_pnl:.2f} | Mode: {'MOMENTUM' if is_momentum else 'NORMAL'}", end="\r")

        except Exception as exc:
            print(f"\nSystem Error: {exc}")
            time.sleep(1)

if __name__ == "__main__":
    run()
# data_feed.py
import threading, queue, time, random, pyotp
from SmartApi import SmartConnect
from SmartApi.smartWebSocketV2 import SmartWebSocketV2
from config import *
from console_utils import safe_print as print

class DataEngine:
    def __init__(self):
        self.data_queue = queue.Queue()
        self.api = SmartConnect(api_key=API_KEY)
        self.auth_token = None
        self.feed_token = None
        self.live_session_ready = False
        self.current_price = 24000.0

    def login(self):
        try:
            totp = pyotp.TOTP(TOTP_SECRET).now()
            res = self.api.generateSession(CLIENT_ID, PASSWORD, totp)
            if res['status']:
                self.auth_token = res['data']['jwtToken']
                self.feed_token = res['data']['feedToken']
                return True
        except Exception:
            return False
        return False

    def get_real_market_price(self):
        try:
            resp = self.api.ltpData("NSE", "NIFTY-EQ", TOKEN)
            return resp['data']['ltp'] if resp['status'] else 24000.0
        except Exception:
            return 24000.0

    def get_market_price(self):
        return self.get_real_market_price()

    def start(self):
        if LIVE_MARKET_MODE:
            threading.Thread(target=self._start_live_feed, daemon=True).start()
        else:
            threading.Thread(target=self._simulate_data, daemon=True).start()

    def _start_live_feed(self):
        self.live_session_ready = self.login()
        if self.live_session_ready and self.auth_token and self.feed_token:
            live_price = self.get_real_market_price()
            if live_price:
                self.current_price = live_price
            self._connect_live_websocket()
            return

        print("Live login unavailable. Falling back to simulated market feed.")
        self._simulate_data()

    def _simulate_data(self):
        while True:
            self.current_price += random.uniform(-1.5, 1.5)
            vol = random.randint(1000, 5000)
            self.data_queue.put({'price': round(self.current_price, 2), 'volume': vol})
            time.sleep(1.0)

    def _connect_live_websocket(self):
        try:
            sws = SmartWebSocketV2(self.auth_token, API_KEY, CLIENT_ID, self.feed_token)

            def on_data(ws, msg):
                if 'last_traded_price' in msg:
                    ltp = msg['last_traded_price'] / 100.0
                    vol = msg.get('volume_traded_today', 0)
                    self.current_price = ltp
                    self.data_queue.put({'price': ltp, 'volume': vol})

            def on_open(ws):
                print("WebSocket connected. Subscribing to NIFTY...")
                correlation_id = "nifty_data_stream"
                mode = 3
                token_list = [{"exchangeType": EXCHANGE_TYPE, "tokens": [TOKEN]}]
                sws.subscribe(correlation_id, mode, token_list)

            def on_error(ws, error):
                print(f"WebSocket error: {error}")

            sws.on_data = on_data
            sws.on_open = on_open
            sws.on_error = on_error
            sws.connect()
        except Exception as exc:
            print(f"Live websocket failed: {exc}")
            self._simulate_data()

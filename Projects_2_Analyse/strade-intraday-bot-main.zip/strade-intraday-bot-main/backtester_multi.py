# # backtester_multi.py
# import pandas as pd
# import glob
# import os
# from backtester import Backtester # Import your existing class
# import config

# def run_portfolio_backtest():
#     # 1. Find all CSV files in data/ directory
#     files = glob.glob("data/*_5min.csv")
    
#     if not files:
#         print("No data files found in 'data/' directory.")
#         return

#     print(f"Found {len(files)} symbols. Starting Portfolio Backtest...")
#     print("-" * 50)

#     all_trades = []
    
#     # 2. Run Backtest for each symbol
#     for filepath in files:
#         # Extract symbol from filename (e.g., "data\INFY_5min.csv" -> "INFY")
#         filename = os.path.basename(filepath)
#         symbol = filename.replace("_5min.csv", "")
        
#         # Initialize and Run Backtester
#         # We suppress the detailed print output for each symbol to keep console clean
#         bt = Backtester(symbol, filepath)
        
#         # We need to access the trades without printing the full report for each
#         # So we modify the run method or just access the internal list after run
#         # NOTE: This assumes your Backtester.run() populates self.account.trades
#         bt.run() 
        
#         # Collect trades
#         if bt.account.trades:
#             all_trades.extend(bt.account.trades)
#             print(f"{symbol}: Generated {len(bt.account.trades)} trades.")
#         else:
#             print(f"{symbol}: No trades.")

#     # 3. Aggregate Results
#     if not all_trades:
#         print("\nNo trades generated across portfolio.")
#         return

#     df_all = pd.DataFrame(all_trades)
    
#     # Sort by Time to simulate real portfolio equity curve
#     df_all['Time'] = pd.to_datetime(df_all['Time'])
#     df_all = df_all.sort_values('Time')

#     # Recalculate Portfolio Balance Cumulative
#     # We start with ONE Initial Capital pool (e.g., 100k)
#     # logic: Current Balance = Initial + Cumulative Sum of PnL
#     df_all['Portfolio_Balance'] = config.INITIAL_CAPITAL + df_all['PnL'].cumsum()

#     # 4. Generate Final Report
#     print("\n" + "="*40)
#     print(" PORTFOLIO BACKTEST REPORT")
#     print("="*40)
    
#     total_trades = len(df_all)
#     wins = len(df_all[df_all['PnL'] > 0])
#     win_rate = (wins / total_trades) * 100
#     total_pnl = df_all['PnL'].sum()
#     final_capital = config.INITIAL_CAPITAL + total_pnl
#     roi = (total_pnl / config.INITIAL_CAPITAL) * 100

#     print(f"Symbols Tested: {len(files)}")
#     print(f"Total Trades:   {total_trades}")
#     print(f"Win Rate:       {win_rate:.2f}%")
#     print(f"Total PnL:      {total_pnl:.2f}")
#     print(f"ROI:            {roi:.2f}%")
#     print(f"Final Capital:  {final_capital:.2f}")
    
#     # Save detailed log
#     df_all.to_csv("portfolio_backtest_results.csv", index=False)
#     print("\nDetailed portfolio logs saved to 'portfolio_backtest_results.csv'")

# if __name__ == "__main__":
#     run_portfolio_backtest()

# backtester_multi.py
import pandas as pd
import glob
import os
import config
from backtester import Backtester, MockAccount # Import the updated classes

def run_portfolio_backtest():
    files = glob.glob("data/*_5min.csv")
    if not files:
        print("No data files found in 'data/' directory.")
        return

    print(f"Found {len(files)} symbols. Starting Portfolio Backtest...")
    print("-" * 50)

    # 1. CREATE SHARED ACCOUNT (Starts with 100k)
    portfolio_account = MockAccount()
    
    # 2. RUN BACKTEST SEQUENTIALLY
    # Each symbol will trade using the *current* balance of portfolio_account
    for filepath in files:
        filename = os.path.basename(filepath)
        symbol = filename.replace("_5min.csv", "")
        
        # Pass the shared account to the backtester
        bt = Backtester(symbol, filepath, shared_account=portfolio_account)
        bt.run()
        
        # Print status after this symbol is done
        current_balance = portfolio_account.balance
        pnl = current_balance - config.INITIAL_CAPITAL
        print(f"Finished {symbol}. Current Balance: {current_balance:.2f} (PnL: {pnl:.2f})")

    # 3. GENERATE FINAL REPORT
    all_trades = portfolio_account.trades
    if not all_trades:
        print("\nNo trades generated.")
        return

    df_all = pd.DataFrame(all_trades)
    
    # Sort by Exit Time to see the chronological growth
    # (Note: backtesting sequentially isn't perfect time-sync, but it tests capital compounding)
    
    print("\n" + "="*40)
    print(" FINAL PORTFOLIO REPORT")
    print("="*40)
    
    total_trades = len(df_all)
    wins = len(df_all[df_all['realized_pnl'] > 0])
    win_rate = (wins / total_trades) * 100
    total_pnl = portfolio_account.balance - config.INITIAL_CAPITAL
    roi = (total_pnl / config.INITIAL_CAPITAL) * 100

    print(f"Symbols Tested: {len(files)}")
    print(f"Total Trades:   {total_trades}")
    print(f"Win Rate:       {win_rate:.2f}%")
    print(f"Total PnL:      {total_pnl:.2f}")
    print(f"ROI:            {roi:.2f}%")
    print(f"Final Capital:  {portfolio_account.balance:.2f}")
    
    df_all.to_csv("portfolio_results.csv", index=False)
    print("\nLog saved to 'portfolio_results.csv'")

if __name__ == "__main__":
    run_portfolio_backtest()
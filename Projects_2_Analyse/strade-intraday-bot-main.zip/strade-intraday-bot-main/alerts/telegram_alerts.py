# alerts/telegram_alerts.py
import requests
import logging
import config 

log = logging.getLogger("telegram")

class TelegramAlerts:
    def __init__(self):
        # Load credentials from config
        self.bot_token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"

    def send(self, message):
        if not self.chat_id or not self.bot_token:
            log.warning("Telegram credentials missing or not configured. Alert skipped.")
            return

        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "Markdown"
        }
        try:
            # Use requests for synchronous, reliable sending
            resp = requests.post(self.base_url, json=payload, timeout=5)
            if resp.status_code != 200:
                log.error(f"Failed to send Telegram alert: {resp.text}")
        except Exception as e:
            log.error(f"Telegram connection error: {e}")
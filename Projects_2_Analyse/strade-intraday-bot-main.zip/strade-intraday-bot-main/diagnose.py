# diagnose.py
import pandas as pd
from kiteconnect import KiteConnect
import config
from indicators import ema, atr, rsi, adx, vwap, supertrend
from datetime import datetime
import os
import time

def run_diagnosis():
    print("--- SYSTEM DIAGNOSIS TOOL ---")
    
    # 1. Connect to API
    try:
        if os.path.exists("access_token.txt"):
            access_token = open("access_token.txt", "r").read().strip()
        else:
            access_token = config.ACCESS_TOKEN

        kite = KiteConnect(api_key=config.KITE_API_KEY)
        kite.set_access_token(access_token)
        print("API Connection: SUCCESS")
    except Exception as e:
        print(f"API Connection: FAILED ({e})")
        return

    # 2. Load Active Instruments
    if not os.path.exists("active_instruments.csv"):
        print("ERROR: 'active_instruments.csv' not found. Run 'universe_selector.py' first.")
        return

    df_active = pd.read_csv("active_instruments.csv")
    print(f"Loaded {len(df_active)} symbols from Hot List.\n")

    # 3. Iterate and Diagnose
    for index, row in df_active.iterrows():
        symbol = row['symbol']
        token = row['token']
        
        diagnose_symbol(kite, symbol, token)
        print("-" * 50) # Separator
        time.sleep(0.5) # Avoid hitting API rate limits

def diagnose_symbol(kite, symbol, token):
    print(f"Checking {symbol}...", end=" ")
    
    try:
        # Fetch Data (Last 5 days)
        to_date = datetime.now()
        from_date = to_date - pd.Timedelta(days=5)
        
        # We need both 5m and 15m data
        recs15 = kite.historical_data(token, from_date, to_date, "15minute")
        recs5 = kite.historical_data(token, from_date, to_date, "5minute")
        
        if len(recs15) < 50 or len(recs5) < 50:
            print(f"SKIPPED (Not enough data: {len(recs5)} candles)")
            return

        df15 = pd.DataFrame(recs15)
        df5 = pd.DataFrame(recs5)

        # --- CALCULATIONS ---
        
        # 1. Market Regime (15m)
        ema50_15m = ema(df15['close'], 50).iloc[-1]
        curr_close_15 = df15['close'].iloc[-1]
        trend_15m = "UP" if curr_close_15 > ema50_15m else "DOWN"
        adx_val = adx(df15, 14).iloc[-1]
        
        # 2. Volatility (5m)
        atr_val = atr(df5).iloc[-1]
        atr_avg = atr(df5).rolling(10).mean().iloc[-1]
        
        # 3. Strategy Indicators (5m)
        close_5m = df5['close'].iloc[-1]
        vwap_val = vwap(df5).iloc[-1]
        rsi_val = rsi(df5['close']).iloc[-1]
        st_line, st_dir = supertrend(df5, period=10, multiplier=3)
        st_status = "GREEN" if st_dir.iloc[-1] == 1 else "RED"

        # --- DIAGNOSIS REPORT ---
        print("\n   [STATUS REPORT]")
        
        # A. CHOP CHECK
        if adx_val < 20:
            print(f"   ❌ REJECT: Choppy Market (ADX: {adx_val:.2f} < 20)")
            return # Stop checking this symbol
            
        # B. VOLATILITY CHECK
        if atr_val < (atr_avg * 0.7):
            print(f"   ❌ REJECT: Low Volatility (ATR: {atr_val:.2f} < Avg: {atr_avg:.2f})")
            return

        # C. TREND ALIGNMENT CHECK
        # Check if we have a valid setup based on Trend
        setup_found = False
        
        if trend_15m == "UP":
            print(f"   ℹ️  Trend: UP (Price > 15m EMA). Looking for LONG...")
            
            # Check Long Logic
            fail_reasons = []
            if st_dir.iloc[-1] != 1: fail_reasons.append(f"Supertrend is RED")
            if close_5m <= vwap_val: fail_reasons.append(f"Price ({close_5m}) < VWAP ({vwap_val:.2f})")
            if rsi_val <= 55: fail_reasons.append(f"RSI Weak ({rsi_val:.2f})")
            
            # Trigger
            trigger = (st_dir.iloc[-2] == -1) or (close_5m < vwap_val * 1.01)
            if not trigger: fail_reasons.append("Waiting for Pullback (Price extended)")
            
            if not fail_reasons:
                print(f"   ✅ ** SIGNAL DETECTED: BUY NOW **")
                setup_found = True
            else:
                print(f"   ⚠️  NO ENTRY: {', '.join(fail_reasons)}")

        elif trend_15m == "DOWN":
            print(f"   ℹ️  Trend: DOWN (Price < 15m EMA). Looking for SHORT...")
            
            if not config.ALLOW_SHORTS:
                print("   ❌ REJECT: Shorting disabled in config.")
                return

            # Check Short Logic
            fail_reasons = []
            if st_dir.iloc[-1] != -1: fail_reasons.append(f"Supertrend is GREEN")
            if close_5m >= vwap_val: fail_reasons.append(f"Price ({close_5m}) > VWAP ({vwap_val:.2f})")
            if rsi_val >= 45: fail_reasons.append(f"RSI High ({rsi_val:.2f})")
            
            # Trigger
            trigger = (st_dir.iloc[-2] == 1) or (close_5m > vwap_val * 0.99)
            if not trigger: fail_reasons.append("Waiting for Pullback")
            
            if not fail_reasons:
                print(f"   ✅ ** SIGNAL DETECTED: SELL NOW **")
                setup_found = True
            else:
                print(f"   ⚠️  NO ENTRY: {', '.join(fail_reasons)}")
        
        if not setup_found:
            print("   (Watching for setup...)")

    except Exception as e:
        print(f"   ERROR: {e}")

if __name__ == "__main__":
    run_diagnosis()
# # universe_selector.py
# import pandas as pd
# from kiteconnect import KiteConnect
# from datetime import datetime, timedelta
# import config
# import os

# # Your master list of Nifty 100 tokens (Token: Symbol)
# # Ideally, load this from a full dump or a CSV
# NIFTY_100 = {
#     "ABB": 3329, "ADANIENT": 6401,"APOLLOHOSP": 40193, "ASIANPAINT": 60417,
#     "BAJAJHLDNG": 78081, "BAJFINANCE": 81153, "BEL": 98049, "HDFCLIFE": 119553,
#     "MAZDOCK": 130305, "BPCL": 134657, "BRITANNIA": 140033, "CHOLAFIN": 175361,
#     "CIPLA": 177665, "CGPOWER": 194561, "DRREDDY": 225537, "EICHERMOT": 232961,
#     "GRASIM": 315393, "AMBUJACEM": 325121, "HDFCBANK": 341249, "HINDALCO": 348929,
#     "HINDUNILVR": 356865, "HINDZINC": 364545, "INDHOTEL": 387073, "INFY": 408065,
#     "IOC": 415745, "ITC": 424961, "KOTAKBANK": 492033, "TRENT": 502785, "IRFC": 519425,
#     "M&M": 519937, "BOSCHLTD": 558337, "HAL": 589569, "ONGC": 633601, "PIDILITIND": 681985,
#     "RELIANCE": 738561, "SBIN": 779521, "VEDL": 784129, "SHREECEM": 794369,
#     "SIEMENS": 806401, "LODHA": 824321, "SUNPHARMA": 857857, "TATAPOWER": 877057,
#     "TATACONSUM": 878593, "TMPV": 884737, "TATASTEEL": 895745, "TITAN": 897537,
#     "TORNTPHARM": 900609, "ADANIGREEN": 912129, "WIPRO": 969473, "MOTHERSON": 1076225,
#     "SHRIRAMFIN": 1102337, "BANKBARODA": 1195009, "GAIL": 1207553, "ICICIBANK": 1270529,
#     "ETERNAL": 1304833, "AXISBANK": 1510401, "JINDALSTEL": 1723649, "HCLTECH": 1850625,
#     "ZYDUSLIFE": 2029825, "TVSMOTOR": 2170625, "LICI": 2426881, "HAVELLS": 2513665,
#     "GODREJCP": 2585345, "ADANIENSOL": 2615553, "UNITDSPR": 2674433, "BHARTIARTL": 2714625,
#     "PNB": 2730497, "CANBK": 2763265, "DIVISLAB": 2800641, "MARUTI": 2815745,
#     "INDIGO": 2865921, "LT": 2939649, "ULTRACEMCO": 2952193, "TCS": 2953217,
#     "NTPC": 2977281, "JSWSTEEL": 3001089, "SOLARINDS": 3412993, "TECHM": 3465729,
#     "NAUKRI": 3520257, "PFC": 3660545, "DLF": 3771393, "POWERGRID": 3834113,
#     "ADANIPORTS": 3861249, "RECLTD": 3930881, "BAJAJ-AUTO": 4267265, "BAJAJFINSV": 4268801,
#     "ADANIPOWER": 4451329, "LTIM": 4561409, "JSWENERGY": 4574465, "NESTLEIND": 4598529,
#     "JIOFIN": 4644609, "VBL": 4843777, "DMART": 5097729, "COALINDIA": 5215745,
#     "ICICIGI": 5573121, "SBILIFE": 5582849, "MAXHEALTH": 5728513, "BAJAJHFL": 6469121,
#     "HYUNDAI": 6616065, "ENRIN": 193758977
# }

# def filter_universe():
#     print("--- GENERATING HOT LIST ---")
    
#     try:
#         access_token = open("access_token.txt", "r").read().strip()
#         kite = KiteConnect(api_key=config.KITE_API_KEY)
#         kite.set_access_token(access_token)
#     except:
#         print("Login Failed")
#         return

#     selected_stocks = []
    
#     # 1. Fetch Previous Day Data for Volatility Check
#     to_date = datetime.now().date()
#     from_date = to_date - timedelta(days=5) # Last 5 days for Average Volume

#     print(f"Scanning {len(NIFTY_100)} stocks...")

#     for symbol, token in NIFTY_100.items():
#         try:
#             # Fetch Daily candles
#             records = kite.historical_data(token, from_date, to_date, "day")
#             if not records or len(records) < 3: continue
            
#             df = pd.DataFrame(records)
#             prev_close = df['close'].iloc[-2]
#             avg_vol = df['volume'].iloc[-3:].mean()
            
#             # --- CRITERIA 1: LIQUIDITY ---
#             # Turnover > 50 Crore (approx) or Volume > 500k
#             if avg_vol < 500000: continue 

#             # --- CRITERIA 2: VOLATILITY (ATR %) ---
#             # We want stocks that move at least 1.5% daily on average
#             high = df['high']
#             low = df['low']
#             tr = (high - low) / prev_close * 100
#             avg_atr_pct = tr.mean()
            
#             if avg_atr_pct < 1.5: continue # Skip slow stocks

#             # --- CRITERIA 3: GAP (Live Check at 9:15) ---
#             # If running after 9:15, check today's open vs yesterday close
#             # current_open = df['open'].iloc[-1]
#             # gap = abs(current_open - prev_close) / prev_close * 100
#             # if gap < 0.5: continue # Skip if opening flat
            
#             selected_stocks.append({
#                 'symbol': symbol,
#                 'token': token,
#                 'avg_atr_pct': avg_atr_pct,
#                 'avg_volume': avg_vol
#             })
            
#         except Exception as e:
#             print(f"Error {symbol}: {e}")

#     # 2. Sort by "Most Volatile" and pick Top 15
#     df_result = pd.DataFrame(selected_stocks)
#     if df_result.empty:
#         print("No stocks met criteria.")
#         return

#     df_result = df_result.sort_values(by='avg_atr_pct', ascending=False).head(15)
    
#     # 3. Save to active_instruments.csv
#     df_result[['symbol', 'token']].to_csv("active_instruments.csv", index=False)
    
#     print("\n--- FINAL HOT LIST ---")
#     print(df_result[['symbol', 'avg_atr_pct']])
#     print(f"\nSaved top 15 stocks to 'active_instruments.csv'")

# if __name__ == "__main__":
#     filter_universe()


# universe_selector.py
import pandas as pd
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import config  # Imports ALLOW_SHORTS and API keys
import os

# Your master list of Nifty 100 tokens (Symbol: Token)
# You can populate this from the Zerodha instrument dump
# Example placeholders provided below:
NIFTY_100 = {
    "RELIANCE": 738561, "HDFCBANK": 341249, "INFY": 408065, "TCS": 2953217,
    "ICICIBANK": 1270529, "SBIN": 779521, "KOTAKBANK": 492033, "BHARTIARTL": 2714625,
    "ITC": 424961, "LT": 2939649, "AXISBANK": 1510401, "ASIANPAINT": 60417,
    "MARUTI": 2815745, "TITAN": 897537, "ULTRACEMCO": 2952193, "BAJFINANCE": 81153,
    "SUNPHARMA": 857857, "TATAMOTORS": 884737, "ADANIENT": 3861249, "WIPRO": 969473,
    # ... (Add remaining Nifty 100 stocks here) ...
}

def filter_universe():
    print(f"--- GENERATING HOT LIST ---")
    print(f"CONFIG: Shorts Allowed = {config.ALLOW_SHORTS}")
    
    try:
        # Load token from file or config
        if os.path.exists("access_token.txt"):
            access_token = open("access_token.txt", "r").read().strip()
        else:
            access_token = config.ACCESS_TOKEN

        kite = KiteConnect(api_key=config.KITE_API_KEY)
        kite.set_access_token(access_token)
    except Exception as e:
        print(f"Login Failed: {e}")
        return

    selected_stocks = []
    
    # Fetch last 60 days to calculate 50 SMA accurately
    to_date = datetime.now().date()
    from_date = to_date - timedelta(days=90) 

    print(f"Scanning {len(NIFTY_100)} stocks for opportunities...")

    for symbol, token in NIFTY_100.items():
        try:
            # Fetch Daily candles
            records = kite.historical_data(token, from_date, to_date, "day")
            if not records or len(records) < 50: continue
            
            df = pd.DataFrame(records)
            prev_close = df['close'].iloc[-1] # Most recent close
            
            # --- FILTER 1: LIQUIDITY ---
            # Average Volume of last 5 days > 500,000
            avg_vol = df['volume'].iloc[-5:].mean()
            if avg_vol < 500000: 
                continue 

            # --- FILTER 2: VOLATILITY (ATR %) ---
            # We want stocks that have an average daily range > 1.5%
            # Simple TR calc: (High - Low) / Close * 100
            high = df['high']
            low = df['low']
            close = df['close']
            tr_pct = ((high - low) / close) * 100
            avg_atr_pct = tr_pct.iloc[-10:].mean() # Average of last 10 days
            
            if avg_atr_pct < 1.5: 
                continue # Skip slow stocks

            # --- FILTER 3: SMART TREND BIAS (Optional Optimization) ---
            # If ALLOW_SHORTS is False, we only want stocks in an Uptrend.
            # Logic: Price must be > 50 Day SMA
            if not config.ALLOW_SHORTS:
                sma_50 = df['close'].rolling(50).mean().iloc[-1]
                if prev_close < sma_50:
                    # Stock is in downtrend, and we can't short -> Skip it
                    continue

            selected_stocks.append({
                'symbol': symbol,
                'token': token,
                'avg_atr_pct': round(avg_atr_pct, 2),
                'avg_volume': int(avg_vol)
            })
            print(f" -> Found {symbol} (Vol: {avg_atr_pct:.2f}%)")
            
        except Exception as e:
            print(f"Error scanning {symbol}: {e}")

    # 2. Sort by "Most Volatile" and pick Top 15
    df_result = pd.DataFrame(selected_stocks)
    
    if df_result.empty:
        print("No stocks met the criteria today.")
        return

    # Sort descending by Volatility
    df_result = df_result.sort_values(by='avg_atr_pct', ascending=False).head(15)
    
    # 3. Save to active_instruments.csv
    # We only need symbol and token for the main bot
    df_result[['symbol', 'token']].to_csv("active_instruments.csv", index=False)
    
    print("\n" + "="*40)
    print(" FINAL HOT LIST GENERATED")
    print("="*40)
    print(df_result[['symbol', 'avg_atr_pct', 'avg_volume']].to_string(index=False))
    print(f"\nSaved top {len(df_result)} stocks to 'active_instruments.csv'")

if __name__ == "__main__":
    filter_universe()
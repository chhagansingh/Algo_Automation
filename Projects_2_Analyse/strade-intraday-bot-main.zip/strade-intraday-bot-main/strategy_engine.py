# # # # # # # strategy_engine.py
# # # # # # import pandas as pd
# # # # # # from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku

# # # # # # class StrategyEngine:
# # # # # #     def analyze(self, symbol, data_cache, context):
# # # # # #         """
# # # # # #         Selects strategy based on Regime and Session.
# # # # # #         """
# # # # # #         df5 = data_cache.get(5) # 5-min data for entry
# # # # # #         if df5 is None or len(df5) < 50: return None
        
# # # # # #         close = df5['close'].iloc[-1]
# # # # # #         session = context['session']
# # # # # #         regime = context['regime']
        
# # # # # #         # -----------------------------------------------
# # # # # #         # STRATEGY 1: VWAP + MACD TREND (For Strong Trends)
# # # # # #         # -----------------------------------------------
# # # # # #         if "STRONG" in regime and session in ["MID_DAY", "CLOSING_RUSH"]:
# # # # # #             # Pass full df5 to vwap
# # # # # #             vwap_val = vwap(df5).iloc[-1]
# # # # # #             macd_line, signal_line, _ = macd(df5['close'])
            
# # # # # #             # LONG CONDITION
# # # # # #             if regime == "STRONG_UPTREND" and close > vwap_val:
# # # # # #                 if macd_line.iloc[-1] > signal_line.iloc[-1] and macd_line.iloc[-1] > 0:
# # # # # #                     atr_val = atr(df5).iloc[-1]
# # # # # #                     return {
# # # # # #                         "symbol": symbol, "direction": "LONG", "strategy": "VWAP_Trend",
# # # # # #                         "entry": close, 
# # # # # #                         "stop": close - (2 * atr_val), 
# # # # # #                         "target": close + (4 * atr_val)
# # # # # #                     }

# # # # # #             # SHORT CONDITION
# # # # # #             elif regime == "STRONG_DOWNTREND" and close < vwap_val:
# # # # # #                 if macd_line.iloc[-1] < signal_line.iloc[-1] and macd_line.iloc[-1] < 0:
# # # # # #                     atr_val = atr(df5).iloc[-1]
# # # # # #                     return {
# # # # # #                         "symbol": symbol, "direction": "SHORT", "strategy": "VWAP_Trend",
# # # # # #                         "entry": close, 
# # # # # #                         "stop": close + (2 * atr_val), 
# # # # # #                         "target": close - (4 * atr_val)
# # # # # #                     }

# # # # # #         # -----------------------------------------------
# # # # # #         # STRATEGY 2: ICHIMOKU CLOUD BREAKOUT (Alternative Trend)
# # # # # #         # -----------------------------------------------
# # # # # #         if "TREND" in regime:
# # # # # #             # Pass full df5 to ichimoku
# # # # # #             tenkan, kijun, senkou_a, senkou_b, _ = ichimoku(df5)
# # # # # #             cloud_top = max(senkou_a.iloc[-1], senkou_b.iloc[-1])
# # # # # #             cloud_bottom = min(senkou_a.iloc[-1], senkou_b.iloc[-1])
            
# # # # # #             # TK Cross (Tenkan crosses above Kijun) above Cloud
# # # # # #             if (tenkan.iloc[-1] > kijun.iloc[-1] and 
# # # # # #                 tenkan.iloc[-2] <= kijun.iloc[-2] and 
# # # # # #                 close > cloud_top):
# # # # # #                  atr_val = atr(df5).iloc[-1]
# # # # # #                  return {
# # # # # #                     "symbol": symbol, "direction": "LONG", "strategy": "Ichimoku_Breakout",
# # # # # #                     "entry": close, "stop": cloud_bottom, "target": close + (3 * atr_val)
# # # # # #                 }

# # # # # #         # -----------------------------------------------
# # # # # #         # STRATEGY 3: RSI + BOLLINGER REVERSAL (For Sideways)
# # # # # #         # -----------------------------------------------
# # # # # #         if regime == "SIDEWAYS":
# # # # # #             rsi_val = rsi(df5['close']).iloc[-1]
            
# # # # # #             # FIX: Pass FULL DataFrame 'df5', not just the series
# # # # # #             upper, lower, _ = bbands(df5) 
            
# # # # # #             # Revert to mean from Lower Band
# # # # # #             if rsi_val < 30 and close < lower.iloc[-1]:
# # # # # #                  return {
# # # # # #                     "symbol": symbol, "direction": "LONG", "strategy": "RSI_MeanRev",
# # # # # #                     "entry": close, 
# # # # # #                     "stop": df5['low'].min(), 
# # # # # #                     "target": upper.iloc[-1] 
# # # # # #                 }
            
# # # # # #             # Revert to mean from Upper Band
# # # # # #             elif rsi_val > 70 and close > upper.iloc[-1]:
# # # # # #                  return {
# # # # # #                     "symbol": symbol, "direction": "SHORT", "strategy": "RSI_MeanRev",
# # # # # #                     "entry": close, 
# # # # # #                     "stop": df5['high'].max(), 
# # # # # #                     "target": lower.iloc[-1]
# # # # # #                 }

# # # # # #         return None


# # # # # # strategy_engine.py
# # # # # import pandas as pd
# # # # # from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku, supertrend

# # # # # class StrategyEngine:
# # # # #     def analyze(self, symbol, data_cache, context):
# # # # #         df5 = data_cache.get(5)
# # # # #         if df5 is None or len(df5) < 50: return None
        
# # # # #         close = df5['close'].iloc[-1]
# # # # #         regime = context['regime']
        
# # # # #         # 1. CRITICAL: DO NOT TRADE IN CHOPPY MARKETS
# # # # #         if regime == "CHOPPY":
# # # # #             return None 

# # # # #         # Calculate Indicators
# # # # #         st_line, st_dir = supertrend(df5, period=10, multiplier=3)
# # # # #         vwap_val = vwap(df5).iloc[-1]
# # # # #         rsi_val = rsi(df5['close']).iloc[-1]
# # # # #         atr_val = atr(df5).iloc[-1]

# # # # #         # -----------------------------------------------
# # # # #         # STRATEGY: SUPERTREND + VWAP CONFLUENCE
# # # # #         # High probability trend following
# # # # #         # -----------------------------------------------
# # # # #         if regime in ["STRONG_UPTREND", "STRONG_DOWNTREND", "SIDEWAYS"]: 
# # # # #             # Note: We allow Sideways if Supertrend breaks out, but filter Choppy
            
# # # # #             # LONG SETUP
# # # # #             # 1. Supertrend is Bullish (1)
# # # # #             # 2. Price is ABOVE VWAP (Institutional Support)
# # # # #             # 3. RSI is healthy (above 50, showing momentum)
# # # # #             if st_dir.iloc[-1] == 1 and close > vwap_val and rsi_val > 50:
# # # # #                 # Trigger: Price just crossed above Supertrend OR pullback to it
# # # # #                 if st_dir.iloc[-2] == -1 or close < vwap_val * 1.01:
# # # # #                      return {
# # # # #                         "symbol": symbol, "direction": "LONG", "strategy": "Supertrend_Flow",
# # # # #                         "entry": close, 
# # # # #                         # Stop Loss is the Supertrend Line itself (Dynamic)
# # # # #                         "stop": st_line.iloc[-1], 
# # # # #                         # Target is open (Trend Following), or 1:3 RR
# # # # #                         "target": close + (3 * atr_val)
# # # # #                     }

# # # # #             # SHORT SETUP
# # # # #             # 1. Supertrend is Bearish (-1)
# # # # #             # 2. Price is BELOW VWAP
# # # # #             # 3. RSI is weak (below 50)
# # # # #             elif st_dir.iloc[-1] == -1 and close < vwap_val and rsi_val < 50:
# # # # #                 if st_dir.iloc[-2] == 1 or close > vwap_val * 0.99:
# # # # #                      return {
# # # # #                         "symbol": symbol, "direction": "SHORT", "strategy": "Supertrend_Flow",
# # # # #                         "entry": close, 
# # # # #                         "stop": st_line.iloc[-1], 
# # # # #                         "target": close - (3 * atr_val)
# # # # #                     }

# # # # #         return None


# # # # # strategy_engine.py
# # # # import pandas as pd
# # # # from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku, supertrend

# # # # class StrategyEngine:
# # # #     def analyze(self, symbol, data_cache, context):
# # # #         df5 = data_cache.get(5)
# # # #         if df5 is None or len(df5) < 52: return None # Need 52 for Ichimoku
        
# # # #         close = df5['close'].iloc[-1]
# # # #         regime = context['regime']
        
# # # #         # 0. SAFETY FILTER: KILL SWITCH IN CHOPPY MARKETS
# # # #         # If ADX < 20 (from market_analyzer), we do absolutely nothing.
# # # #         if regime == "CHOPPY":
# # # #             return None 

# # # #         # --- PRE-CALCULATE COMMON INDICATORS ---
# # # #         atr_val = atr(df5).iloc[-1]
# # # #         vwap_val = vwap(df5).iloc[-1]
# # # #         rsi_val = rsi(df5['close']).iloc[-1]

# # # #         # ============================================================
# # # #         # STRATEGY 1: SUPERTREND FLOW (Highest Priority / Reliability)
# # # #         # ============================================================
# # # #         st_line, st_dir = supertrend(df5, period=10, multiplier=3)
        
# # # #         # LONG: Supertrend Green + Price > VWAP + RSI > 50
# # # #         if st_dir.iloc[-1] == 1 and close > vwap_val and rsi_val > 50:
# # # #             # Trigger: Fresh crossover OR pullback
# # # #             if st_dir.iloc[-2] == -1 or close < vwap_val * 1.01:
# # # #                 return {
# # # #                     "symbol": symbol, "direction": "LONG", "strategy": "Supertrend_Flow",
# # # #                     "entry": close, "stop": st_line.iloc[-1], "target": close + (3 * atr_val)
# # # #                 }

# # # #         # SHORT: Supertrend Red + Price < VWAP + RSI < 50
# # # #         elif st_dir.iloc[-1] == -1 and close < vwap_val and rsi_val < 50:
# # # #             if st_dir.iloc[-2] == 1 or close > vwap_val * 0.99:
# # # #                 return {
# # # #                     "symbol": symbol, "direction": "SHORT", "strategy": "Supertrend_Flow",
# # # #                     "entry": close, "stop": st_line.iloc[-1], "target": close - (3 * atr_val)
# # # #                 }

# # # #         # ============================================================
# # # #         # STRATEGY 2: ICHIMOKU CLOUD BREAKOUT (Explosive Moves)
# # # #         # ============================================================
# # # #         tenkan, kijun, senkou_a, senkou_b, _ = ichimoku(df5)
# # # #         cloud_top = max(senkou_a.iloc[-1], senkou_b.iloc[-1])
# # # #         cloud_bottom = min(senkou_a.iloc[-1], senkou_b.iloc[-1])

# # # #         # LONG: Price breaks above Cloud + Tenkan > Kijun (Bullish Cross)
# # # #         if close > cloud_top and tenkan.iloc[-1] > kijun.iloc[-1]:
# # # #             # Ensure the breakout just happened (don't buy extended)
# # # #             if df5['close'].iloc[-2] <= cloud_top or tenkan.iloc[-2] <= kijun.iloc[-2]:
# # # #                 return {
# # # #                     "symbol": symbol, "direction": "LONG", "strategy": "Ichimoku_Breakout",
# # # #                     "entry": close, "stop": cloud_bottom, "target": close + (4 * atr_val)
# # # #                 }
        
# # # #         # SHORT: Price breaks below Cloud + Tenkan < Kijun
# # # #         elif close < cloud_bottom and tenkan.iloc[-1] < kijun.iloc[-1]:
# # # #              if df5['close'].iloc[-2] >= cloud_bottom or tenkan.iloc[-2] >= kijun.iloc[-2]:
# # # #                 return {
# # # #                     "symbol": symbol, "direction": "SHORT", "strategy": "Ichimoku_Breakout",
# # # #                     "entry": close, "stop": cloud_top, "target": close - (4 * atr_val)
# # # #                 }

# # # #         # ============================================================
# # # #         # STRATEGY 3: MACD MOMENTUM (Reversals / Trend Confirm)
# # # #         # ============================================================
# # # #         # Only take these if we are NOT in a Supertrend setup (to avoid duplicate signals)
# # # #         macd_line, signal_line, _ = macd(df5['close'])
        
# # # #         # LONG: MACD Cross Up + Price > EMA 50 (Trend Confirm)
# # # #         e50 = ema(df5['close'], 50).iloc[-1]
# # # #         if macd_line.iloc[-1] > signal_line.iloc[-1] and macd_line.iloc[-2] <= signal_line.iloc[-2]:
# # # #             if close > e50:
# # # #                  return {
# # # #                     "symbol": symbol, "direction": "LONG", "strategy": "MACD_Momentum",
# # # #                     "entry": close, "stop": close - (1.5 * atr_val), "target": close + (2.5 * atr_val)
# # # #                 }

# # # #         # SHORT: MACD Cross Down + Price < EMA 50
# # # #         elif macd_line.iloc[-1] < signal_line.iloc[-1] and macd_line.iloc[-2] >= signal_line.iloc[-2]:
# # # #             if close < e50:
# # # #                  return {
# # # #                     "symbol": symbol, "direction": "SHORT", "strategy": "MACD_Momentum",
# # # #                     "entry": close, "stop": close + (1.5 * atr_val), "target": close - (2.5 * atr_val)
# # # #                 }

# # # #         return None


# # # # strategy_engine.py
# # # import pandas as pd
# # # from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku, supertrend

# # # class StrategyEngine:
# # #     def analyze(self, symbol, data_cache, context):
# # #         df5 = data_cache.get(5)
# # #         df15 = data_cache.get(15) # <--- Fetch 15m data
        
# # #         if df5 is None or len(df5) < 52 or df15 is None or len(df15) < 50: 
# # #             return None
        
# # #         close = df5['close'].iloc[-1]
# # #         regime = context['regime']
        
# # #         # 0. SAFETY FILTER: CHOPPY MARKETS
# # #         if regime == "CHOPPY": return None 

# # #         # --- 1. HIGHER TIMEFRAME FILTER (The "Golden Rule") ---
# # #         # Calculate 50 EMA on 15-minute chart
# # #         ema50_15m = ema(df15['close'], 50).iloc[-1]
        
# # #         # Determine permitted trade direction
# # #         allow_longs = df15['close'].iloc[-1] > ema50_15m
# # #         allow_shorts = df15['close'].iloc[-1] < ema50_15m

# # #         # --- PRE-CALCULATE INDICATORS ---
# # #         atr_val = atr(df5).iloc[-1]
# # #         vwap_val = vwap(df5).iloc[-1]
# # #         rsi_val = rsi(df5['close']).iloc[-1]
# # #         st_line, st_dir = supertrend(df5, period=10, multiplier=3)

# # #         # ============================================================
# # #         # STRATEGY 1: SUPERTREND FLOW (Highest Priority)
# # #         # ============================================================
        
# # #         # LONG: Allowed only if 15m Trend is UP
# # #         if allow_longs and st_dir.iloc[-1] == 1 and close > vwap_val and rsi_val > 50:
# # #             if st_dir.iloc[-2] == -1 or close < vwap_val * 1.01:
# # #                 return {
# # #                     "symbol": symbol, "direction": "LONG", "strategy": "Supertrend_Flow",
# # #                     "entry": close, "stop": st_line.iloc[-1], "target": close + (3 * atr_val)
# # #                 }

# # #         # SHORT: Allowed only if 15m Trend is DOWN
# # #         elif allow_shorts and st_dir.iloc[-1] == -1 and close < vwap_val and rsi_val < 50:
# # #             if st_dir.iloc[-2] == 1 or close > vwap_val * 0.99:
# # #                 return {
# # #                     "symbol": symbol, "direction": "SHORT", "strategy": "Supertrend_Flow",
# # #                     "entry": close, "stop": st_line.iloc[-1], "target": close - (3 * atr_val)
# # #                 }

# # #         # ============================================================
# # #         # STRATEGY 2: ICHIMOKU CLOUD BREAKOUT (Explosive Moves)
# # #         # ============================================================
# # #         tenkan, kijun, senkou_a, senkou_b, _ = ichimoku(df5)
# # #         cloud_top = max(senkou_a.iloc[-1], senkou_b.iloc[-1])
# # #         cloud_bottom = min(senkou_a.iloc[-1], senkou_b.iloc[-1])

# # #         # LONG: Only if 15m Trend is UP
# # #         if allow_longs and close > cloud_top and tenkan.iloc[-1] > kijun.iloc[-1]:
# # #             if df5['close'].iloc[-2] <= cloud_top or tenkan.iloc[-2] <= kijun.iloc[-2]:
# # #                 return {
# # #                     "symbol": symbol, "direction": "LONG", "strategy": "Ichimoku_Breakout",
# # #                     "entry": close, "stop": cloud_bottom, "target": close + (4 * atr_val)
# # #                 }
        
# # #         # SHORT: Only if 15m Trend is DOWN
# # #         elif allow_shorts and close < cloud_bottom and tenkan.iloc[-1] < kijun.iloc[-1]:
# # #              if df5['close'].iloc[-2] >= cloud_bottom or tenkan.iloc[-2] >= kijun.iloc[-2]:
# # #                 return {
# # #                     "symbol": symbol, "direction": "SHORT", "strategy": "Ichimoku_Breakout",
# # #                     "entry": close, "stop": cloud_top, "target": close - (4 * atr_val)
# # #                 }

# # #         # ============================================================
# # #         # STRATEGY 3: MACD MOMENTUM (Reversals)
# # #         # ============================================================
# # #         macd_line, signal_line, _ = macd(df5['close'])
# # #         e50_5m = ema(df5['close'], 50).iloc[-1]
        
# # #         # LONG: Only if 15m Trend is UP
# # #         if allow_longs and macd_line.iloc[-1] > signal_line.iloc[-1] and macd_line.iloc[-2] <= signal_line.iloc[-2]:
# # #             if close > e50_5m:
# # #                  return {
# # #                     "symbol": symbol, "direction": "LONG", "strategy": "MACD_Momentum",
# # #                     "entry": close, "stop": close - (1.5 * atr_val), "target": close + (2.5 * atr_val)
# # #                 }

# # #         # SHORT: Only if 15m Trend is DOWN
# # #         elif allow_shorts and macd_line.iloc[-1] < signal_line.iloc[-1] and macd_line.iloc[-2] >= signal_line.iloc[-2]:
# # #             if close < e50_5m:
# # #                  return {
# # #                     "symbol": symbol, "direction": "SHORT", "strategy": "MACD_Momentum",
# # #                     "entry": close, "stop": close + (1.5 * atr_val), "target": close - (2.5 * atr_val)
# # #                 }

# # #         return None

# # # strategy_engine.py
# # import pandas as pd
# # from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku, supertrend

# # class StrategyEngine:
# #     def analyze(self, symbol, data_cache, context):
# #         df5 = data_cache.get(5)
# #         df15 = data_cache.get(15)
        
# #         if df5 is None or len(df5) < 52 or df15 is None or len(df15) < 50: 
# #             return None
        
# #         close = df5['close'].iloc[-1]
# #         regime = context['regime']
        
# #         # 0. SAFETY FILTERS
# #         if regime == "CHOPPY": return None 
        
# #         # VOLATILITY FILTER: Don't trade if the market is "dead"
# #         # We compare current ATR to the average ATR of the last 10 bars
# #         atr_val = atr(df5).iloc[-1]
# #         atr_avg = atr(df5).rolling(10).mean().iloc[-1]
# #         if atr_val < (atr_avg * 0.8): # Market is too quiet
# #             return None

# #         # 1. GOLDEN RULE: 15-Minute Trend Filter
# #         ema50_15m = ema(df15['close'], 50).iloc[-1]
# #         allow_longs = df15['close'].iloc[-1] > ema50_15m
# #         allow_shorts = df15['close'].iloc[-1] < ema50_15m

# #         # Pre-calc Indicators
# #         vwap_val = vwap(df5).iloc[-1]
# #         rsi_val = rsi(df5['close']).iloc[-1]
# #         st_line, st_dir = supertrend(df5, period=10, multiplier=3)

# #         # ============================================================
# #         # STRATEGY 1: SUPERTREND FLOW (Sniper Mode)
# #         # ============================================================
        
# #         # LONG: 
# #         # 1. 15m Trend UP
# #         # 2. Supertrend Green
# #         # 3. Price > VWAP
# #         # 4. RSI > 55 (Strong Momentum - Changed from 50)
# #         if allow_longs and st_dir.iloc[-1] == 1 and close > vwap_val and rsi_val > 55:
# #             # Entry Trigger: Fresh Cross OR Pullback
# #             if st_dir.iloc[-2] == -1 or close < vwap_val * 1.01:
# #                 return {
# #                     "symbol": symbol, "direction": "LONG", "strategy": "Supertrend_Flow",
# #                     "entry": close, "stop": st_line.iloc[-1], "target": close + (3 * atr_val)
# #                 }

# #         # SHORT:
# #         # 1. 15m Trend DOWN
# #         # 2. Supertrend Red
# #         # 3. Price < VWAP
# #         # 4. RSI < 45 (Strong Momentum - Changed from 50)
# #         elif allow_shorts and st_dir.iloc[-1] == -1 and close < vwap_val and rsi_val < 45:
# #             if st_dir.iloc[-2] == 1 or close > vwap_val * 0.99:
# #                 return {
# #                     "symbol": symbol, "direction": "SHORT", "strategy": "Supertrend_Flow",
# #                     "entry": close, "stop": st_line.iloc[-1], "target": close - (3 * atr_val)
# #                 }

# #         # ============================================================
# #         # STRATEGY 2: ICHIMOKU BREAKOUT (Explosive Moves Only)
# #         # ============================================================
# #         tenkan, kijun, senkou_a, senkou_b, _ = ichimoku(df5)
# #         cloud_top = max(senkou_a.iloc[-1], senkou_b.iloc[-1])
# #         cloud_bottom = min(senkou_a.iloc[-1], senkou_b.iloc[-1])

# #         # LONG
# #         if allow_longs and close > cloud_top and tenkan.iloc[-1] > kijun.iloc[-1]:
# #             # Ensure fresh breakout (don't buy if we are already 2% away from cloud)
# #             if df5['close'].iloc[-2] <= cloud_top or tenkan.iloc[-2] <= kijun.iloc[-2]:
# #                 return {
# #                     "symbol": symbol, "direction": "LONG", "strategy": "Ichimoku_Breakout",
# #                     "entry": close, "stop": cloud_bottom, "target": close + (4 * atr_val)
# #                 }
        
# #         # SHORT
# #         elif allow_shorts and close < cloud_bottom and tenkan.iloc[-1] < kijun.iloc[-1]:
# #              if df5['close'].iloc[-2] >= cloud_bottom or tenkan.iloc[-2] >= kijun.iloc[-2]:
# #                 return {
# #                     "symbol": symbol, "direction": "SHORT", "strategy": "Ichimoku_Breakout",
# #                     "entry": close, "stop": cloud_top, "target": close - (4 * atr_val)
# #                 }

# #         # REMOVED: Mean Reversion (RSI_MeanRev) and MACD (Lagging)
# #         # We focus purely on high-probability trend trades now.

# #         return None

# # strategy_engine.py
# import pandas as pd
# from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku, supertrend

# class StrategyEngine:
#     def analyze(self, symbol, data_cache, context):
#         df5 = data_cache.get(5)
#         df15 = data_cache.get(15)
        
#         if df5 is None or len(df5) < 52 or df15 is None or len(df15) < 50: 
#             return None
        
#         close = df5['close'].iloc[-1]
#         regime = context['regime']
        
#         # 0. SAFETY FILTERS
#         if regime == "CHOPPY": return None 
        
#         # Volatility Filter (Slightly relaxed to allow more trades)
#         atr_val = atr(df5).iloc[-1]
#         atr_avg = atr(df5).rolling(10).mean().iloc[-1]
#         if atr_val < (atr_avg * 0.7): return None # Changed 0.8 to 0.7

#         # 1. GOLDEN RULE: 15-Minute Trend Filter
#         ema50_15m = ema(df15['close'], 50).iloc[-1]
#         allow_longs = df15['close'].iloc[-1] > ema50_15m
#         allow_shorts = df15['close'].iloc[-1] < ema50_15m

#         # Pre-calc Indicators
#         vwap_val = vwap(df5).iloc[-1]
#         rsi_val = rsi(df5['close']).iloc[-1]
#         st_line, st_dir = supertrend(df5, period=10, multiplier=3)

#         # ============================================================
#         # STRATEGY 1: SUPERTREND FLOW (1:2 Risk-Reward)
#         # ============================================================
        
#         # LONG
#         if allow_longs and st_dir.iloc[-1] == 1 and close > vwap_val and rsi_val > 55:
#             # Trigger
#             if st_dir.iloc[-2] == -1 or close < vwap_val * 1.01:
#                 stop_loss = st_line.iloc[-1]
#                 risk = close - stop_loss
                
#                 # Minimum Risk Check (Avoid trades with tiny stops that get whipped)
#                 if risk < (atr_val * 0.5): stop_loss = close - (atr_val * 0.5); risk = close - stop_loss
                
#                 return {
#                     "symbol": symbol, "direction": "LONG", "strategy": "Supertrend_Flow",
#                     "entry": close, 
#                     "stop": stop_loss, 
#                     "target": close + (2.0 * risk) # 1:2 Risk Reward
#                 }

#         # SHORT
#         elif allow_shorts and st_dir.iloc[-1] == -1 and close < vwap_val and rsi_val < 45:
#             if st_dir.iloc[-2] == 1 or close > vwap_val * 0.99:
#                 stop_loss = st_line.iloc[-1]
#                 risk = stop_loss - close
                
#                 if risk < (atr_val * 0.5): stop_loss = close + (atr_val * 0.5); risk = stop_loss - close

#                 return {
#                     "symbol": symbol, "direction": "SHORT", "strategy": "Supertrend_Flow",
#                     "entry": close, 
#                     "stop": stop_loss, 
#                     "target": close - (2.0 * risk) # 1:2 Risk Reward
#                 }

#         # ============================================================
#         # STRATEGY 2: ICHIMOKU BREAKOUT (Fixed ATR Target)
#         # ============================================================
#         tenkan, kijun, senkou_a, senkou_b, _ = ichimoku(df5)
#         cloud_top = max(senkou_a.iloc[-1], senkou_b.iloc[-1])
#         cloud_bottom = min(senkou_a.iloc[-1], senkou_b.iloc[-1])

#         # LONG
#         if allow_longs and close > cloud_top and tenkan.iloc[-1] > kijun.iloc[-1]:
#             if df5['close'].iloc[-2] <= cloud_top or tenkan.iloc[-2] <= kijun.iloc[-2]:
#                 return {
#                     "symbol": symbol, "direction": "LONG", "strategy": "Ichimoku_Breakout",
#                     "entry": close, 
#                     "stop": cloud_bottom, 
#                     "target": close + (3 * atr_val) # Fixed 3x ATR target
#                 }
        
#         # SHORT
#         elif allow_shorts and close < cloud_bottom and tenkan.iloc[-1] < kijun.iloc[-1]:
#              if df5['close'].iloc[-2] >= cloud_bottom or tenkan.iloc[-2] >= kijun.iloc[-2]:
#                 return {
#                     "symbol": symbol, "direction": "SHORT", "strategy": "Ichimoku_Breakout",
#                     "entry": close, 
#                     "stop": cloud_top, 
#                     "target": close - (3 * atr_val)
#                 }

#         return None


# strategy_engine.py
import pandas as pd
import config  # <--- Import config to check the flag
from indicators import ema, rsi, bbands, atr, vwap, macd, ichimoku, supertrend

class StrategyEngine:
    def analyze(self, symbol, data_cache, context):
        df5 = data_cache.get(5)
        df15 = data_cache.get(15)
        
        if df5 is None or len(df5) < 52 or df15 is None or len(df15) < 50: 
            return None
        
        close = df5['close'].iloc[-1]
        regime = context['regime']
        
        # 0. SAFETY FILTERS
        if regime == "CHOPPY": return None 
        
        # Volatility Filter
        atr_val = atr(df5).iloc[-1]
        atr_avg = atr(df5).rolling(10).mean().iloc[-1]
        if atr_val < (atr_avg * 0.7): return None

        # 1. GOLDEN RULE: 15-Minute Trend Filter
        ema50_15m = ema(df15['close'], 50).iloc[-1]
        
        # Trend Permissions
        trend_is_up = df15['close'].iloc[-1] > ema50_15m
        trend_is_down = df15['close'].iloc[-1] < ema50_15m
        
        # --- GLOBAL PERMISSIONS ---
        # We combine the 15m Trend check AND the Global Config Flag
        can_long = trend_is_up
        can_short = trend_is_down and config.ALLOW_SHORTS  # <--- THE GATEKEEPER

        # Pre-calc Indicators
        vwap_val = vwap(df5).iloc[-1]
        rsi_val = rsi(df5['close']).iloc[-1]
        st_line, st_dir = supertrend(df5, period=10, multiplier=3)

        # ============================================================
        # STRATEGY 1: SUPERTREND FLOW
        # ============================================================
        
        # LONG
        if can_long and st_dir.iloc[-1] == 1 and close > vwap_val and rsi_val > 55:
            if st_dir.iloc[-2] == -1 or close < vwap_val * 1.01:
                stop_loss = st_line.iloc[-1]
                risk = close - stop_loss
                if risk < (atr_val * 0.5): stop_loss = close - (atr_val * 0.5); risk = close - stop_loss
                
                return {
                    "symbol": symbol, "direction": "LONG", "strategy": "Supertrend_Flow",
                    "entry": close, "stop": stop_loss, "target": close + (2.0 * risk)
                }

        # SHORT (Only runs if ALLOW_SHORTS is True AND Trend is Down)
        elif can_short and st_dir.iloc[-1] == -1 and close < vwap_val and rsi_val < 45:
            if st_dir.iloc[-2] == 1 or close > vwap_val * 0.99:
                stop_loss = st_line.iloc[-1]
                risk = stop_loss - close
                if risk < (atr_val * 0.5): stop_loss = close + (atr_val * 0.5); risk = stop_loss - close

                return {
                    "symbol": symbol, "direction": "SHORT", "strategy": "Supertrend_Flow",
                    "entry": close, "stop": stop_loss, "target": close - (2.0 * risk)
                }

        # ============================================================
        # STRATEGY 2: ICHIMOKU BREAKOUT
        # ============================================================
        tenkan, kijun, senkou_a, senkou_b, _ = ichimoku(df5)
        cloud_top = max(senkou_a.iloc[-1], senkou_b.iloc[-1])
        cloud_bottom = min(senkou_a.iloc[-1], senkou_b.iloc[-1])

        # LONG
        if can_long and close > cloud_top and tenkan.iloc[-1] > kijun.iloc[-1]:
            if df5['close'].iloc[-2] <= cloud_top or tenkan.iloc[-2] <= kijun.iloc[-2]:
                return {
                    "symbol": symbol, "direction": "LONG", "strategy": "Ichimoku_Breakout",
                    "entry": close, "stop": cloud_bottom, "target": close + (3 * atr_val)
                }
        
        # SHORT
        elif can_short and close < cloud_bottom and tenkan.iloc[-1] < kijun.iloc[-1]:
             if df5['close'].iloc[-2] >= cloud_bottom or tenkan.iloc[-2] >= kijun.iloc[-2]:
                return {
                    "symbol": symbol, "direction": "SHORT", "strategy": "Ichimoku_Breakout",
                    "entry": close, "stop": cloud_top, "target": close - (3 * atr_val)
                }

        return None
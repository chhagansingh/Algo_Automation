# indicators.py
import pandas as pd
import numpy as np

# --- FAST INDICATORS ---

def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def rma(series, n):
    return series.ewm(alpha=1/n, adjust=False).mean()

def atr(df, n=14):
    high = df['high']
    low = df['low']
    close = df['close']
    tr1 = high - low
    tr2 = (high - close.shift()).abs()
    tr3 = (low - close.shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return rma(tr, n)

def adx(df, n=14):
    high = df['high']
    low = df['low']
    close = df['close']
    up = high.diff()
    down = -low.diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    plus_dm = pd.Series(plus_dm, index=df.index)
    minus_dm = pd.Series(minus_dm, index=df.index)
    tr1 = high - low
    tr2 = (high - close.shift()).abs()
    tr3 = (low - close.shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    tr_smooth = rma(tr, n)
    plus_di = 100 * (rma(plus_dm, n) / tr_smooth)
    minus_di = 100 * (rma(minus_dm, n) / tr_smooth)
    dx = 100 * (abs(plus_di - minus_di) / (plus_di + minus_di))
    return rma(dx, n)

def supertrend(df, period=7, multiplier=3):
    """
    Optimized Supertrend using Numpy for 100x speedup.
    """
    # 1. Calculate Basic Bands (Vectorized)
    hl2 = (df['high'] + df['low']) / 2
    atr_val = atr(df, period)
    upperband = hl2 + (multiplier * atr_val)
    lowerband = hl2 - (multiplier * atr_val)
    
    # 2. Prepare Numpy Arrays (Much faster than iterating Pandas Series)
    close = df['close'].values
    upper = upperband.values
    lower = lowerband.values
    trend = np.ones(len(df)) # 1 for Bullish, -1 for Bearish
    st = np.zeros(len(df))   # Supertrend Line
    
    # 3. Fast Loop
    # We loop from 1 to len(df), calculating recursive logic
    for i in range(1, len(df)):
        curr_close = close[i]
        prev_close = close[i-1]
        
        # Upper Band Logic
        if upper[i] < upper[i-1] or prev_close > upper[i-1]:
            upper[i] = upper[i]
        else:
            upper[i] = upper[i-1]
        
        # Lower Band Logic
        if lower[i] > lower[i-1] or prev_close < lower[i-1]:
            lower[i] = lower[i]
        else:
            lower[i] = lower[i-1]
            
        # Trend Switching
        prev_trend = trend[i-1]
        
        if prev_trend == 1:
            if curr_close < lower[i]:
                trend[i] = -1
                st[i] = upper[i]
            else:
                trend[i] = 1
                st[i] = lower[i]
        elif prev_trend == -1:
            if curr_close > upper[i]:
                trend[i] = 1
                st[i] = lower[i]
            else:
                trend[i] = -1
                st[i] = upper[i]
                
    return pd.Series(st, index=df.index), pd.Series(trend, index=df.index)

# (Keep your other indicators like bbands, rsi, vwap, macd, ichimoku below exactly as they were)
def bbands(df, n=20, k=2):
    ma = df['close'].rolling(n).mean()
    std = df['close'].rolling(n).std()
    upper = ma + k * std
    lower = ma - k * std
    width = (upper - lower) / ma
    return upper, lower, width

def rsi(series, n=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = rma(up, n)
    ma_down = rma(down, n)
    rs = ma_up / ma_down
    return 100 - (100 / (1 + rs))

def vwap(df):
    q = df['volume']
    p = df['close']
    return (p * q).cumsum() / q.cumsum()

def macd(series, fast=12, slow=26, signal=9):
    exp1 = series.ewm(span=fast, adjust=False).mean()
    exp2 = series.ewm(span=slow, adjust=False).mean()
    macd_line = exp1 - exp2
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram

def ichimoku(df):
    high = df['high']
    low = df['low']
    tenkan = (high.rolling(9).max() + low.rolling(9).min()) / 2
    kijun = (high.rolling(26).max() + low.rolling(26).min()) / 2
    senkou_a = ((tenkan + kijun) / 2).shift(26)
    senkou_b = ((high.rolling(52).max() + low.rolling(52).min()) / 2).shift(26)
    chikou = df['close'].shift(-26)
    return tenkan, kijun, senkou_a, senkou_b, chikou
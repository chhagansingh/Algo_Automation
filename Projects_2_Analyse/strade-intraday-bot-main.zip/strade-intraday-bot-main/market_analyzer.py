# market_analyzer.py
import pandas as pd
from datetime import datetime, timedelta, time
from indicators import ema, atr, adx, ichimoku

class MarketAnalyzer:
    def __init__(self, kite):
        self.kite = kite

    def fetch_data(self, symbol, token):
        """
        Fetches 5m and 15m data for the given token.
        """
        try:
            # Define range (Last 5 days is enough for indicators)
            to_date = datetime.now()
            from_date = to_date - timedelta(days=5)
            
            # Fetch 15 Minute Data
            recs15 = self.kite.historical_data(token, from_date, to_date, "15minute")
            if len(recs15) < 50: return None
            df15 = pd.DataFrame(recs15)
            
            # Fetch 5 Minute Data
            recs5 = self.kite.historical_data(token, from_date, to_date, "5minute")
            if len(recs5) < 50: return None
            df5 = pd.DataFrame(recs5)
            
            return {
                5: df5,
                15: df15
            }
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return None

    def get_market_context(self, df_15m, current_time):
        if df_15m is None or len(df_15m) < 52: return None

        # 1. SESSION
        session = "MID_DAY"
        if time(9, 15) <= current_time < time(10, 15):
            session = "MORNING_OPEN"
        elif time(14, 0) <= current_time < time(15, 15):
            session = "CLOSING_RUSH"

        # 2. REGIME (ADX & EMA)
        try:
            adx_val = adx(df_15m, 14).iloc[-1]
            e20 = ema(df_15m['close'], 20).iloc[-1]
            e50 = ema(df_15m['close'], 50).iloc[-1]
            close = df_15m['close'].iloc[-1]

            regime = "SIDEWAYS"
            if adx_val < 20:
                regime = "CHOPPY"
            elif adx_val > 25:
                if close > e20 > e50:
                    regime = "STRONG_UPTREND"
                elif close < e20 < e50:
                    regime = "STRONG_DOWNTREND"
        except:
            regime = "SIDEWAYS"

        # 3. VOLATILITY
        try:
            atr_val = atr(df_15m, 14).iloc[-1]
            atr_avg = atr(df_15m, 14).rolling(10).mean().iloc[-1]
            volatility = "HIGH" if atr_val > 1.2 * atr_avg else "NORMAL"
        except:
            volatility = "NORMAL"

        return {
            "session": session,
            "regime": regime,
            "volatility": volatility
        }

# main.py
import time
import pandas as pd
import os
import notifications
from datetime import datetime
from config import INSTRUMENTS_FILE, MARKET_OPEN, MARKET_CLOSE, SYSTEM_CLOSE, KITE_API_KEY, ACCESS_TOKEN
from logger_setup import setup_logger
from account_manager import AccountManager
from market_analyzer import MarketAnalyzer
from strategy_engine import StrategyEngine
from smart_executor import SmartExecutor
from kiteconnect import KiteConnect
from stream_manager import StreamManager # <--- NEW IMPORT

log = setup_logger("main")

def main():
    log.info("System Initializing...")
    notifications.send_notification("Trading System Starting Up")
    
    # 1. Connect API
    try:
        token_val = ACCESS_TOKEN
        if os.path.exists("access_token.txt"):
            with open("access_token.txt", "r") as f:
                token_val = f.read().strip()
        
        kite = KiteConnect(api_key=KITE_API_KEY)
        kite.set_access_token(token_val)
    except Exception as e:
        log.error(f"Connection Error: {e}")
        return
    
    # 2. Initialize Modules
    acct = AccountManager()
    market = MarketAnalyzer(kite)
    strategy_engine = StrategyEngine()
    executor = SmartExecutor(kite, acct)
    
    # 3. Load Instruments & Start WebSocket
    instrument_map = {} 
    if os.path.exists("active_instruments.csv"):
        df_inst = pd.read_csv("active_instruments.csv")
        instrument_map = dict(zip(df_inst['symbol'], df_inst['token']))
        log.info(f"Loaded {len(instrument_map)} stocks from Hot List.")
    elif os.path.exists(INSTRUMENTS_FILE):
         df_inst = pd.read_csv(INSTRUMENTS_FILE)
         instrument_map = dict(zip(df_inst['symbol'], df_inst['token']))
    else:
        log.error("No instrument file found.")
        return

    # --- START WEBSOCKET ---
    stream = StreamManager()
    all_tokens = list(instrument_map.values())
    stream.start(all_tokens)
    log.info("WebSocket Stream Started.")
    
    # Wait 2 seconds for prices to populate
    time.sleep(2)

    # Variables for API Rate Limit Optimization
    last_analysis_time = {} # Stores when we last fetched candles for each stock
    ANALYSIS_INTERVAL = 60  # Fetch candles only once every 60 seconds

    # 4. Main Loop
    while True:
        now = datetime.now().time()
        
        # --- CLOSE & SQUARE OFF ---
        if now > SYSTEM_CLOSE:
            if acct.state.positions:
                log.warning("MARKET CLOSED. Force Squaring off...")
                executor.square_off_all()
            stream.stop() # Kill socket
            break

        if now < MARKET_OPEN:
            time.sleep(60)
            continue

        # --- FAST LOOP (1 second) ---
        # Checks Exits using WebSocket Prices (Instant, No API Limit)
        
        current_ltp_map = {}
        
        for symbol, token in instrument_map.items():
            # 1. Get Live Price from WebSocket Memory
            ltp = stream.get_ltp(token)
            
            if ltp == 0: continue # Wait if tick hasn't arrived yet
            current_ltp_map[symbol] = ltp

        # 2. Check Exits (SL/Target) using WebSocket Prices
        executor.check_exits(current_ltp_map)

        # 3. Strategy Analysis (Rate Limited)
        # We only fetch API data if enough time has passed (to avoid Ban)
        if now < MARKET_CLOSE:
            current_timestamp = time.time()
            
            for symbol, token in instrument_map.items():
                
                # Check if we should fetch historical data for this symbol
                last_time = last_analysis_time.get(symbol, 0)
                if (current_timestamp - last_time) < ANALYSIS_INTERVAL:
                    continue # Skip if analyzed recently

                try:
                    # Only analyze if we don't have a position
                    if symbol not in acct.state.positions:
                        # This API call is now safe because we spread it out
                        data_cache = market.fetch_data(symbol, token) 
                        if data_cache:
                            context = market.get_market_context(data_cache[15], now)
                            if context:
                                signal = strategy_engine.analyze(symbol, data_cache, context)
                                if signal:
                                    signal['token'] = token 
                                    executor.execute_entry(signal)
                        
                        # Update timestamp
                        last_analysis_time[symbol] = current_timestamp
                        
                except Exception as e:
                    log.error(f"Analysis Error {symbol}: {e}")
                
                # Small sleep to distribute API calls smoothly
                time.sleep(0.1) 

        # Loop ticks every 1 second for fast Gap Protection
        time.sleep(1)

if __name__ == "__main__":
    main()
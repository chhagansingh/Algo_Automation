# logger_setup.py
import logging
import os
import sys
from datetime import datetime
from config import LOG_DIR

def setup_logger(name="trading_system"):
    os.makedirs(LOG_DIR, exist_ok=True)
    
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers = [] # Clear existing handlers

    # 1. File Handler (Saves all logs to txt)
    today = datetime.now().strftime("%Y-%m-%d")
    file_handler = logging.FileHandler(os.path.join(LOG_DIR, f"system_log_{today}.txt"))
    file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # 2. Console Handler (Prints to terminal)
    console_handler = logging.StreamHandler(sys.stdout)
    console_formatter = logging.Formatter('%(asctime)s - %(message)s') # Simpler for console
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    return logger
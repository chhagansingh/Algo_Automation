# # backtester.py
# import pandas as pd
# from datetime import time
# import config
# from strategy_engine import StrategyEngine
# # Use your local indicators for accuracy
# from indicators import ema, atr, rsi, adx, ichimoku, supertrend # <--- Add supertrend

# # Mock classes to simulate live behavior
# class MockAccount:
#     def __init__(self):
#         self.balance = config.INITIAL_CAPITAL
#         self.positions = []
#         self.trades = []

#     def add_trade(self, entry_time, symbol, strategy, direction, entry, exit_price, pnl):
#         self.balance += pnl
#         self.trades.append({
#             "Time": entry_time, "Symbol": symbol, "Strategy": strategy, 
#             "Direction": direction, "Entry": entry, "Exit": exit_price, "PnL": pnl, 
#             "Balance": self.balance
#         })

# class Backtester:
#     def __init__(self, symbol, filename):
#         self.symbol = symbol
#         try:
#             self.df = pd.read_csv(filename)
#             self.df['date'] = pd.to_datetime(self.df['date'])
#         except FileNotFoundError:
#             print(f"Error: File {filename} not found. Run data_downloader.py first.")
#             exit()
            
#         self.strategy_engine = StrategyEngine()
#         self.account = MockAccount()
#         self.open_position = None

#     def run(self):
#         print(f"Starting Backtest on {self.symbol} ({len(self.df)} candles)...")
        
#         # We need at least 52 candles for Ichimoku/EMA50 calculations
#         for i in range(52, len(self.df)):
#             # 1. Slice Data: Simulate "what we know at time i"
#             current_slice_5m = self.df.iloc[:i+1].copy()
#             current_candle = current_slice_5m.iloc[-1]
#             current_time = current_candle['date'].time()
            
#             # 2. Resample to 15m for Regime Detection
#             current_slice_15m = current_slice_5m.set_index('date').resample('15min').agg({
#                 'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'
#             }).dropna()

#             if len(current_slice_15m) < 52: continue

#             # 3. BUILD CONTEXT (Fixes the TypeError)
#             # We must construct the full dictionary expected by StrategyEngine
#             context = self._build_context(current_slice_15m, current_time)
            
#             # 4. Check Exit if Position is Open
#             if self.open_position:
#                 self._check_exit(current_candle)
#                 continue # Don't enter if already open

#             # 5. Run Strategy Engine
#             # Construct cache dict exactly like the live system
#             data_cache = {5: current_slice_5m, 15: current_slice_15m}
            
#             signal = self.strategy_engine.analyze(self.symbol, data_cache, context)
            
#             if signal:
#                 self._execute_entry(signal, current_candle['date'])

#         self._generate_report()

#     def _build_context(self, df_15m, current_time):
#         """
#         Replicates logic from market_analyzer.py to create the context dictionary.
#         """
#         # A. Determine Session
#         session = "MID_DAY"
#         if time(9, 15) <= current_time < time(10, 15):
#             session = "MORNING_OPEN"
#         elif time(14, 0) <= current_time < time(15, 15):
#             session = "CLOSING_RUSH"

#         # B. Determine Regime
#         try:
#             adx_val = adx(df_15m, 14).iloc[-1]
#             e20 = ema(df_15m['close'], 20).iloc[-1]
#             e50 = ema(df_15m['close'], 50).iloc[-1]
#             close = df_15m['close'].iloc[-1]

#             regime = "SIDEWAYS"
#             if adx_val > 25:
#                 if close > e20 > e50:
#                     regime = "STRONG_UPTREND"
#                 elif close < e20 < e50:
#                     regime = "STRONG_DOWNTREND"
#         except:
#             regime = "SIDEWAYS" # Fallback
            
#         # C. Determine Volatility (Optional for now, but good to have)
#         volatility = "NORMAL"

#         return {
#             "session": session,
#             "regime": regime,
#             "volatility": volatility
#         }

#     def _execute_entry(self, signal, time):
#         # Calculate Quantity based on Risk (Config)
#         risk_per_share = abs(signal['entry'] - signal['stop'])
#         if risk_per_share == 0: return
        
#         risk_capital = self.account.balance * config.MAX_RISK_PER_TRADE
#         qty = int(risk_capital / risk_per_share)
        
#         if qty > 0:
#             self.open_position = {
#                 "symbol": signal['symbol'], "direction": signal['direction'],
#                 "entry": signal['entry'], "stop": signal['stop'], "target": signal['target'],
#                 "qty": qty, "strategy": signal['strategy'], "entry_time": time
#             }

#     def _check_exit(self, candle):
#         pos = self.open_position
        
#         exit_price = None
#         reason = None
        
#         low = candle['low']
#         high = candle['high']

#         if pos['direction'] == 'LONG':
#             if low <= pos['stop']: 
#                 exit_price = pos['stop']
#                 reason = "STOP_LOSS"
#             elif high >= pos['target']:
#                 exit_price = pos['target']
#                 reason = "TARGET"
        
#         elif pos['direction'] == 'SHORT':
#             if high >= pos['stop']:
#                 exit_price = pos['stop']
#                 reason = "STOP_LOSS"
#             elif low <= pos['target']:
#                 exit_price = pos['target']
#                 reason = "TARGET"

#         if exit_price:
#             pnl = (exit_price - pos['entry']) * pos['qty'] if pos['direction'] == 'LONG' else (pos['entry'] - exit_price) * pos['qty']
#             self.account.add_trade(pos['entry_time'], pos['symbol'], pos['strategy'], pos['direction'], pos['entry'], exit_price, pnl)
#             self.open_position = None # Close position

#     def _generate_report(self):
#         print("\n--- BACKTEST RESULTS ---")
#         df_trades = pd.DataFrame(self.account.trades)
#         if df_trades.empty:
#             print("No trades generated.")
#             return

#         total_trades = len(df_trades)
#         wins = len(df_trades[df_trades['PnL'] > 0])
#         win_rate = (wins / total_trades) * 100 if total_trades > 0 else 0
#         total_pnl = df_trades['PnL'].sum()
        
#         print(f"Total Trades: {total_trades}")
#         print(f"Win Rate:     {win_rate:.2f}%")
#         print(f"Total PnL:    {total_pnl:.2f}")
#         print(f"Final Capital:{self.account.balance:.2f}")
        
#         df_trades.to_csv("backtest_results.csv", index=False)
#         print("Detailed logs saved to 'backtest_results.csv'")

# if __name__ == "__main__":
#     # Ensure data is downloaded
#     bt = Backtester("INFY", "data/INFY_5min.csv")
#     bt.run()

# backtester.py
import pandas as pd
import json
import time
from datetime import time as dtime
import config
from strategy_engine import StrategyEngine
from indicators import ema, atr, rsi, adx, ichimoku, supertrend

# --- MOCK ACCOUNT (State Manager) ---
class MockAccount:
    def __init__(self):
        self.balance = config.INITIAL_CAPITAL
        self.initial_capital = config.INITIAL_CAPITAL
        self.positions = {} 
        self.trades = []
        self._save_state()

    def add_trade(self, entry_time, symbol, strategy, direction, entry, exit_price, pnl):
        self.balance += pnl
        trade_record = {
            "exit_time": str(entry_time),
            "symbol": symbol,
            "direction": direction,
            "realized_pnl": pnl,
            "exit_price": exit_price,
            "strategy": strategy
        }
        self.trades.append(trade_record)
        if symbol in self.positions:
            del self.positions[symbol]
        self._save_state()

    def open_pos(self, symbol, pos_data):
        self.positions[symbol] = {
            "entry_time": str(pos_data['entry_time']),
            "symbol": symbol,
            "direction": pos_data['direction'],
            "qty": pos_data['qty'],
            "entry_price": pos_data['entry'],
            "stop_price": pos_data['stop'],
            "target_price": pos_data['target'],
            "strategy": pos_data['strategy']
        }
        self._save_state()

    def _save_state(self):
        # Writes to JSON for the Dashboard
        data = {
            "available_cash": self.balance,
            "total_pnl": self.balance - self.initial_capital,
            "positions": self.positions,
            "trade_history": self.trades
        }
        try:
            with open(config.STATE_FILE, 'w') as f:
                json.dump(data, f, default=str)
        except: pass

# --- UPDATED BACKTESTER CLASS ---
class Backtester:
    # MODIFIED: Accepts 'shared_account' argument
    def __init__(self, symbol, filename, shared_account=None):
        self.symbol = symbol
        try:
            self.df = pd.read_csv(filename)
            self.df['date'] = pd.to_datetime(self.df['date'])
        except FileNotFoundError:
            print(f"Error: File {filename} not found.")
            return
            
        self.strategy_engine = StrategyEngine()
        
        # USE SHARED ACCOUNT IF PROVIDED, ELSE CREATE NEW
        self.account = shared_account if shared_account else MockAccount()
        self.open_position = None

    def run(self):
        if not hasattr(self, 'df'): return # Safety check if file load failed
        
        print(f"--> Processing {self.symbol}...")
        
        for i in range(52, len(self.df)):
            # Optional: Small delay to let you see dashboard updates
            # time.sleep(0.01) 
            
            start_index = max(0, i - 500)
            current_slice_5m = self.df.iloc[start_index : i+1].copy()
            current_candle = current_slice_5m.iloc[-1]
            current_time = current_candle['date'].time()
            
            current_slice_15m = current_slice_5m.set_index('date').resample('15min').agg({
                'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'
            }).dropna()

            if len(current_slice_15m) < 52: continue

            context = self._build_context(current_slice_15m, current_time)
            
            if self.open_position:
                self._check_exit(current_candle)
                continue 

            data_cache = {5: current_slice_5m, 15: current_slice_15m}
            signal = self.strategy_engine.analyze(self.symbol, data_cache, context)
            
            if signal:
                self._execute_entry(signal, current_candle['date'])

    # ... (Keep _build_context, _execute_entry, _check_exit logic exactly as before) ...
    # ... Only change is ensuring they use self.account methods ...

    def _build_context(self, df_15m, current_time):
        session = "MID_DAY"
        if dtime(9, 15) <= current_time < dtime(10, 15): session = "MORNING_OPEN"
        elif dtime(14, 0) <= current_time < dtime(15, 15): session = "CLOSING_RUSH"
        try:
            adx_val = adx(df_15m, 14).iloc[-1]
            e20 = ema(df_15m['close'], 20).iloc[-1]
            e50 = ema(df_15m['close'], 50).iloc[-1]
            close = df_15m['close'].iloc[-1]
            regime = "SIDEWAYS"
            if adx_val < 20: regime = "CHOPPY"
            elif adx_val > 25:
                if close > e20 > e50: regime = "STRONG_UPTREND"
                elif close < e20 < e50: regime = "STRONG_DOWNTREND"
        except: regime = "SIDEWAYS"
        return {"session": session, "regime": regime, "volatility": "NORMAL"}

    def _execute_entry(self, signal, time):
        risk_per_share = abs(signal['entry'] - signal['stop'])
        if risk_per_share == 0: return
        
        risk_capital = self.account.balance * config.MAX_RISK_PER_TRADE
        qty = int(risk_capital / risk_per_share)
        
        if qty > 0:
            self.open_position = {
                "symbol": signal['symbol'], "direction": signal['direction'],
                "entry": signal['entry'], "stop": signal['stop'], "target": signal['target'],
                "qty": qty, "strategy": signal['strategy'], "entry_time": time
            }
            # Update Dashboard via shared account
            self.account.open_pos(signal['symbol'], self.open_position)

    def _check_exit(self, candle):
        pos = self.open_position
        exit_price = None
        low = candle['low']
        high = candle['high']

        if pos['direction'] == 'LONG':
            if low <= pos['stop']: exit_price = pos['stop']
            elif high >= pos['target']: exit_price = pos['target']
        elif pos['direction'] == 'SHORT':
            if high >= pos['stop']: exit_price = pos['stop']
            elif low <= pos['target']: exit_price = pos['target']

        if exit_price:
            pnl = (exit_price - pos['entry']) * pos['qty'] if pos['direction'] == 'LONG' else (pos['entry'] - exit_price) * pos['qty']
            self.account.add_trade(pos['entry_time'], pos['symbol'], pos['strategy'], pos['direction'], pos['entry'], exit_price, pnl)
            self.open_position = None
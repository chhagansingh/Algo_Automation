# smart_executor.py
import time
import notifications
from kiteconnect import KiteConnect
from config import PAPER_MODE
from logger_setup import setup_logger
from account_manager import Position

log = setup_logger("executor")

class SmartExecutor:
    def __init__(self, kite, account_manager):
        self.kite = kite
        self.acct = account_manager

    def execute_entry(self, signal):
        # ... (Entry logic remains exactly the same) ...
        qty = self.acct.get_position_size(signal['entry'], signal['stop'])
        if qty <= 0:
            log.warning(f"Skipping {signal['symbol']}: Qty 0 (Funds/Risk)")
            return

        log.info(f"Executing {signal['direction']} on {signal['symbol']} Qty: {qty}")

        # --- TELEGRAM ALERT (NEW) ---
        notifications.send_trade_notification(
            self.kite,
            signal['symbol'],
            "BUY" if signal['direction'] == "LONG" else "SELL",
            qty,
            signal['entry'],
            f"Entry Strategy: {signal['strategy']}"
        )
        # ----------------------------

        if not PAPER_MODE:
            try:
                txn_type = self.kite.TRANSACTION_TYPE_BUY if signal['direction'] == "LONG" else self.kite.TRANSACTION_TYPE_SELL
                order_id = self.kite.place_order(
                    tradingsymbol=signal['symbol'],
                    exchange=self.kite.EXCHANGE_NSE,
                    transaction_type=txn_type,
                    quantity=qty,
                    order_type=self.kite.ORDER_TYPE_MARKET,
                    product=self.kite.PRODUCT_MIS,
                    validity=self.kite.VALIDITY_DAY
                )
                log.info(f"Live Order Placed: {order_id}")
            except Exception as e:
                log.error(f"Order Execution Failed: {e}")
                return

        pos = Position(
            symbol=signal['symbol'], qty=qty, entry_price=signal['entry'],
            direction=signal['direction'], stop_loss=signal['stop'],
            target=signal['target'], strategy=signal['strategy'],
            entry_time=time.strftime("%Y-%m-%d %H:%M:%S")
        )
        self.acct.add_position(pos)

    def check_exits(self, current_prices):
        """
        Monitors for Targets and Stop Losses.
        Includes GAP PROTECTION logic.
        """
        # Loop through active positions
        for symbol, pos in list(self.acct.state.positions.items()):
            if symbol not in current_prices: continue
            ltp = current_prices[symbol]
            
            exit_reason = None
            gap_warning = False
            
            # --- LONG EXIT LOGIC ---
            if pos.direction == "LONG":
                # GAP DOWN PROTECTION: Check if LTP is BELOW Stop Loss
                if ltp <= pos.stop_loss: 
                    exit_reason = "STOP_LOSS"
                    # Check for large gap (slippage > 0.5%)
                    if ltp < (pos.stop_loss * 0.995):
                        gap_warning = True
                
                elif ltp >= pos.target: 
                    exit_reason = "TARGET"
            
            # --- SHORT EXIT LOGIC ---
            elif pos.direction == "SHORT":
                # GAP UP PROTECTION: Check if LTP is ABOVE Stop Loss
                if ltp >= pos.stop_loss: 
                    exit_reason = "STOP_LOSS"
                    # Check for large gap (slippage > 0.5%)
                    if ltp > (pos.stop_loss * 1.005):
                        gap_warning = True
                        
                elif ltp <= pos.target: 
                    exit_reason = "TARGET"
            
            # EXECUTE EXIT
            if exit_reason:
                if gap_warning:
                    log.warning(f"CRITICAL: GAP DETECTED on {symbol}! Price jumped past Stop Loss. Exiting immediately.")
                
                self._execute_exit(pos, ltp, exit_reason)

    def square_off_all(self):
        # (Square off logic remains the same)
        positions = list(self.acct.state.positions.items())
        if not positions: return

        log.info(f"--- AUTO SQUARE-OFF TRIGGERED for {len(positions)} positions ---")

        for symbol, pos in positions:
            if not PAPER_MODE:
                try:
                    txn_type = self.kite.TRANSACTION_TYPE_SELL if pos.direction == "LONG" else self.kite.TRANSACTION_TYPE_BUY
                    self.kite.place_order(
                        tradingsymbol=pos.symbol,
                        exchange=self.kite.EXCHANGE_NSE,
                        transaction_type=txn_type,
                        quantity=pos.qty,
                        order_type=self.kite.ORDER_TYPE_MARKET,
                        product=self.kite.PRODUCT_MIS
                    )
                except Exception as e:
                    log.error(f"Failed to Square off {symbol}: {e}")
            
            close_price = pos.entry_price 
            try:
                quote = self.kite.ltp(f"NSE:{symbol}")
                if quote:
                    close_price = quote[f"NSE:{symbol}"]['last_price']
            except: pass

            pnl = (close_price - pos.entry_price) * pos.qty if pos.direction == "LONG" else (pos.entry_price - close_price) * pos.qty
            self.acct.log_trade(pos, close_price, pnl)
            log.info(f"Squared Off {symbol} | PnL: {pnl:.2f}")

            # --- TELEGRAM ALERT (NEW) ---
            notifications.send_trade_notification(
                self.kite,
                symbol,
                "SQUARE OFF",
                pos.qty,
                close_price,
                "End of Day Auto-Squareoff"
            )
            # ----------------------------

    def _execute_exit(self, pos, price, reason):
        # (Exit logic remains the same)
        if not PAPER_MODE:
            try:
                txn_type = self.kite.TRANSACTION_TYPE_SELL if pos.direction == "LONG" else self.kite.TRANSACTION_TYPE_BUY
                self.kite.place_order(
                    tradingsymbol=pos.symbol,
                    exchange=self.kite.EXCHANGE_NSE,
                    transaction_type=txn_type,
                    quantity=pos.qty,
                    order_type=self.kite.ORDER_TYPE_MARKET,
                    product=self.kite.PRODUCT_MIS
                )
            except Exception as e:
                log.error(f"Exit Failed: {e}")
                return

        # --- TELEGRAM ALERT (NEW) ---
        notifications.send_trade_notification(
            self.kite,
            pos.symbol,
            "SELL" if pos.direction == "LONG" else "BUY",
            pos.qty,
            price,
            f"Exit Trigger: {reason}"
        )
        # ----------------------------

        pnl = (price - pos.entry_price) * pos.qty if pos.direction == "LONG" else (pos.entry_price - price) * pos.qty
        self.acct.log_trade(pos, price, pnl)
        log.info(f"Exited {pos.symbol} ({pos.direction}) | Reason: {reason} | PnL: {pnl:.2f}")
# NIFTY Intraday Multi-Strategy Engine (VSCode-ready)

Quick start:
1. Create a virtual env: `python -m venv .venv` and activate it.
2. `pip install -r requirements.txt`
3. Set environment variables: `KITE_API_KEY`, `KITE_ACCESS_TOKEN`, optionally `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`.
4. Build instruments map: `python tools/build_instruments_map.py` (will create `instruments_map.csv`).
5. Run unit tests: `pytest tests/`
6. Start paper run: ensure `PAPER_MODE=True` in `config.py`, then `python main.py`.

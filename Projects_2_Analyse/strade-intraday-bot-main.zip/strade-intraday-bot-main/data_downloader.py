# data_downloader.py
import os
import pandas as pd
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import config

# Define your Universe here (Symbol: Token)
# You can find tokens in the full instrument dump from Zerodha
UNIVERSE = {
    "ABB": 3329,
    "ADANIENT": 6401,
    "APOLLOHOSP": 40193,
    "ASIANPAINT": 60417,
    "BAJAJHLDNG": 78081,
    "BAJFINANCE": 81153,
    "BEL": 98049,
    "HDFCLIFE": 119553,
    "MAZDOCK": 130305,
    "BPCL": 134657,
    "BRITANNIA": 140033,
    "CHOLAFIN": 175361,
    "CIPLA": 177665,
    "CGPOWER": 194561,
    "DRREDDY": 225537,
    "EICHERMOT": 232961,
    "GRASIM": 315393,
    "AMBUJACEM": 325121,
    "HDFCBANK": 341249,
    "HINDALCO": 348929,
    "HINDUNILVR": 356865,
    "HINDZINC": 364545,
    "INDHOTEL": 387073,
    "INFY": 408065,
    "IOC": 415745,
    "ITC": 424961,
    "KOTAKBANK": 492033,
    "TRENT": 502785,
    "IRFC": 519425,
    "M&M": 519937,
    "BOSCHLTD": 558337,
    "HAL": 589569,
    "ONGC": 633601,
    "PIDILITIND": 681985,
    "RELIANCE": 738561,
    "SBIN": 779521,
    "VEDL": 784129,
    "SHREECEM": 794369,
    "SIEMENS": 806401,
    "LODHA": 824321,
    "SUNPHARMA": 857857,
    "TATAPOWER": 877057,
    "TATACONSUM": 878593,
    "TMPV": 884737,
    "TATASTEEL": 895745,
    "TITAN": 897537,
    "TORNTPHARM": 900609,
    "ADANIGREEN": 912129,
    "WIPRO": 969473,
    "MOTHERSON": 1076225,
    "SHRIRAMFIN": 1102337,
    "BANKBARODA": 1195009,
    "GAIL": 1207553,
    "ICICIBANK": 1270529,
    "ETERNAL": 1304833,
    "AXISBANK": 1510401,
    "JINDALSTEL": 1723649,
    "HCLTECH": 1850625,
    "ZYDUSLIFE": 2029825,
    "TVSMOTOR": 2170625,
    "LICI": 2426881,
    "HAVELLS": 2513665,
    "GODREJCP": 2585345,
    "ADANIENSOL": 2615553,
    "UNITDSPR": 2674433,
    "BHARTIARTL": 2714625,
    "PNB": 2730497,
    "CANBK": 2763265,
    "DIVISLAB": 2800641,
    "MARUTI": 2815745,
    "INDIGO": 2865921,
    "LT": 2939649,
    "ULTRACEMCO": 2952193,
    "TCS": 2953217,
    "NTPC": 2977281,
    "JSWSTEEL": 3001089,
    "SOLARINDS": 3412993,
    "TECHM": 3465729,
    "NAUKRI": 3520257,
    "PFC": 3660545,
    "DLF": 3771393,
    "POWERGRID": 3834113,
    "ADANIPORTS": 3861249,
    "RECLTD": 3930881,
    "BAJAJ-AUTO": 4267265,
    "BAJAJFINSV": 4268801,
    "ADANIPOWER": 4451329,
    "LTIM": 4561409,
    "JSWENERGY": 4574465,
    "NESTLEIND": 4598529,
    "JIOFIN": 4644609,
    "VBL": 4843777,
    "DMART": 5097729,
    "COALINDIA": 5215745,
    "ICICIGI": 5573121,
    "SBILIFE": 5582849,
    "MAXHEALTH": 5728513,
    "BAJAJHFL": 6469121,
    "HYUNDAI": 6616065,
    "ENRIN": 193758977
}

def download_universe(days=356):
    os.makedirs("data", exist_ok=True)
    
    try:
        access_token = open("access_token.txt", "r").read().strip()
        kite = KiteConnect(api_key=config.KITE_API_KEY)
        kite.set_access_token(access_token)
    except Exception as e:
        print(f"Login failed: {e}")
        return

    to_date = datetime.now()
    from_date = to_date - timedelta(days=days)

    print(f"--- Downloading Data for {len(UNIVERSE)} symbols ---")
    
    for symbol, token in UNIVERSE.items():
        print(f"Fetching {symbol}...", end=" ")
        try:
            records = kite.historical_data(token, from_date, to_date, "5minute")
            if records:
                df = pd.DataFrame(records)
                df['date'] = pd.to_datetime(df['date'])
                df.to_csv(f"data/{symbol}_5min.csv", index=False)
                print("Done.")
            else:
                print("No Data.")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    download_universe(days=60)
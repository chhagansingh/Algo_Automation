# backtest/backtest_engine.py
"""
Minimal BacktestEngine compatible with run_backtest.py.

Provides:
- run_sample_strategy(df): simple SMA crossover example
- self.trades: list of trade dicts
- trades_df(): helper to convert trades to a pandas DataFrame

This is intentionally small and readable — extend with commissions, slippage,
order types, and position sizing as needed.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
import pandas as pd


@dataclass
class BacktestEngine:
    initial_capital: float = 100000.0
    cash: float = None
    position: float = 0.0   # number of shares (positive = long)
    entry_price: Optional[float] = None
    trades: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.cash = float(self.initial_capital)
        self.position = 0.0
        self.entry_price = None
        self.trades = []

    # ---- compatible sample runner expected by run_backtest.py ----
    def run_sample_strategy(self, df: pd.DataFrame):
        """
        Simple SMA crossover:
        - Enter long when SMA_fast > SMA_slow (not in position)
        - Exit when SMA_fast <= SMA_slow (if in position)
        Trades recorded to self.trades as dicts with entry/exit times & PnL.
        """
        if df is None or df.empty:
            return

        # ensure 'close' present
        if "close" not in df.columns:
            raise ValueError("DataFrame must contain 'close' column")

        # simple SMA params (configurable)
        fast = 5
        slow = 20

        df = df.copy()
        df["sma_fast"] = df["close"].rolling(window=fast, min_periods=1).mean()
        df["sma_slow"] = df["close"].rolling(window=slow, min_periods=1).mean()

        in_position = False
        entry_ts = None
        entry_price = None
        size = 0.0

        for ts, row in df.iterrows():
            price = float(row["close"])
            sma_f = float(row["sma_fast"])
            sma_s = float(row["sma_slow"])

            # entry
            if (sma_f > sma_s) and (not in_position):
                # example sizing: use 10% of current cash
                risk_amount = 0.10 * self.cash
                if price > 0:
                    size = risk_amount / price
                    entry_price = price
                    entry_ts = ts
                    in_position = True
                    self.cash -= size * price

            # exit
            elif (sma_f <= sma_s) and in_position:
                exit_price = price
                exit_ts = ts
                pnl = (exit_price - entry_price) * size
                self.trades.append({
                    "entry_ts": entry_ts,
                    "exit_ts": exit_ts,
                    "entry_price": float(entry_price),
                    "exit_price": float(exit_price),
                    "size": float(size),
                    "pnl": float(pnl),
                })
                self.cash += size * exit_price
                in_position = False
                entry_price = None
                entry_ts = None
                size = 0.0

        # close remaining position at last price
        if in_position and entry_price is not None:
            last_price = float(df["close"].iloc[-1])
            exit_ts = df.index[-1]
            pnl = (last_price - entry_price) * size
            self.trades.append({
                "entry_ts": entry_ts,
                "exit_ts": exit_ts,
                "entry_price": float(entry_price),
                "exit_price": float(last_price),
                "size": float(size),
                "pnl": float(pnl),
            })
            self.cash += size * last_price

    # ---- helper to return trades as DataFrame ----
    def trades_df(self) -> pd.DataFrame:
        if not self.trades:
            return pd.DataFrame(columns=["entry_ts", "exit_ts", "entry_price", "exit_price", "size", "pnl"])
        return pd.DataFrame(self.trades)

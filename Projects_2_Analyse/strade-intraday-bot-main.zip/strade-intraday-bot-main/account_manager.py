# # account_manager.py
# import json
# import os
# import csv
# from datetime import datetime
# from dataclasses import dataclass, field, asdict
# from config import STATE_FILE, LOG_DIR, INITIAL_CAPITAL, NO_LEVERAGE, MAX_RISK_PER_TRADE
# from logger_setup import setup_logger

# log = setup_logger("account")

# @dataclass
# class Position:
#     symbol: str
#     qty: int
#     entry_price: float
#     direction: str # 'LONG' or 'SHORT'
#     stop_loss: float
#     target: float
#     strategy: str
#     entry_time: str

# @dataclass
# class AccountState:
#     available_cash: float
#     total_pnl: float = 0.0
#     positions: dict = field(default_factory=dict)

# class AccountManager:
#     def __init__(self):
#         self.state = self._load_state()
#         self.csv_file = self._setup_csv()

#     def _load_state(self):
#         if os.path.exists(STATE_FILE):
#             try:
#                 with open(STATE_FILE, 'r') as f:
#                     data = json.load(f)
#                     # Reconstruct Position objects
#                     positions = {k: Position(**v) for k,v in data.get('positions', {}).items()}
#                     return AccountState(available_cash=data['available_cash'], total_pnl=data.get('total_pnl', 0.0), positions=positions)
#             except Exception as e:
#                 log.error(f"State load error: {e}")
#         return AccountState(available_cash=INITIAL_CAPITAL)

#     def _save_state(self):
#         data = asdict(self.state)
#         with open(STATE_FILE, 'w') as f:
#             json.dump(data, f, default=str, indent=4)

#     def _setup_csv(self):
#         # Create a single CSV file for the day
#         today = datetime.now().strftime("%Y-%m-%d")
#         fname = os.path.join(LOG_DIR, f"trades_session_{today}.csv")
        
#         # Initialize header if file doesn't exist
#         if not os.path.exists(fname):
#             with open(fname, 'w', newline='') as f:
#                 writer = csv.writer(f)
#                 writer.writerow(["Time", "Symbol", "Strategy", "Direction", "Qty", "Entry", "Exit", "PnL", "Result"])
#         return fname

#     def log_trade(self, pos: Position, exit_price: float, pnl: float):
#         # Append trade directly to CSV
#         with open(self.csv_file, 'a', newline='') as f:
#             writer = csv.writer(f)
#             result = "WIN" if pnl > 0 else "LOSS"
#             exit_time = datetime.now().strftime("%H:%M:%S")
#             writer.writerow([exit_time, pos.symbol, pos.strategy, pos.direction, pos.qty, pos.entry_price, exit_price, round(pnl, 2), result])
        
#         # Update State
#         self.state.total_pnl += pnl
#         self.state.available_cash += (pos.qty * pos.entry_price) + pnl
#         del self.state.positions[pos.symbol]
#         self._save_state()
#         log.info(f"Trade Closed: {pos.symbol} | PnL: {pnl:.2f} | Logged to CSV")

#     def add_position(self, pos: Position):
#         cost = pos.qty * pos.entry_price
#         self.state.available_cash -= cost
#         self.state.positions[pos.symbol] = pos
#         self._save_state()
#         log.info(f"Position Added: {pos.symbol} ({pos.strategy})")

#     def get_position_size(self, price, stop_loss):
#         # Risk-based sizing
#         risk_per_share = abs(price - stop_loss)
#         if risk_per_share == 0: return 0
        
#         risk_amt = self.state.available_cash * MAX_RISK_PER_TRADE
#         qty_risk = int(risk_amt / risk_per_share)
        
#         # Cash-based sizing (No Leverage)
#         qty_cash = int(self.state.available_cash / price)
        
#         return min(qty_risk, qty_cash)

# account_manager.py
import json
import os
import csv
from datetime import datetime
from dataclasses import dataclass, field, asdict
from config import STATE_FILE, LOG_DIR, INITIAL_CAPITAL, NO_LEVERAGE, MAX_RISK_PER_TRADE, MAX_CAPITAL_PER_TRADE_PCT
from logger_setup import setup_logger

log = setup_logger("account")

@dataclass
class Position:
    symbol: str
    qty: int
    entry_price: float
    direction: str 
    stop_loss: float
    target: float
    strategy: str
    entry_time: str

@dataclass
class AccountState:
    available_cash: float
    total_pnl: float = 0.0
    positions: dict = field(default_factory=dict)

class AccountManager:
    def __init__(self):
        self.state = self._load_state()
        self.csv_file = self._setup_csv()

    def _load_state(self):
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, 'r') as f:
                    data = json.load(f)
                    # Check for compatibility
                    if 'available_cash' not in data:
                         return AccountState(available_cash=INITIAL_CAPITAL)

                    positions = {k: Position(**v) for k,v in data.get('positions', {}).items()}
                    return AccountState(available_cash=data['available_cash'], total_pnl=data.get('total_pnl', 0.0), positions=positions)
            except Exception as e:
                log.error(f"State load error: {e}")
        return AccountState(available_cash=INITIAL_CAPITAL)

    def _save_state(self):
        data = asdict(self.state)
        with open(STATE_FILE, 'w') as f:
            json.dump(data, f, default=str, indent=4)

    def _setup_csv(self):
        today = datetime.now().strftime("%Y-%m-%d")
        fname = os.path.join(LOG_DIR, f"trades_session_{today}.csv")
        if not os.path.exists(fname):
            with open(fname, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Time", "Symbol", "Strategy", "Direction", "Qty", "Entry", "Exit", "PnL", "Result"])
        return fname

    def log_trade(self, pos: Position, exit_price: float, pnl: float):
        with open(self.csv_file, 'a', newline='') as f:
            writer = csv.writer(f)
            result = "WIN" if pnl > 0 else "LOSS"
            exit_time = datetime.now().strftime("%H:%M:%S")
            writer.writerow([exit_time, pos.symbol, pos.strategy, pos.direction, pos.qty, pos.entry_price, exit_price, round(pnl, 2), result])
        
        self.state.total_pnl += pnl
        self.state.available_cash += (pos.qty * pos.entry_price) + pnl
        del self.state.positions[pos.symbol]
        self._save_state()
        log.info(f"Trade Closed: {pos.symbol} | PnL: {pnl:.2f}")

    def add_position(self, pos: Position):
        cost = pos.qty * pos.entry_price
        self.state.available_cash -= cost
        self.state.positions[pos.symbol] = pos
        self._save_state()
        log.info(f"Position Added: {pos.symbol} Qty: {pos.qty}")

    def get_position_size(self, price, stop_loss):
        # 1. CALCULATE TOTAL ACCOUNT VALUE (Cash + Invested)
        # This prevents the risk/allocation calculations from shrinking purely because cash is tied up.
        invested_capital = sum(p.qty * p.entry_price for p in self.state.positions.values())
        total_account_value = self.state.available_cash + invested_capital
        
        # 2. RISK-BASED SIZING (The Loss Limit)
        # How much are we willing to LOSE? (e.g. 1% of Total Value)
        risk_per_share = abs(price - stop_loss)
        if risk_per_share == 0: return 0
        
        max_risk_amt = total_account_value * MAX_RISK_PER_TRADE
        qty_risk = int(max_risk_amt / risk_per_share)
        
        # 3. ALLOCATION-BASED SIZING (The Diversification Limit)
        # How much capital can we COMMIT? (e.g. 20% of Total Value)
        max_alloc_amt = total_account_value * MAX_CAPITAL_PER_TRADE_PCT
        qty_alloc = int(max_alloc_amt / price)
        
        # 4. CASH-BASED SIZING (The Hard Limit)
        # We physically cannot spend more cash than we have available.
        qty_cash = int(self.state.available_cash / price)
        
        # 5. FINAL SIZING
        # We take the smallest number to satisfy ALL constraints.
        final_qty = min(qty_risk, qty_alloc, qty_cash)
        
        # Debug Log for transparency
        # log.info(f"Sizing Calc | RiskQty: {qty_risk} | AllocQty: {qty_alloc} | CashQty: {qty_cash} -> Final: {final_qty}")
        
        return final_qty
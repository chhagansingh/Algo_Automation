import logging
import requests
import config

def fetch_dashboard_stats(kite):
    """
    Fetches available cash and current day's realized/unrealized PnL.
    """
    try:
        # 1. Get Available Cash
        margins = kite.margins(segment="equity")
        available_cash = margins['available']['cash']

        # 2. Get Day's PnL
        positions = kite.positions()
        day_positions = positions['day']

        realized_pnl = 0
        unrealized_pnl = 0

        for pos in day_positions:
            realized_pnl += pos['pnl']
            unrealized_pnl += pos['m2m'] 

        total_pnl = realized_pnl + unrealized_pnl

        return {
            "cash": available_cash,
            "realized": realized_pnl,
            "unrealized": unrealized_pnl,
            "total": total_pnl
        }
    except Exception as e:
        # If stats fail (e.g. during Paper Mode without API), return valid placeholders
        return {"cash": 0.0, "realized": 0.0, "unrealized": 0.0, "total": 0.0}

def send_trade_notification(kite, symbol, signal, quantity, price, reason):
    """
    Sends a rich formatted message to Telegram.
    """
    # 1. Master Switch Check
    if not config.ENABLE_TELEGRAM:
        return

    try:
        stats = fetch_dashboard_stats(kite)
        
        # Emoji Logic
        signal_emoji = "🟢" if "BUY" in signal or "LONG" in signal else "🔴"
        if "SQUARE" in signal: signal_emoji = "⚠️"
        
        pnl_emoji = "✅" if stats['total'] >= 0 else "🔻"

        # Message Construction
        message = (
            f"{signal_emoji} **TRADE ALERT: {signal}**\n"
            f"----------------------------\n"
            f"**Symbol:** {symbol}\n"
            f"**Qty:** {quantity} @ ₹{price}\n"
            f"**Reason:** {reason}\n\n"
            f"📊 **Account Dashboard**\n"
            f"----------------------------\n"
            f"💰 **Cash Avail:** ₹{stats['cash']:,.2f}\n"
            f"✅ **Realized PnL:** ₹{stats['realized']:,.2f}\n"
            f"📈 **Unrealized PnL:** ₹{stats['unrealized']:,.2f}\n"
            f"{pnl_emoji} **Total Day PnL:** ₹{stats['total']:,.2f}"
        )

        # Send API Request
        url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": config.TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "Markdown"
        }
        response = requests.post(url, json=payload)
        
        # 3. Check for HTTP Errors (4xx or 5xx)
        if response.status_code != 200:
            print(f"Telegram API Error: {response.status_code} - {response.text}")
            logging.error(f"Telegram API Error: {response.text}")
        # else:
        #     print("Notification sent successfully!")

    except Exception as e:
        logging.error(f"Failed to send Telegram notification: {e}")
        print(f"Exception: {e}")


import logging
import requests
import config

def send_notification(messageContent):
    # 1. Master Switch Check
    if not config.ENABLE_TELEGRAM:
        print("Telegram disabled in config.") # Debug print
        return

    try:
        # Send API Request
        url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": config.TELEGRAM_CHAT_ID,
            "text": messageContent,
            "parse_mode": "Markdown" 
        }
        
        # 2. Capture the response
        response = requests.post(url, json=payload)
        
        # 3. Check for HTTP Errors (4xx or 5xx)
        if response.status_code != 200:
            print(f"Telegram API Error: {response.status_code} - {response.text}")
            logging.error(f"Telegram API Error: {response.text}")
        # else:
        #     print("Notification sent successfully!")

    except Exception as e:
        logging.error(f"Failed to send Telegram notification: {e}")
        print(f"Exception: {e}")
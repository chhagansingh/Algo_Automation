# config.py
import os
from datetime import time

# --- CREDENTIALS ---
#KITE_API_KEY = os.getenv("KITE_API_KEY", "your_api_key")
#ACCESS_TOKEN = os.getenv("KITE_ACCESS_TOKEN", "your_access_token")
KITE_API_KEY = os.getenv("KITE_API_KEY", "xxxxxxxx")
KITE_API_SECRET = os.getenv("KITE_API_SECRET", "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy")
ACCESS_TOKEN = os.getenv("KITE_ACCESS_TOKEN", None)

# --- SYSTEM MODES ---
PAPER_MODE = True       # Set to False for REAL TRADING
NO_LEVERAGE = True      # Force 1x Margin (Cash only)
ALLOW_SHORTS = True    # Allow Intraday Short Selling

# --- RISK MANAGEMENT ---
INITIAL_CAPITAL = 100000.0
MAX_RISK_PER_TRADE = 0.01   # 1% risk per trade
MAX_CAPITAL_PER_TRADE_PCT = 0.20  # Max 20% capital per trade
MAX_DAILY_LOSS = -0.03      # Stop trading if down 3%
MAX_OPEN_POSITIONS = 5

# --- TIME SETTINGS (IST) ---
MARKET_OPEN = time(9, 15)
MARKET_CLOSE = time(15, 15) # Stop taking new trades
SYSTEM_CLOSE = time(15, 12) # Hard exit all

# MARKET_OPEN = time(9, 15)
# MARKET_CLOSE = time(8, 15) # Stop taking new trades
# SYSTEM_CLOSE = time(8, 30) # Hard exit all

# --- FILES ---
LOG_DIR = "logs"
INSTRUMENTS_FILE = "instruments_map.csv"
STATE_FILE = "account_state.json"

# --- STRATEGY PARAMETERS ---
TIMEFRAMES = [5, 15] # Monitor 5m and 15m
EMA_FAST = 9
EMA_SLOW = 21
RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
ATR_PERIOD = 14

# --- TELEGRAM NOTIFICATIONS ---
ENABLE_TELEGRAM = True  # Set to False to silence all alerts
TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # Paste your Token inside quotes
TELEGRAM_CHAT_ID = "YOUR_CHAT_ID_HERE"      # Paste your Chat ID inside quotes
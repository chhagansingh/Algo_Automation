# # # # dashboard.py
# # # import time
# # # import os
# # # import json
# # # from datetime import datetime
# # # from config import STATE_FILE, INITIAL_CAPITAL
# # # from tabulate import tabulate

# # # def clear_screen():
# # #     os.system('cls' if os.name == 'nt' else 'clear')

# # # def load_state():
# # #     if not os.path.exists(STATE_FILE): return None
# # #     try:
# # #         with open(STATE_FILE, 'r') as f:
# # #             return json.load(f)
# # #     except:
# # #         return None

# # # def main():
# # #     while True:
# # #         state = load_state()
# # #         if not state:
# # #             print("Waiting for system to start...")
# # #             time.sleep(2)
# # #             continue

# # #         clear_screen()
        
# # #         # 1. HEADER STATS
# # #         total_pnl = state.get('total_pnl', 0.0)
# # #         cash = state.get('available_cash', 0.0)
# # #         # Calculate current Portfolio Value (Cash + Unrealized PnL could be added here if live data available)
# # #         # For now, we show realized metrics
        
# # #         print("="*60)
# # #         print(f" LIVE TRADING DASHBOARD ({datetime.now().strftime('%H:%M:%S')})")
# # #         print("="*60)
        
# # #         # Color coding PnL
# # #         pnl_str = f"{total_pnl:.2f}"
# # #         if total_pnl > 0: pnl_str = f"+{pnl_str}"
        
# # #         print(f" CAPITAL:   {cash:.2f}")
# # #         print(f" DAILY PnL: {pnl_str}")
# # #         print("-" * 60)

# # #         # 2. ACTIVE POSITIONS
# # #         positions = state.get('positions', {})
# # #         if positions:
# # #             print(f"\n ACTIVE POSITIONS ({len(positions)})")
# # #             table_data = []
# # #             for sym, pos in positions.items():
# # #                 # entry_time, symbol, direction, qty, entry_price, strategy
# # #                 table_data.append([
# # #                     pos.get('entry_time', '')[11:19], # Slice time only
# # #                     sym,
# # #                     pos['direction'],
# # #                     pos['qty'],
# # #                     pos['entry_price'],
# # #                     pos['stop_price'],
# # #                     pos['target_price'],
# # #                     pos['strategy']
# # #                 ])
            
# # #             print(tabulate(table_data, headers=["Time", "Symbol", "Side", "Qty", "Entry", "Stop", "Target", "Strategy"], tablefmt="simple"))
# # #         else:
# # #             print("\n [NO OPEN POSITIONS]")

# # #         # 3. RECENT COMPLETED TRADES
# # #         history = state.get('trade_history', [])
# # #         if history:
# # #             print(f"\n RECENT TRADES (Last 5)")
# # #             # Show last 5 trades, reversed
# # #             recent = history[-5:][::-1]
# # #             hist_data = []
# # #             for t in recent:
# # #                 res = "WIN" if t['realized_pnl'] > 0 else "LOSS"
# # #                 hist_data.append([
# # #                     t['exit_time'][11:19],
# # #                     t['symbol'],
# # #                     t['direction'],
# # #                     f"{t['realized_pnl']:.2f}",
# # #                     res
# # #                 ])
# # #             print(tabulate(hist_data, headers=["Exit Time", "Symbol", "Side", "PnL", "Result"], tablefmt="simple"))

# # #         print("\n" + "="*60)
# # #         print(" Press Ctrl+C to stop dashboard")
# # #         time.sleep(2) # Refresh every 2 seconds

# # # if __name__ == "__main__":
# # #     main()


# # # dashboard.py
# # import time
# # import os
# # import json
# # from datetime import datetime
# # from config import STATE_FILE
# # from tabulate import tabulate

# # def clear_screen():
# #     os.system('cls' if os.name == 'nt' else 'clear')

# # def load_state():
# #     if not os.path.exists(STATE_FILE): return None
# #     try:
# #         with open(STATE_FILE, 'r') as f:
# #             return json.load(f)
# #     except: return None

# # def main():
# #     while True:
# #         state = load_state()
# #         if not state:
# #             print("Waiting for backtest/system to start...")
# #             time.sleep(1)
# #             continue

# #         clear_screen()
        
# #         total_pnl = state.get('total_pnl', 0.0)
# #         cash = state.get('available_cash', 0.0)
        
# #         print("="*60)
# #         print(f" TRADING DASHBOARD ({datetime.now().strftime('%H:%M:%S')})")
# #         print("="*60)
        
# #         pnl_str = f"+{total_pnl:.2f}" if total_pnl > 0 else f"{total_pnl:.2f}"
# #         print(f" CAPITAL:   {cash:.2f}")
# #         print(f" TOTAL PnL: {pnl_str}")
# #         print("-" * 60)

# #         positions = state.get('positions', {})
# #         if positions:
# #             print(f"\n ACTIVE POSITIONS ({len(positions)})")
# #             table_data = []
# #             for sym, pos in positions.items():
# #                 table_data.append([
# #                     pos.get('entry_time', '')[11:19], sym, pos['direction'], 
# #                     pos['qty'], pos['entry_price'], pos['stop_price'], pos['target_price']
# #                 ])
# #             print(tabulate(table_data, headers=["Time", "Symbol", "Side", "Qty", "Entry", "Stop", "Target"], tablefmt="simple"))
# #         else:
# #             print("\n [NO OPEN POSITIONS]")

# #         history = state.get('trade_history', [])
# #         if history:
# #             print(f"\n RECENT TRADES (Last 5)")
# #             recent = history[-5:][::-1]
# #             hist_data = []
# #             for t in recent:
# #                 res = "WIN" if t['realized_pnl'] > 0 else "LOSS"
# #                 hist_data.append([t['symbol'], t['direction'], f"{t['realized_pnl']:.2f}", res])
# #             print(tabulate(hist_data, headers=["Symbol", "Side", "PnL", "Result"], tablefmt="simple"))

# #         time.sleep(0.5) # Fast refresh for backtest viewing

# # if __name__ == "__main__":
# #     main()


# # dashboard.py
# import time
# import os
# import json
# from datetime import datetime
# from config import STATE_FILE
# from tabulate import tabulate

# def clear_screen():
#     os.system('cls' if os.name == 'nt' else 'clear')

# def load_state():
#     if not os.path.exists(STATE_FILE): return None
#     try:
#         with open(STATE_FILE, 'r') as f:
#             return json.load(f)
#     except: return None

# def main():
#     while True:
#         state = load_state()
#         if not state:
#             print("Waiting for system to start...")
#             time.sleep(2)
#             continue

#         clear_screen()
        
#         # 1. HEADER
#         total_pnl = state.get('total_pnl', 0.0)
#         cash = state.get('available_cash', 0.0)
        
#         print("="*60)
#         print(f" LIVE TRADING DASHBOARD ({datetime.now().strftime('%H:%M:%S')})")
#         print("="*60)
        
#         pnl_str = f"+{total_pnl:.2f}" if total_pnl > 0 else f"{total_pnl:.2f}"
#         print(f" CAPITAL:   {cash:.2f}")
#         print(f" TOTAL PnL: {pnl_str}")
#         print("-" * 60)

#         # 2. ACTIVE POSITIONS
#         positions = state.get('positions', {})
#         if positions:
#             print(f"\n ACTIVE POSITIONS ({len(positions)})")
#             table_data = []
#             for sym, pos in positions.items():
#                 # FIX: Use .get() and correct key names (stop_loss, target)
#                 entry_time = pos.get('entry_time', '')[11:19] # Slice HH:MM:SS
#                 stop = pos.get('stop_loss', 0.0)  # Changed from stop_price
#                 target = pos.get('target', 0.0)   # Changed from target_price
                
#                 table_data.append([
#                     entry_time, 
#                     sym, 
#                     pos.get('direction', 'N/A'), 
#                     pos.get('qty', 0), 
#                     pos.get('entry_price', 0.0), 
#                     f"{stop:.2f}", 
#                     f"{target:.2f}"
#                 ])
#             print(tabulate(table_data, headers=["Time", "Symbol", "Side", "Qty", "Entry", "Stop", "Target"], tablefmt="simple"))
#         else:
#             print("\n [NO OPEN POSITIONS]")

#         # 3. RECENT TRADES
#         # (Check if your account_manager saves history as 'trade_history' or just appends to CSV)
#         # If using the new account_manager.py, it mainly logs to CSV, but let's see if we can read state
#         # The new account_manager doesn't keep a long 'trade_history' list in JSON to save space.
#         # It relies on the CSV. So this section might be empty, which is fine.
        
#         print("\n" + "="*60)
#         print(" Press Ctrl+C to stop dashboard")
        
#         time.sleep(2) # Refresh every 2 seconds

# if __name__ == "__main__":
#     main()


# dashboard.py
import time
import os
import json
from datetime import datetime
from config import STATE_FILE, KITE_API_KEY
from kiteconnect import KiteConnect
from tabulate import tabulate

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def load_state():
    if not os.path.exists(STATE_FILE): return None
    try:
        with open(STATE_FILE, 'r') as f:
            return json.load(f)
    except: return None

def get_kite_client():
    """Initializes a local Kite client for the dashboard to fetch prices."""
    try:
        if os.path.exists("access_token.txt"):
            access_token = open("access_token.txt", "r").read().strip()
            kite = KiteConnect(api_key=KITE_API_KEY)
            kite.set_access_token(access_token)
            return kite
    except Exception as e:
        # print(f"Dashboard Data Warning: {e}") 
        pass
    return None

def main():
    # Initialize Kite once for price fetching
    kite = get_kite_client()
    
    while True:
        state = load_state()
        if not state:
            print("Waiting for system to start...")
            time.sleep(2)
            continue

        clear_screen()
        
        # 1. HEADER STATS
        total_realized_pnl = state.get('total_pnl', 0.0)
        cash = state.get('available_cash', 0.0)
        positions = state.get('positions', {})
        
        # --- FETCH LIVE PRICES (CMP) ---
        live_data = {}
        total_open_pnl = 0.0
        
        if kite and positions:
            try:
                # Prepare list for API (e.g., ["NSE:INFY", "NSE:TCS"])
                # We assume NSE for Nifty 100 stocks
                symbols_to_fetch = [f"NSE:{sym}" for sym in positions.keys()]
                
                if symbols_to_fetch:
                    quotes = kite.ltp(symbols_to_fetch)
                    # Map back: {'NSE:INFY': ...} -> {'INFY': 1500.5}
                    for k, v in quotes.items():
                        clean_sym = k.replace("NSE:", "")
                        live_data[clean_sym] = v['last_price']
            except Exception:
                # If API fails (e.g. network), we just show N/A for CMP
                pass

        # Calculate Open PnL from Live Data
        for sym, pos in positions.items():
            if sym in live_data:
                cmp = live_data[sym]
                qty = pos.get('qty', 0)
                entry = pos.get('entry_price', 0)
                
                if pos['direction'] == 'LONG':
                    pnl = (cmp - entry) * qty
                else: # SHORT
                    pnl = (entry - cmp) * qty
                
                total_open_pnl += pnl

        # HEADER DISPLAY
        print("="*65)
        print(f" LIVE TRADING DASHBOARD ({datetime.now().strftime('%H:%M:%S')})")
        print("="*65)
        
        print(f" CAPITAL:      {cash:,.2f}")
        print(f" REALIZED PnL: {total_realized_pnl:,.2f}")
        print(f" OPEN PnL:     {total_open_pnl:,.2f}") 
        
        # Combined PnL (Realized + Open)
        net_pnl = total_realized_pnl + total_open_pnl
        print(f" NET SESSION:  {net_pnl:,.2f}")
        print("-" * 65)

        # 2. ACTIVE POSITIONS TABLE
        if positions:
            print(f"\n ACTIVE POSITIONS ({len(positions)})")
            table_data = []
            for sym, pos in positions.items():
                entry_time = pos.get('entry_time', '')[11:19]
                direction = pos.get('direction', 'N/A')
                qty = pos.get('qty', 0)
                entry = pos.get('entry_price', 0.0)
                stop = pos.get('stop_loss', 0.0)
                target = pos.get('target', 0.0)
                
                # Live Data
                cmp = live_data.get(sym, 0.0)
                
                # Calculate Row PnL
                row_pnl = "N/A"
                if cmp > 0:
                    if direction == 'LONG':
                        val = (cmp - entry) * qty
                    else:
                        val = (entry - cmp) * qty
                    row_pnl = f"{val:.2f}"

                table_data.append([
                    entry_time, 
                    sym, 
                    direction, 
                    qty, 
                    f"{entry:.2f}", 
                    f"{cmp:.2f}" if cmp > 0 else "N/A", # CMP Column
                    row_pnl, # PnL Column
                    f"{stop:.2f}", 
                    f"{target:.2f}"
                ])
            
            print(tabulate(table_data, 
                           headers=["Time", "Symbol", "Side", "Qty", "Entry", "CMP", "PnL", "Stop", "Target"], 
                           tablefmt="simple"))
        else:
            print("\n [NO OPEN POSITIONS]")

        # 3. RECENT TRADES
        history = state.get('trade_history', [])
        if history:
            print(f"\n RECENT COMPLETED TRADES (Last 5)")
            recent = history[-5:][::-1]
            hist_data = []
            for t in recent:
                res = "WIN" if t['realized_pnl'] > 0 else "LOSS"
                hist_data.append([
                    t['symbol'], 
                    t['direction'], 
                    f"{t['realized_pnl']:.2f}", 
                    res,
                    t.get('exit_time', '')[11:19]
                ])
            print(tabulate(hist_data, headers=["Symbol", "Side", "PnL", "Result", "Exit Time"], tablefmt="simple"))

        print("\n" + "="*65)
        print(" Press Ctrl+C to stop dashboard")
        
        # Refresh Rate
        time.sleep(2) 

if __name__ == "__main__":
    main()
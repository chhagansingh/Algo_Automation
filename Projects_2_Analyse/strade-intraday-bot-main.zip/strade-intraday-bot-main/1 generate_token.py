#!/usr/bin/env python3
"""
Robust token generator for Kite Connect.
Prints diagnostics if generate_session is missing (so you can spot version/shadowing issues).
"""

import sys
import traceback
from kiteconnect import KiteConnect
import config  # your config.py with KITE_API_KEY / KITE_API_SECRET

def diagnose():
    import kiteconnect, inspect, pkgutil
    print("kiteconnect module file:", getattr(kiteconnect, "__file__", "<not found>"))
    print("kiteconnect loader:", pkgutil.find_loader("kiteconnect"))
    print("KiteConnect object:", KiteConnect)
    print("KiteConnect dir snapshot (first 40):", [n for n in dir(KiteConnect)][:40])

def get_access_token_interactive(kite):
    # prefer generate_session (current docs), fallback to request_access_token (older)
    if hasattr(kite, "generate_session"):
        method_name = "generate_session"
    elif hasattr(kite, "request_access_token"):
        method_name = "request_access_token"
    else:
        method_name = None

    if not method_name:
        print("ERROR: KiteConnect instance lacks generate_session/request_access_token.")
        print("Available methods:", [m for m in dir(kite) if not m.startswith('_')][:100])
        raise RuntimeError("KiteConnect missing session-generation method.")

    while True:
        try:
            print("Open this URL in your browser and login:")
            print(kite.login_url())
            request_token = input("Enter request token (from redirect URL) -> ").strip()
            if not request_token:
                print("No request token entered; aborting.")
                sys.exit(1)
            if method_name == "generate_session":
                data = kite.generate_session(request_token, api_secret=config.KITE_API_SECRET)
            else:
                # older alternative
                data = kite.request_access_token(request_token, secret=config.KITE_API_SECRET)
            access_token = data.get("access_token") or data.get("accessToken") or data.get("data", {}).get("access_token")
            if not access_token:
                print("Couldn't find access token in response; raw response:", data)
                raise RuntimeError("No access token in response")
            return access_token
        except Exception as e:
            print("Error while exchanging request_token:", e)
            traceback.print_exc()
            print("Try again or Ctrl+C to quit.")

def save_token(tok, path="access_token.txt"):
    with open(path, "w") as f:
        f.write(tok)
    print("Saved access token to", path)

def main():
    print("Diagnostic info...")
    try:
        diagnose()
    except Exception as e:
        print("Failed to run diagnostics:", e)
    try:
        kite = KiteConnect(api_key=config.KITE_API_KEY)
    except Exception as e:
        print("Failed to instantiate KiteConnect:", e)
        raise
    token = get_access_token_interactive(kite)
    save_token(token)

if __name__ == "__main__":
    main()

# stream_manager.py
import logging
from kiteconnect import KiteTicker
from config import KITE_API_KEY, ACCESS_TOKEN

# Shared dictionary to store Live Prices (LTP)
# Format: { token_id: price, ... }
LTP_DICT = {}

class StreamManager:
    def __init__(self):
        self.kws = KiteTicker(KITE_API_KEY, ACCESS_TOKEN)
        self.tokens_to_track = []
        self.log = logging.getLogger("main")

        # Assign Callbacks
        self.kws.on_ticks = self.on_ticks
        self.kws.on_connect = self.on_connect
        self.kws.on_error = self.on_error

    def start(self, tokens):
        """Starts the WebSocket in a non-blocking background thread"""
        self.tokens_to_track = list(tokens)
        
        # Enable threaded mode so main.py can keep running
        self.kws.connect(threaded=True)

    def on_connect(self, ws, response):
        self.log.info(f"WebSocket Connected! Subscribing to {len(self.tokens_to_track)} tokens.")
        ws.subscribe(self.tokens_to_track)
        # Set mode to LTP (Least bandwidth, fastest)
        ws.set_mode(ws.MODE_LTP, self.tokens_to_track)

    def on_ticks(self, ws, ticks):
        """Updates the global LTP_DICT whenever price changes"""
        for tick in ticks:
            token = tick['instrument_token']
            price = tick['last_price']
            LTP_DICT[token] = price
            # We don't log here to avoid spamming the console

    def on_error(self, ws, code, reason):
        self.log.error(f"WebSocket Error: {code} - {reason}")

    def get_ltp(self, token):
        """Safe method to get price from dictionary"""
        return LTP_DICT.get(token, 0.0)

    def stop(self):
        self.kws.close()

const DASHBOARD_CONFIG = window.DASHBOARD_CONFIG || {};
const REFRESH_MS = Number(DASHBOARD_CONFIG.refreshMs || 2000);
const IMAGE_ASSETS = DASHBOARD_CONFIG.images || {};
const CHART_BADGE_IMAGES = IMAGE_ASSETS;
// Hardcoded ET because the bot only trades US equities/options sessions
// and all server-side bar timestamps are emitted as ET-localized
// `pd.Timestamp.isoformat()`. Without forcing this, browsers in other
// timezones would render bar labels in their local TZ, mislabeling the
// market clock. If the bot ever supports non-US markets, plumb
// `runtime.timezone` through `DASHBOARD_CONFIG` and read it here.
const DASHBOARD_TIMEZONE = 'America/New_York';
// Cached Intl.DateTimeFormat instances. Per-call `toLocaleString({timeZone:...})`
// is significantly slower than reusing a pre-built formatter — each invocation
// re-parses options and constructs the underlying ICU resolver. Charts call
// these per axis tick (10-20× per render), so the cache shaves real time off
// every chart paint. Day-key formatter uses en-CA's YYYY-MM-DD output so
// string compare cleanly identifies trading-day rollovers in ET.
const CHART_TS_FMT = new Intl.DateTimeFormat([], {
  month: 'short',
  day: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  timeZone: DASHBOARD_TIMEZONE,
});
const TIME_AXIS_FMT = new Intl.DateTimeFormat([], {
  hour: 'numeric',
  minute: '2-digit',
  timeZone: DASHBOARD_TIMEZONE,
});
const DAY_AXIS_FMT = new Intl.DateTimeFormat('en-US', {
  month: '2-digit',
  day: '2-digit',
  timeZone: DASHBOARD_TIMEZONE,
});
const DAY_KEY_FMT = new Intl.DateTimeFormat('en-CA', {
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  timeZone: DASHBOARD_TIMEZONE,
});
const EXPANDED_CHART_CACHE_MAX = 6;
const EXPANDED_CHART_CACHE_TTL_MS = 20 * 60 * 1000;
const COMPACT_CHART_CACHE_MAX = 8;
const COMPACT_CHART_CACHE_TTL_MS = 20 * 60 * 1000;
const appState = {
  data: null,
  snapshotMap: new Map(),
  selectedSymbol: null,
  filter: 'all',
  dockTab: 'events',
  refreshInFlight: false,
  mainPanelExpanded: false,
  expandedChart: {
    symbol: null,
    bars: null,
    maxBars: 360,
    timeframeMode: 'ltf',
    sourceKey: null,
    requestSeq: 0,
    lastBarTs: null,
    timeframeLabel: null,
    emaFastSpan: null,
    emaSlowSpan: null,
    htfRefreshToken: null,
    pinnedBarId: null,
    refreshRafId: 0,
    pendingForceRefresh: false,
    stateLastUpdate: null,
    isLoading: false,
    cache: new Map(),
  },
  compactChart: {
    symbol: null,
    bars: null,
    maxBars: 90,
    timeframeMode: 'ltf',
    sourceKey: null,
    requestSeq: 0,
    lastBarTs: null,
    timeframeLabel: null,
    emaFastSpan: null,
    emaSlowSpan: null,
    htfRefreshToken: null,
    patterns: {},
    structureOverlay: {},
    stateLastUpdate: null,
    isLoading: false,
    cache: new Map(),
  },
};

function safe(value) {
  return value === null || value === undefined || value === '' ? '—' : String(value);
}

function fmtChartTs(value) {
  if (!value) return '—';
  const dt = new Date(value);
  if (Number.isFinite(dt.getTime())) {
    return CHART_TS_FMT.format(dt);
  }
  return safe(value).replace('T', ' ').slice(0, 16);
}

function positiveOrNull(value) {
  const n = numOrNull(value);
  return n !== null && n > 0 ? n : null;
}

function positionRangeSpec(pos) {
  const entry = numOrNull(pos?.entry_price);
  // Use the trade's INITIAL stop/target for span calculations so the bar
  // layout stays stable through management ratchets (adaptive_breakeven_rr
  // collapsing stop to entry, final-rung clearing target to None).
  // Falls back to the live stop/target for legacy positions that didn't
  // get ``initial_*_price`` stamped on metadata at entry.
  const stop = numOrNull(pos?.initial_stop_price) ?? numOrNull(pos?.stop_price);
  const target = numOrNull(pos?.initial_target_price) ?? numOrNull(pos?.target_price);
  const last = numOrNull(pos?.last_price);
  const side = String(pos?.side || '').toUpperCase();
  if (entry === null || stop === null || target === null || last === null) return null;
  const adverseSpan = Math.abs(entry - stop);
  const favorableSpan = Math.abs(target - entry);
  if (!(adverseSpan > 0) || !(favorableSpan > 0)) return null;
  const favorableMove = side === 'SHORT' ? (entry - last) : (last - entry);
  const towardTarget = favorableMove >= 0;
  const span = towardTarget ? favorableSpan : adverseSpan;
  if (!(span > 0)) return null;
  const progress = clamp(Math.abs(favorableMove) / span, 0, 1);
  const widthPct = progress * 50;
  const markerPct = towardTarget ? 50 + widthPct : 50 - widthPct;
  const destination = towardTarget ? 'target' : 'stop';
  const statusTone = towardTarget ? 'good' : 'bad';
  const progressPct = progress * 100;
  const remainingPct = (1 - progress) * 100;
  return {
    leftPct: towardTarget ? 50 : 50 - widthPct,
    widthPct,
    markerPct: clamp(markerPct, 0, 100),
    tone: towardTarget ? 'good' : 'bad',
    progressPct,
    destination,
    statusTone,
    progressLabel: `${fmtPct(progressPct / 100, 1)} to ${destination}`,
    remainingLabel: `${fmtPct(remainingPct / 100, 1)} remaining`,
  };
}

function positionRangeMarkup(pos) {
  const spec = positionRangeSpec(pos);
  if (!spec) {
    // pos.return_pct comes in as an already-multiplied percentage from
    // paper_account._return_pct (e.g. 25 for +25%), so use ×4 so that a
    // 25% return fills the bar. (Was ×400 under the old ratio assumption,
    // which kept the bar permanently clamped to 100.)
    const pnlBar = numOrNull(pos?.return_pct) === null ? 0 : clamp(Math.abs(Number(pos.return_pct)) * 4, 0, 100);
    const fillTone = Number(pos?.return_pct) < 0 ? 'bad' : '';
    return `<div style="margin-top:12px;" class="bar-track"><div class="bar-fill ${fillTone}" style="width:${pnlBar}%;"></div></div>`;
  }
  const fillTone = spec.tone === 'bad' ? 'bad' : '';
  return `<div class="trade-range">
    <div class="trade-range-track">
      <div class="trade-range-fill ${fillTone}" style="left:${spec.leftPct}%; width:${spec.widthPct}%;"></div>
      <div class="trade-range-center"></div>
    </div>
    <div class="trade-range-status">
      <div class="tiny-label">Progress</div>
      <div class="emph ${fillTone}">${escapeHtml(spec.progressLabel)}</div>
      <div class="tiny-label">${escapeHtml(spec.remainingLabel)}</div>
    </div>
    <div class="trade-range-labels">
      <div class="trade-range-label left"><div class="tiny-label">Stop</div><div class="v">${fmtNum(pos?.initial_stop_price ?? pos?.stop_price, 2)}</div></div>
      <div class="trade-range-label right"><div class="tiny-label">Target</div><div class="v">${fmtNum(pos?.initial_target_price ?? pos?.target_price, 2)}</div></div>
    </div>
  </div>`;
}

function pnlTone(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n === 0) return 'tone-neutral';
  return n > 0 ? 'tone-good' : 'tone-bad';
}

function selectedSymbolTone(snapshot) {
  if (!snapshot) return 'tone-neutral';
  // Explicit bias (candidate directional_bias or open-position side) always
  // wins. The trend-state fallback only fires when no bias / position is set
  // — previously the OR-with-trend check could flip a SHORT-tagged card to
  // tone-long if the HTF trend happened to be bullish, contradicting the
  // visible "SHORT" subtitle. Bias is the strategy's directional intent for
  // the symbol; trend is just structural context.
  const bias = String(snapshot?.candidate?.directional_bias || snapshot?.position?.side || '').toUpperCase();
  if (bias === 'LONG') return 'tone-long';
  if (bias === 'SHORT') return 'tone-short';
  const trend = String(snapshot?.support_resistance?.trend_state || snapshot?.support_resistance?.structure_bias || '').toLowerCase();
  if (trend === 'bullish') return 'tone-long';
  if (trend === 'bearish') return 'tone-short';
  return 'tone-neutral';
}

function eventTone(name) {
  const token = String(name || '').toUpperCase();
  if (token.includes('BOS↑') || token.includes('CHOCH↑') || token.includes('EQL') || token.includes('BREAKOUT') || token.includes('NEAR_SUPPORT')) return 'event-bullish';
  if (token.includes('BOS↓') || token.includes('CHOCH↓') || token.includes('EQH') || token.includes('BREAKDOWN') || token.includes('NEAR_RESISTANCE')) return 'event-bearish';
  if (token.includes('ERROR') || token.includes('BLOCKED') || token.includes('DISCONNECTED')) return 'event-bearish';
  if (token.includes('WARNING') || token.includes('PAUSED')) return 'tone-warn';
  return 'event-neutral';
}

function tinyChip(text, tone = 'tone-neutral') {
  return `<span class="tiny-chip ${tone}">${escapeHtml(text)}</span>`;
}

function iconForState(state, fallbackLabel, contextLabel = 'State') {
  const token = String(state || fallbackLabel || '').toLowerCase();
  const src = token.includes('bull') ? CHART_BADGE_IMAGES.bullish : (token.includes('bear') ? CHART_BADGE_IMAGES.bearish : CHART_BADGE_IMAGES.neutral);
  const label = token.includes('bull') ? 'Bullish' : (token.includes('bear') ? 'Bearish' : 'Neutral');
  const fullLabel = `${label} ${contextLabel}`.trim();
  return `<div class="icon-badge" title="${fullLabel}"><img src="${src}" alt="${fullLabel}" title="${fullLabel}" /></div>`;
}

function structureEventChip(value) {
  const text = safe(value);
  return `<span class="event-chip ${eventTone(text)}">${escapeHtml(text)}</span>`;
}

function stateChip(value) {
  const token = String(value || 'neutral');
  return `<span class="status-chip ${eventTone(token)}">${escapeHtml(token.replace(/_/g, ' '))}</span>`;
}

function humanizeDecisionToken(value) {
  const raw = String(value || '').trim();
  if (!raw) return '—';
  const [head, ...rest] = raw.split(':');
  const humanHead = head.replace(/_/g, ' ');
  return rest.length ? `${humanHead}: ${rest.join(':')}` : humanHead;
}

// Short-form labels for the most verbose entry-decision tokens. Used by
// humanizeDecisionTokenCompact below for the focus-meta line where the
// space budget is tight. Keys are the raw underscore tokens emitted by
// the strategies (zero_dte_etf_options + equity strategies); values are
// the abbreviated human labels. The full token still appears in the
// score-sub line below the focus card, so the abbreviations here only
// affect the always-visible top-left status text.
//
// Add new entries here when a new long token shows up — anything longer
// than ~16 chars after underscore→space conversion is a candidate.
const COMPACT_DECISION_REASON_LABELS = {
  insufficient_underlying_bars: 'low bars',
  insufficient_confirm_bars: 'low confirm bars',
  insufficient_htf_bars: 'low htf bars',
  insufficient_bars: 'low bars',
  insufficient_chain: 'thin chain',
  option_quote_unstable: 'quote unstable',
  quote_not_stable: 'quote unstable',
  option_chain_empty: 'no chain',
  option_chain_invalid: 'bad chain',
  no_contract_near_target_delta: 'no delta match',
  vix_above_limit: 'vix high',
  vix_below_floor: 'vix low',
  vix_spike: 'vix spike',
  iv_rank_too_low: 'iv low',
  iv_rank_too_high: 'iv high',
  dead_tape: 'dead tape',
  weak_relative_volume: 'low rvol',
  chaos_intraday_range: 'chop range',
  chart_pattern_bias_too_low: 'pattern weak',
  eql_eqh_compressed: 'eq compressed',
  min_score_gap_not_met: 'score gap low',
  regime_unclear: 'regime unclear',
  no_setup: 'no setup',
  already_in_position: 'in position',
  outside_entry_window: 'window closed',
  confirm_index_disagrees: 'idx disagrees',
  htf_misaligned: 'htf misaligned',
  style_unavailable: 'style off',
  force_flatten_active: 'flatten now',
  not_yet_implemented: 'todo',
};

// Compact form: drops the parameter detail after the first colon and
// consults COMPACT_DECISION_REASON_LABELS for the most verbose tokens.
// Used in tight UI spots (e.g. the focus-meta line next to the symbol name)
// where long ETF-options skip reasons like
// `option_quote_unstable:bid=1.05 ask=1.20 mid=1.13 stability_pct=14.2`
// would push the live-price/change/volume chips off the right edge.
// The full detail still appears in the score-sub line below.
function humanizeDecisionTokenCompact(value) {
  const raw = String(value || '').trim();
  if (!raw) return '—';
  const head = raw.split(':')[0];
  const abbrev = COMPACT_DECISION_REASON_LABELS[head];
  if (abbrev) return abbrev;
  return head.replace(/_/g, ' ');
}

function entryDecisionForSnapshot(snapshot) {
  if (!snapshot) return null;
  const direct = snapshot.entry_decision;
  return direct && typeof direct === 'object' ? direct : null;
}

function entryDecisionLabel(decision) {
  if (!decision || typeof decision !== 'object') return '';
  const action = String(decision.action || '').trim().toLowerCase();
  const primary = humanizeDecisionToken(decision.primary_reason || (Array.isArray(decision.reasons) ? decision.reasons[0] : ''));
  if (!action && !primary) return '';
  if (!primary || primary === '—') return action || '';
  if (!action || action === 'signal') return primary;
  return `${action}: ${primary}`;
}

// Compact variant for tight UI surfaces. Same shape as
// entryDecisionLabel() but uses the head-only humanizer + abbreviation
// map so long parameter strings (e.g. option-strategy quote-stability
// values) don't blow out the focus-meta line layout. Also drops the
// "skipped: " action prefix — the trade-not-taken state is implied by
// the muted styling and the absence of an active-position label
// elsewhere on the card. The full prefix still appears in
// entryDecisionLabel() used on roomier surfaces.
function entryDecisionLabelCompact(decision) {
  if (!decision || typeof decision !== 'object') return '';
  const action = String(decision.action || '').trim().toLowerCase();
  const primary = humanizeDecisionTokenCompact(decision.primary_reason || (Array.isArray(decision.reasons) ? decision.reasons[0] : ''));
  if (!action && !primary) return '';
  if (!primary || primary === '—') return action || '';
  return primary;
}

function normalizeTradingViewSymbol(symbol) {
  const raw = String(symbol || '').toUpperCase().trim();
  if (!raw) return '';
  if (raw.startsWith('Q-') && raw.length > 2) return raw.slice(2).trim();
  return raw;
}

function normalizeTradingViewExchange(exchange) {
  const raw = String(exchange || '').toUpperCase().trim();
  if (!raw) return '';
  if (raw === 'Q' || raw === 'Q-' || raw.startsWith('Q-')) return '';
  return raw;
}

function tradingViewSymbolMeta(symbol, exchangeMap, rowExchange) {
  const rawSymbol = String(symbol || '').toUpperCase().trim();
  const normalizedSymbol = normalizeTradingViewSymbol(rawSymbol);
  const mappedExchange = exchangeMap && (exchangeMap[rawSymbol] || exchangeMap[normalizedSymbol]);
  const exchange = normalizeTradingViewExchange(rowExchange) || normalizeTradingViewExchange(mappedExchange) || '';
  return { rawSymbol, normalizedSymbol, exchange };
}

function symbolLink(symbol, exchangeMap, displaySymbol, rowExchange) {
  const { rawSymbol, normalizedSymbol, exchange } = tradingViewSymbolMeta(symbol, exchangeMap, rowExchange);
  if (!rawSymbol) return '—';
  const rawLabel = String(displaySymbol || normalizedSymbol || rawSymbol).toUpperCase().trim();
  const label = normalizeTradingViewSymbol(rawLabel) || normalizedSymbol || rawSymbol;
  if (!exchange || !normalizedSymbol) return escapeHtml(label);
  const href = `https://www.tradingview.com/symbols/${encodeURIComponent(exchange)}-${encodeURIComponent(normalizedSymbol)}/`;
  return `<a class="tv-link" href="${href}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>`;
}

function tradeSymbolCell(trade, exchangeMap) {
  const assetType = String(trade?.asset_type || '').toUpperCase().trim();
  const tradeSymbol = String(trade?.symbol || '').toUpperCase().trim();
  const underlying = String(trade?.underlying || '').toUpperCase().trim();
  if (assetType.startsWith('OPTION')) {
    if (underlying) {
      const underlyingLink = symbolLink(underlying, exchangeMap, underlying);
      return `${underlyingLink}<div class="table-sub">${escapeHtml(tradeSymbol || assetType)}</div>`;
    }
    return escapeHtml(tradeSymbol || '—');
  }
  return symbolLink(tradeSymbol, exchangeMap, tradeSymbol, trade?.exchange);
}

function warmupTone(warmup) {
  if (!warmup || typeof warmup !== 'object') return 'tone-neutral';
  const current = numOrNull(warmup.current_bars) ?? 0;
  if (warmup.ready) return 'tone-good';
  if (current <= 0) return 'tone-bad';
  return 'tone-warn';
}

function warmupLabel(warmup) {
  if (!warmup || typeof warmup !== 'object') return '';
  const current = numOrNull(warmup.current_bars) ?? 0;
  if (warmup.ready) return 'Ready';
  if (current <= 0) return 'Not Ready';
  return 'Loading';
}

function warmupChip(warmup) {
  const label = warmupLabel(warmup);
  if (!label) return '';
  return tinyChip(label, warmupTone(warmup));
}


function buildSnapshotMap(data) {
  const out = new Map();
  (data?.dashboard_symbols || []).forEach(item => {
    if (item && item.symbol) out.set(String(item.symbol).toUpperCase(), item);
  });
  return out;
}

function activeSnapshotMap(data = appState.data) {
  if (data === appState.data && appState.snapshotMap instanceof Map && appState.snapshotMap.size) return appState.snapshotMap;
  return buildSnapshotMap(data);
}

function rawDashboardCharting(data = appState.data) {
  const raw = data && data.dashboard_charting;
  return raw && typeof raw === 'object' ? raw : {};
}

function dashboardChartProfile(mode = 'compact', data = appState.data) {
  const raw = rawDashboardCharting(data);
  if (raw && (raw.compact || raw.expanded)) {
    const profile = raw[mode] || raw.compact || raw.expanded || {};
    return profile && typeof profile === 'object' ? profile : {};
  }
  return raw;
}

function currentChartProfile(data = appState.data) {
  return dashboardChartProfile(appState.mainPanelExpanded ? 'expanded' : 'compact', data);
}

function normalizedExpandedChartTimeframeMode(value) {
  return String(value || 'ltf').trim().toLowerCase() === 'htf' ? 'htf' : 'ltf';
}

function compactChartTimeframeMode(data = appState.data) {
  const raw = rawDashboardCharting(data);
  return String(raw?.compact_chart_timeframe || 'ltf').trim().toLowerCase() === 'htf' ? 'htf' : 'ltf';
}

function chartMaxBarsForMode(viewMode = 'compact', data = appState.data) {
  const profile = dashboardChartProfile(viewMode, data);
  const fallback = String(viewMode || '').toLowerCase() === 'expanded' ? 360 : 90;
  return Math.max(1, Math.min(Number(profile?.max_bars) || fallback, 480));
}

function expandedChartMaxBars(data = appState.data) {
  return chartMaxBarsForMode('expanded', data);
}

function compactChartMaxBars(data = appState.data) {
  return chartMaxBarsForMode('compact', data);
}

function expandedChartTimeframeMode() {
  return normalizedExpandedChartTimeframeMode(appState.expandedChart?.timeframeMode);
}

function selectedSnapshot(data = appState.data, symbol = appState.selectedSymbol) {
  const normalizedSymbol = String(symbol || '').toUpperCase();
  if (!normalizedSymbol) return null;
  return activeSnapshotMap(data).get(normalizedSymbol) || null;
}

function currentHtfTimeframeLabel(data = appState.data, symbol = appState.selectedSymbol) {
  const snapshot = selectedSnapshot(data, symbol);
  const snapshotLabel = String(snapshot?.support_resistance?.timeframe || '').trim();
  if (snapshotLabel) return snapshotLabel;
  const normalizedSymbol = String(symbol || '').toUpperCase();
  if (normalizedSymbol) {
    if (normalizedExpandedChartTimeframeMode(appState.expandedChart?.timeframeMode) === 'htf'
      && String(appState.expandedChart?.symbol || '').toUpperCase() === normalizedSymbol) {
      const expandedLabel = String(appState.expandedChart?.timeframeLabel || '').trim();
      if (expandedLabel) return expandedLabel;
    }
    if (normalizedExpandedChartTimeframeMode(appState.compactChart?.timeframeMode) === 'htf'
      && String(appState.compactChart?.symbol || '').toUpperCase() === normalizedSymbol) {
      const compactLabel = String(appState.compactChart?.timeframeLabel || '').trim();
      if (compactLabel) return compactLabel;
    }
  }
  return 'HTF';
}

function currentHtfRefreshToken(data = appState.data, symbol = appState.selectedSymbol) {
  const snapshot = selectedSnapshot(data, symbol);
  const snapshotToken = String(snapshot?.support_resistance?.htf_refresh_token || '').trim();
  if (snapshotToken) return snapshotToken;
  const normalizedSymbol = String(symbol || '').toUpperCase();
  if (normalizedSymbol) {
    if (normalizedExpandedChartTimeframeMode(appState.expandedChart?.timeframeMode) === 'htf'
      && String(appState.expandedChart?.symbol || '').toUpperCase() === normalizedSymbol) {
      const expandedToken = String(appState.expandedChart?.htfRefreshToken || '').trim();
      if (expandedToken) return expandedToken;
    }
    if (normalizedExpandedChartTimeframeMode(appState.compactChart?.timeframeMode) === 'htf'
      && String(appState.compactChart?.symbol || '').toUpperCase() === normalizedSymbol) {
      const compactToken = String(appState.compactChart?.htfRefreshToken || '').trim();
      if (compactToken) return compactToken;
    }
  }
  return '';
}

function currentLtfTimeframeLabel(data = appState.data, symbol = appState.selectedSymbol) {
  const snapshot = selectedSnapshot(data, symbol);
  const snapshotLabel = String(snapshot?.support_resistance?.ltf_timeframe || '').trim();
  if (snapshotLabel) return snapshotLabel;
  const normalizedSymbol = String(symbol || '').toUpperCase();
  if (normalizedSymbol) {
    if (normalizedExpandedChartTimeframeMode(appState.expandedChart?.timeframeMode) === 'ltf'
      && String(appState.expandedChart?.symbol || '').toUpperCase() === normalizedSymbol) {
      const expandedLabel = String(appState.expandedChart?.timeframeLabel || '').trim();
      if (expandedLabel) return expandedLabel;
    }
    if (normalizedExpandedChartTimeframeMode(appState.compactChart?.timeframeMode) === 'ltf'
      && String(appState.compactChart?.symbol || '').toUpperCase() === normalizedSymbol) {
      const compactLabel = String(appState.compactChart?.timeframeLabel || '').trim();
      if (compactLabel) return compactLabel;
    }
  }
  return '1m';
}

function expandedChartTimeframeLabel(data = appState.data, mode = expandedChartTimeframeMode()) {
  if (normalizedExpandedChartTimeframeMode(mode) === 'htf') {
    return currentHtfTimeframeLabel(data);
  }
  return currentLtfTimeframeLabel(data);
}

function chartLtfIsOneMinute(data = appState.data, symbol = appState.selectedSymbol) {
  // Single source of truth for "is the LTF chart's bar size literally 1m?".
  // Snapshot.bars are always 1m streaming bars (dashboard_cache.py:626 reads
  // get_merged with no timeframe arg). When the active strategy declares
  // params.ltf_minutes > 1 (e.g. peer_confirmed_key_levels uses 5m), the
  // /api/chart LTF payload returns 5m bars resampled by data_feed.get_merged.
  // Merging the 1m snapshot bars into the 5m cache would overwrite the 5m
  // candles by colliding abs_index keys, "rewinding" the chart to whatever
  // the 1m streaming window covers. So this gate must return true ONLY when
  // ltf_minutes == 1.
  const label = String(currentLtfTimeframeLabel(data, symbol) || '').trim().toLowerCase();
  return label === '1m';
}

function chartBarIdentity(bar, fallbackIndex = -1) {
  const absIndex = numOrNull(bar?.abs_index);
  if (absIndex !== null) return `a:${absIndex}`;
  const ts = String(bar?.ts || '').trim();
  if (ts) return `t:${ts}`;
  if (fallbackIndex >= 0) return `i:${fallbackIndex}`;
  return null;
}

function compareChartBars(left, right) {
  const leftAbs = numOrNull(left?.abs_index);
  const rightAbs = numOrNull(right?.abs_index);
  if (leftAbs !== null || rightAbs !== null) {
    return (leftAbs ?? Number.NEGATIVE_INFINITY) - (rightAbs ?? Number.NEGATIVE_INFINITY);
  }
  return String(left?.ts || '').localeCompare(String(right?.ts || ''));
}

function chartBarsSignature(bars) {
  if (!Array.isArray(bars) || !bars.length) return '0';
  const tail = bars.slice(-3).map((bar) => [
    chartBarIdentity(bar),
    safe(bar?.ts),
    safe(bar?.open),
    safe(bar?.high),
    safe(bar?.low),
    safe(bar?.close),
    safe(bar?.volume),
  ].join('|')).join('||');
  return `${bars.length}|${tail}`;
}
function writeExpandedChartCache(sourceKey, cacheEntry) {
  if (!sourceKey || !cacheEntry || !Array.isArray(cacheEntry.bars) || !cacheEntry.bars.length) return;
  const symbol = String(cacheEntry.symbol || '').toUpperCase();
  const maxBars = Math.max(1, Number(cacheEntry.maxBars) || 90);
  appState.expandedChart.cache.set(sourceKey, {
    ...cacheEntry,
    symbol,
    maxBars,
    updatedAt: Number(cacheEntry.updatedAt) || Date.now(),
  });
  pruneExpandedChartCache({ preserveSourceKey: sourceKey });
}

function pruneExpandedChartCache({ preserveSourceKey = null } = {}) {
  const cache = appState.expandedChart.cache;
  if (!(cache instanceof Map) || !cache.size) return;
  const now = Date.now();
  const preserved = new Set([preserveSourceKey, appState.expandedChart.sourceKey].filter(Boolean));
  const latestByPrefix = new Map();
  for (const [key, entry] of cache.entries()) {
    if (!entry || !Array.isArray(entry.bars) || !entry.bars.length) continue;
    const updatedAt = Number(entry.updatedAt) || now;
    if (!preserved.has(key) && (now - updatedAt) > EXPANDED_CHART_CACHE_TTL_MS) continue;
    const symbol = String(entry.symbol || '').toUpperCase();
    const maxBars = Math.max(1, Number(entry.maxBars) || Number(entry.bars?.length) || 90);
    const timeframeMode = normalizedExpandedChartTimeframeMode(entry.timeframeMode);
    const prefix = `${symbol}|${maxBars}|${timeframeMode}`;
    const current = latestByPrefix.get(prefix);
    const shouldReplace = !current || preserved.has(key) || (!preserved.has(current[0]) && updatedAt >= (Number(current[1]?.updatedAt) || 0));
    if (shouldReplace) latestByPrefix.set(prefix, [key, { ...entry, symbol, maxBars, updatedAt }]);
  }
  let entries = Array.from(latestByPrefix.values());
  entries.sort((left, right) => (Number(right[1]?.updatedAt) || 0) - (Number(left[1]?.updatedAt) || 0));
  if (entries.length > EXPANDED_CHART_CACHE_MAX) {
    const keepKeys = new Set(entries.slice(0, EXPANDED_CHART_CACHE_MAX).map(([key]) => key));
    preserved.forEach((key) => {
      if (!keepKeys.has(key) && cache.has(key)) {
        const entry = cache.get(key);
        if (entry && Array.isArray(entry.bars) && entry.bars.length) {
          keepKeys.add(key);
          entries.push([key, entry]);
        }
      }
    });
    entries = entries.filter(([key]) => keepKeys.has(key));
  }
  const nextCache = new Map();
  entries
    .sort((left, right) => (Number(left[1]?.updatedAt) || 0) - (Number(right[1]?.updatedAt) || 0))
    .forEach(([key, entry]) => nextCache.set(key, entry));
  appState.expandedChart.cache = nextCache;
}

function mergeChartBars(existingBars, incomingBars, maxBars) {
  const merged = new Map();
  (Array.isArray(existingBars) ? existingBars : []).forEach((bar, idx) => {
    const key = chartBarIdentity(bar, idx);
    if (!key) return;
    merged.set(key, bar);
  });
  (Array.isArray(incomingBars) ? incomingBars : []).forEach((bar, idx) => {
    const key = chartBarIdentity(bar, idx);
    if (!key) return;
    const previous = merged.get(key) || {};
    merged.set(key, { ...previous, ...bar });
  });
  return Array.from(merged.values())
    .sort(compareChartBars)
    .slice(-Math.max(1, Number(maxBars) || 90));
}

function syncExpandedChartFromBaseSnapshot(data = appState.data) {
  if (!appState.mainPanelExpanded || !appState.selectedSymbol) return false;
  if (expandedChartTimeframeMode() !== 'ltf') return false;
  const symbol = String(appState.selectedSymbol || '').toUpperCase();
  if (!symbol) return false;
  // Snapshot.bars are 1m streaming bars. For ltf_minutes > 1 they'd collide
  // with the resampled chart cache via abs_index — bail out and let the
  // /api/chart fetch keep the cache fresh instead.
  if (!chartLtfIsOneMinute(data, symbol)) return false;
  const snapshot = activeSnapshotMap(data).get(symbol) || null;
  const baseBars = Array.isArray(snapshot?.bars) ? snapshot.bars : [];
  if (!baseBars.length) return false;
  const maxBars = expandedChartMaxBars(data);
  const sourceKey = expandedChartSourceKey(symbol, maxBars, data);
  const cached = appState.expandedChart.cache.get(sourceKey) || null;
  const currentBars = (
    String(appState.expandedChart.symbol || '').toUpperCase() === symbol &&
    Array.isArray(appState.expandedChart.bars) &&
    appState.expandedChart.bars.length
  ) ? appState.expandedChart.bars : (Array.isArray(cached?.bars) ? cached.bars : []);
  if (!currentBars.length) return false;
  const mergedBars = mergeChartBars(currentBars, baseBars, maxBars);
  if (!mergedBars.length) return false;
  const changed = chartBarsSignature(mergedBars) !== chartBarsSignature(currentBars);
  const mode = expandedChartTimeframeMode();
  // Preserve patterns/structureOverlay from the existing chart cache
  // when the state snapshot doesn't carry them. The state-level snapshot
  // payload (snapshot.chart) NEVER includes `patterns` — that field is
  // only populated by /api/chart fetches via ensureExpandedChartBars.
  // Without this fallback, every state poll wipes
  // appState.expandedChart.patterns to {} for expanded LTF view (this
  // function only runs for LTF, see line ~664), causing the tooltip
  // pattern section to render empty until the next /api/chart fetch
  // re-populates them. Compact version (syncCompactChartFromBaseSnapshot
  // line ~740) already does this.
  const existingPatterns = (cached && typeof cached === 'object' ? cached.patterns : null)
    || appState.expandedChart.patterns
    || {};
  const existingStructureOverlay = (cached && typeof cached === 'object' ? cached.structureOverlay : null)
    || appState.expandedChart.structureOverlay
    || {};
  const cacheEntry = {
    bars: mergedBars,
    lastBarTs: safe(mergedBars[mergedBars.length - 1]?.ts),
    symbol,
    maxBars,
    timeframeMode: mode,
    timeframeLabel: expandedChartTimeframeLabel(data, mode),
    patterns: snapshot?.chart?.patterns || existingPatterns,
    structureOverlay: snapshot?.chart?.structure_overlay || existingStructureOverlay,
    htfRefreshToken: null,
    stateLastUpdate: safe(data?.last_update),
    updatedAt: Date.now(),
  };
  writeExpandedChartCache(sourceKey, cacheEntry);
  appState.expandedChart.maxBars = maxBars;
  appState.expandedChart.timeframeMode = mode;
  appState.expandedChart.symbol = symbol;
  appState.expandedChart.bars = mergedBars;
  appState.expandedChart.sourceKey = sourceKey;
  appState.expandedChart.lastBarTs = cacheEntry.lastBarTs;
  appState.expandedChart.timeframeLabel = cacheEntry.timeframeLabel;
  appState.expandedChart.htfRefreshToken = cacheEntry.htfRefreshToken || null;
  appState.expandedChart.patterns = cacheEntry.patterns || {};
  appState.expandedChart.structureOverlay = cacheEntry.structureOverlay || {};
  appState.expandedChart.stateLastUpdate = cacheEntry.stateLastUpdate || safe(appState.data?.last_update);
  return changed;
}

function syncCompactChartFromBaseSnapshot(data = appState.data) {
  if (appState.mainPanelExpanded || !appState.selectedSymbol) return false;
  if (compactChartTimeframeMode(data) !== 'ltf') return false;
  const symbol = String(appState.selectedSymbol || '').toUpperCase();
  if (!symbol) return false;
  // Same 1m-only gate as the expanded sync above — snapshot.bars are 1m and
  // would corrupt a resampled (5m / 15m / 30m) compact LTF chart cache.
  if (!chartLtfIsOneMinute(data, symbol)) return false;
  const snapshot = activeSnapshotMap(data).get(symbol) || null;
  const baseBars = Array.isArray(snapshot?.bars) ? snapshot.bars : [];
  if (!baseBars.length) return false;
  const maxBars = compactChartMaxBars(data);
  const sourceKey = compactChartSourceKey(symbol, maxBars, 'ltf');
  const cached = appState.compactChart.cache.get(sourceKey) || null;
  const currentBars = (
    String(appState.compactChart.symbol || '').toUpperCase() === symbol
    && normalizedExpandedChartTimeframeMode(appState.compactChart.timeframeMode) === 'ltf'
    && Array.isArray(appState.compactChart.bars)
    && appState.compactChart.bars.length
  ) ? appState.compactChart.bars : (Array.isArray(cached?.bars) ? cached.bars : []);
  if (!currentBars.length) return false;
  const mergedBars = mergeChartBars(currentBars, baseBars, maxBars);
  if (!mergedBars.length) return false;
  const changed = chartBarsSignature(mergedBars) !== chartBarsSignature(currentBars)
    || appState.compactChart.sourceKey !== sourceKey;
  const cacheEntry = {
    bars: mergedBars,
    lastBarTs: safe(mergedBars[mergedBars.length - 1]?.ts),
    symbol,
    maxBars,
    timeframeMode: 'ltf',
    timeframeLabel: expandedChartTimeframeLabel(data, 'ltf'),
    patterns: snapshot?.chart?.patterns || appState.compactChart.patterns || {},
    structureOverlay: snapshot?.chart?.structure_overlay || appState.compactChart.structureOverlay || {},
    htfRefreshToken: null,
    stateLastUpdate: safe(data?.last_update),
    updatedAt: Date.now(),
  };
  writeCompactChartCache(sourceKey, cacheEntry);
  appState.compactChart.maxBars = maxBars;
  appState.compactChart.timeframeMode = 'ltf';
  appState.compactChart.symbol = symbol;
  appState.compactChart.bars = mergedBars;
  appState.compactChart.sourceKey = sourceKey;
  appState.compactChart.lastBarTs = cacheEntry.lastBarTs;
  appState.compactChart.timeframeLabel = cacheEntry.timeframeLabel;
  appState.compactChart.htfRefreshToken = null;
  appState.compactChart.patterns = cacheEntry.patterns || {};
  appState.compactChart.structureOverlay = cacheEntry.structureOverlay || {};
  appState.compactChart.stateLastUpdate = cacheEntry.stateLastUpdate || safe(data?.last_update);
  return changed;
}

function expandedChartSourceKey(symbol, maxBars, data = appState.data, mode = expandedChartTimeframeMode()) {
  const normalizedSymbol = String(symbol || '').toUpperCase();
  const timeframeMode = normalizedExpandedChartTimeframeMode(mode);
  if (timeframeMode === 'htf') {
    return `${normalizedSymbol}|${Math.max(1, Number(maxBars) || 90)}|${timeframeMode}`;
  }
  const snapshot = activeSnapshotMap(data).get(normalizedSymbol) || null;
  const baseBars = Array.isArray(snapshot?.bars) ? snapshot.bars : [];
  const lastBarTs = baseBars.length ? safe(baseBars[baseBars.length - 1]?.ts) : safe(data?.last_update);
  return `${normalizedSymbol}|${Math.max(1, Number(maxBars) || 90)}|${timeframeMode}|${lastBarTs}`;
}

function currentChartBars(snapshot) {
  const baseBars = Array.isArray(snapshot?.bars) ? snapshot.bars : [];
  const expanded = appState.expandedChart || {};
  const compact = appState.compactChart || {};
  if (!snapshot?.symbol) return baseBars;
  if (!appState.mainPanelExpanded) {
    const targetSymbol = String(snapshot.symbol || '').toUpperCase();
    const compactMode = compactChartTimeframeMode(appState.data);
    const targetMaxBars = compactChartMaxBars(appState.data);
    const targetSourceKey = compactChartSourceKey(targetSymbol, targetMaxBars, compactMode);
    const cachedCompact = appState.compactChart.cache.get(targetSourceKey) || null;
    const cachedCompactBars = Array.isArray(cachedCompact?.bars) ? cachedCompact.bars : [];
    const compactSymbol = String(compact.symbol || '').toUpperCase();
    const compactBars = Array.isArray(compact.bars) ? compact.bars : [];
    const compactModeMatchesTarget = compactSymbol === targetSymbol
      && normalizedExpandedChartTimeframeMode(compact.timeframeMode) === compactMode
      && compactBars.length;
    const compactMatchesTarget = compactModeMatchesTarget
      && compact.sourceKey === targetSourceKey;
    // Only merge the snapshot's 1m streaming bars when the LTF chart is
    // itself 1m-grained — see chartLtfIsOneMinute. For ltf_minutes > 1 the
    // 1m bars would collide on abs_index and overwrite the resampled
    // candles.
    const mergeBaseBarsAllowed = compactMode === 'ltf' && baseBars.length && chartLtfIsOneMinute(appState.data, targetSymbol);
    if (compactMatchesTarget) {
      if (!mergeBaseBarsAllowed) return compactBars;
      return mergeChartBars(compactBars, baseBars, targetMaxBars);
    }
    if (compactModeMatchesTarget) {
      if (!mergeBaseBarsAllowed) return compactBars;
      return mergeChartBars(compactBars, baseBars, targetMaxBars);
    }
    if (cachedCompactBars.length) {
      if (!mergeBaseBarsAllowed) return cachedCompactBars;
      return mergeChartBars(cachedCompactBars, baseBars, targetMaxBars);
    }
    const loadingSelected = !!compact.isLoading && String(appState.selectedSymbol || '').toUpperCase() === targetSymbol;
    if (loadingSelected && compactMode === 'ltf' && baseBars.length && baseBars.length < targetMaxBars) {
      return [];
    }
    // Final fallback: snapshot.bars are 1m streaming bars. Returning them as
    // the chart payload only makes sense when the strategy's LTF is 1m. For
    // ltf_minutes > 1 the 1m bars would briefly show on a chart labeled as
    // (e.g.) 5m until the /api/chart fetch lands — visually wrong. Show
    // empty bars in that case so the loading state takes over instead.
    if (compactMode === 'ltf' && !chartLtfIsOneMinute(appState.data, targetSymbol)) return [];
    return baseBars;
  }
  const targetSymbol = String(snapshot.symbol || '').toUpperCase();
  const targetMode = expandedChartTimeframeMode();
  const targetMaxBars = expandedChartMaxBars(appState.data);
  const targetSourceKey = expandedChartSourceKey(targetSymbol, targetMaxBars, appState.data, targetMode);
  const cachedExpanded = appState.expandedChart.cache.get(targetSourceKey) || null;
  const cachedExpandedBars = Array.isArray(cachedExpanded?.bars) ? cachedExpanded.bars : [];
  if (String(expanded.symbol || '').toUpperCase() !== targetSymbol) {
    return cachedExpandedBars.length ? cachedExpandedBars : [];
  }
  if (normalizedExpandedChartTimeframeMode(expanded.timeframeMode) !== targetMode) {
    return cachedExpandedBars.length ? cachedExpandedBars : [];
  }
  if (!Array.isArray(expanded.bars) || !expanded.bars.length) {
    return cachedExpandedBars.length ? cachedExpandedBars : [];
  }
  // Same 1m-only merge gate as the compact branch above. For HTF mode or
  // an LTF > 1m, the snapshot's 1m bars would collide with the chart's
  // resampled candles via abs_index and corrupt the visible window.
  if (targetMode !== 'ltf' || !baseBars.length || !chartLtfIsOneMinute(appState.data, targetSymbol)) return expanded.bars;
  return mergeChartBars(expanded.bars, baseBars, targetMaxBars);
}

function chartLoadingState(snapshot) {
  const symbol = String(snapshot?.symbol || '').toUpperCase();
  if (!symbol) return { active: false, message: 'Loading chart…' };
  if (appState.mainPanelExpanded) {
    const active = !!appState.expandedChart?.isLoading && String(appState.selectedSymbol || '').toUpperCase() === symbol;
    return { active, message: 'Loading expanded chart…' };
  }
  const compactMode = compactChartTimeframeMode(appState.data);
  const active = !!appState.compactChart?.isLoading && String(appState.selectedSymbol || '').toUpperCase() === symbol;
  return { active, message: 'Loading chart…' };
}

function renderChartTimeframeToggle(data = appState.data) {
  const toggle = document.getElementById('chart-timeframe-toggle');
  if (!toggle) return;
  const mode = expandedChartTimeframeMode();
  const htfLabel = expandedChartTimeframeLabel(data, 'htf');
  toggle.querySelectorAll('.chart-timeframe-btn[data-timeframe-mode]').forEach((btn) => {
    const btnMode = normalizedExpandedChartTimeframeMode(btn.dataset.timeframeMode);
    btn.classList.toggle('active', btnMode === mode);
    if (btnMode === 'htf') btn.textContent = `HTF ${htfLabel}`;
    if (btnMode === 'ltf') btn.textContent = `${expandedChartTimeframeLabel(data, 'ltf')} LTF`;
  });
}

function setExpandedChartTimeframeMode(mode) {
  const next = normalizedExpandedChartTimeframeMode(mode);
  if (appState.expandedChart.timeframeMode === next) {
    renderChartTimeframeToggle(appState.data);
    if (appState.mainPanelExpanded) scheduleExpandedChartRefresh(true);
    return;
  }
  appState.expandedChart.timeframeMode = next;
  appState.expandedChart.isLoading = true;
  appState.expandedChart.bars = null;
  appState.expandedChart.sourceKey = null;
  appState.expandedChart.lastBarTs = null;
  appState.expandedChart.timeframeLabel = null;
  appState.expandedChart.emaFastSpan = null;
  appState.expandedChart.emaSlowSpan = null;
  appState.expandedChart.htfRefreshToken = null;
  appState.expandedChart.patterns = {};
  appState.expandedChart.structureOverlay = {};
  appState.expandedChart.pinnedBarId = null;
  if (appState.data) renderSelectedSymbol();
  else renderChartTimeframeToggle();
  if (appState.mainPanelExpanded) scheduleExpandedChartRefresh(true);
}

function cancelScheduledExpandedChartRefresh() {
  const rafId = Number(appState.expandedChart?.refreshRafId || 0);
  if (rafId) {
    window.cancelAnimationFrame(rafId);
    appState.expandedChart.refreshRafId = 0;
  }
  appState.expandedChart.pendingForceRefresh = false;
}

function resetExpandedChartCache() {
  cancelScheduledExpandedChartRefresh();
  appState.expandedChart.symbol = null;
  appState.expandedChart.bars = null;
  appState.expandedChart.sourceKey = null;
  appState.expandedChart.lastBarTs = null;
  appState.expandedChart.timeframeLabel = null;
  appState.expandedChart.emaFastSpan = null;
  appState.expandedChart.emaSlowSpan = null;
  appState.expandedChart.htfRefreshToken = null;
  appState.expandedChart.patterns = {};
  appState.expandedChart.structureOverlay = {};
  appState.expandedChart.stateLastUpdate = null;
  appState.expandedChart.pinnedBarId = null;
  appState.expandedChart.isLoading = false;
  pruneExpandedChartCache();
}

function compactChartSourceKey(symbol, maxBars, mode = compactChartTimeframeMode(appState.data)) {
  const normalizedSymbol = String(symbol || '').toUpperCase();
  const timeframeMode = normalizedExpandedChartTimeframeMode(mode);
  if (timeframeMode === 'htf') return `${normalizedSymbol}|${Math.max(1, Number(maxBars) || 90)}|${timeframeMode}`;
  const snapshot = activeSnapshotMap(appState.data).get(normalizedSymbol) || null;
  const baseBars = Array.isArray(snapshot?.bars) ? snapshot.bars : [];
  const lastBarTs = baseBars.length ? safe(baseBars[baseBars.length - 1]?.ts) : safe(appState.data?.last_update);
  return `${normalizedSymbol}|${Math.max(1, Number(maxBars) || 90)}|${timeframeMode}|${lastBarTs}`;
}

function writeCompactChartCache(sourceKey, cacheEntry) {
  if (!sourceKey || !cacheEntry || !Array.isArray(cacheEntry.bars) || !cacheEntry.bars.length) return;
  const symbol = String(cacheEntry.symbol || '').toUpperCase();
  const maxBars = Math.max(1, Number(cacheEntry.maxBars) || 90);
  appState.compactChart.cache.set(sourceKey, {
    ...cacheEntry,
    symbol,
    maxBars,
    updatedAt: Number(cacheEntry.updatedAt) || Date.now(),
  });
  pruneCompactChartCache({ preserveSourceKey: sourceKey });
}

function pruneCompactChartCache({ preserveSourceKey = null } = {}) {
  const cache = appState.compactChart.cache;
  if (!(cache instanceof Map) || !cache.size) return;
  const now = Date.now();
  const preserved = new Set([preserveSourceKey, appState.compactChart.sourceKey].filter(Boolean));
  const latestByPrefix = new Map();
  for (const [key, entry] of cache.entries()) {
    if (!entry || !Array.isArray(entry.bars) || !entry.bars.length) continue;
    const updatedAt = Number(entry.updatedAt) || now;
    if (!preserved.has(key) && (now - updatedAt) > COMPACT_CHART_CACHE_TTL_MS) continue;
    const symbol = String(entry.symbol || '').toUpperCase();
    const maxBars = Math.max(1, Number(entry.maxBars) || Number(entry.bars?.length) || 90);
    const timeframeMode = normalizedExpandedChartTimeframeMode(entry.timeframeMode);
    const prefix = `${symbol}|${maxBars}|${timeframeMode}`;
    const current = latestByPrefix.get(prefix);
    const shouldReplace = !current || preserved.has(key) || (!preserved.has(current[0]) && updatedAt >= (Number(current[1]?.updatedAt) || 0));
    if (shouldReplace) latestByPrefix.set(prefix, [key, { ...entry, symbol, maxBars, updatedAt }]);
  }
  let entries = Array.from(latestByPrefix.values());
  entries.sort((left, right) => (Number(right[1]?.updatedAt) || 0) - (Number(left[1]?.updatedAt) || 0));
  if (entries.length > COMPACT_CHART_CACHE_MAX) {
    const keepKeys = new Set(entries.slice(0, COMPACT_CHART_CACHE_MAX).map(([key]) => key));
    preserved.forEach((key) => {
      if (!keepKeys.has(key) && cache.has(key)) {
        const entry = cache.get(key);
        if (entry && Array.isArray(entry.bars) && entry.bars.length) {
          keepKeys.add(key);
          entries.push([key, entry]);
        }
      }
    });
    entries = entries.filter(([key]) => keepKeys.has(key));
  }
  const nextCache = new Map();
  entries
    .sort((left, right) => (Number(left[1]?.updatedAt) || 0) - (Number(right[1]?.updatedAt) || 0))
    .forEach(([key, entry]) => nextCache.set(key, entry));
  appState.compactChart.cache = nextCache;
}

function remoteChartCacheNeedsRefresh(entry, data = appState.data, timeframeMode = 'ltf') {
  if (!entry || !Array.isArray(entry.bars) || !entry.bars.length) return true;
  const normalizedMode = normalizedExpandedChartTimeframeMode(timeframeMode);
  if (normalizedMode !== 'htf') return false;
  const currentToken = currentHtfRefreshToken(data, entry?.symbol || appState.selectedSymbol);
  const entryToken = String(entry?.htfRefreshToken || '').trim();
  if (currentToken || entryToken) return currentToken !== entryToken;
  return false;
}

async function ensureCompactChartBars(force = false) {
  if (appState.mainPanelExpanded || !appState.selectedSymbol) return null;
  const timeframeMode = compactChartTimeframeMode(appState.data);
  const symbol = String(appState.selectedSymbol || '').toUpperCase();
  const maxBars = compactChartMaxBars(appState.data);
  const sourceKey = compactChartSourceKey(symbol, maxBars, timeframeMode);
  const cached = appState.compactChart.cache.get(sourceKey) || null;
  if (!force
    && appState.compactChart.symbol === symbol
    && appState.compactChart.sourceKey === sourceKey
    && Array.isArray(appState.compactChart.bars)
    && appState.compactChart.bars.length
    && !remoteChartCacheNeedsRefresh(appState.compactChart, appState.data, timeframeMode)) {
    appState.compactChart.isLoading = false;
    return appState.compactChart.bars;
  }
  if (!force && cached && !remoteChartCacheNeedsRefresh(cached, appState.data, timeframeMode)) {
    appState.compactChart.symbol = symbol;
    appState.compactChart.bars = cached.bars;
    appState.compactChart.timeframeMode = timeframeMode;
    appState.compactChart.sourceKey = sourceKey;
    appState.compactChart.lastBarTs = cached.lastBarTs;
    appState.compactChart.timeframeLabel = cached.timeframeLabel || expandedChartTimeframeLabel(appState.data, timeframeMode);
    appState.compactChart.emaFastSpan = cached.emaFastSpan ?? null;
    appState.compactChart.emaSlowSpan = cached.emaSlowSpan ?? null;
    appState.compactChart.htfRefreshToken = cached.htfRefreshToken || null;
    appState.compactChart.patterns = cached.patterns || {};
    appState.compactChart.structureOverlay = cached.structureOverlay || {};
    appState.compactChart.stateLastUpdate = cached.stateLastUpdate || safe(appState.data?.last_update);
    appState.compactChart.isLoading = false;
    if (appState.data) renderSelectedSymbol();
    return cached.bars;
  }
  const requestSeq = (appState.compactChart.requestSeq || 0) + 1;
  appState.compactChart.requestSeq = requestSeq;
  appState.compactChart.isLoading = true;
  if (appState.data) renderSelectedSymbol();
  let res;
  try {
    res = await fetch(`/api/chart?symbol=${encodeURIComponent(symbol)}&bars=${encodeURIComponent(maxBars)}&timeframe=${encodeURIComponent(timeframeMode)}&ts=${Date.now()}`, { cache: 'no-store' });
  } catch (err) {
    if (appState.compactChart.requestSeq === requestSeq) appState.compactChart.isLoading = false;
    throw err;
  }
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const payload = await res.json();
  if (appState.mainPanelExpanded || appState.compactChart.requestSeq !== requestSeq || String(appState.selectedSymbol || '').toUpperCase() !== symbol) {
    if (appState.compactChart.requestSeq === requestSeq) appState.compactChart.isLoading = false;
    return null;
  }
  const bars = Array.isArray(payload?.bars) ? payload.bars : [];
  const cacheEntry = {
    bars,
    lastBarTs: safe(payload?.last_bar_ts || (bars.length ? bars[bars.length - 1]?.ts : null)),
    symbol,
    maxBars,
    timeframeMode,
    timeframeLabel: String(payload?.timeframe_label || expandedChartTimeframeLabel(appState.data, timeframeMode)),
    // Capture EMA spans from the chart payload so the chart legend can render
    // strategy-specific spans (e.g. EMA34 / EMA200 in HTF mode for
    // peer_confirmed_key_levels) instead of the universal 9 / 20 fallback.
    emaFastSpan: Number(payload?.ema_fast_span) || null,
    emaSlowSpan: Number(payload?.ema_slow_span) || null,
    htfRefreshToken: String(payload?.htf_refresh_token || currentHtfRefreshToken(appState.data, symbol) || '').trim() || null,
    patterns: payload?.patterns || {},
    structureOverlay: payload?.structure_overlay || {},
    stateLastUpdate: safe(appState.data?.last_update),
    updatedAt: Date.now(),
  };
  writeCompactChartCache(sourceKey, cacheEntry);
  appState.compactChart.symbol = symbol;
  appState.compactChart.bars = bars;
  appState.compactChart.timeframeMode = timeframeMode;
  appState.compactChart.sourceKey = sourceKey;
  appState.compactChart.lastBarTs = cacheEntry.lastBarTs;
  appState.compactChart.timeframeLabel = cacheEntry.timeframeLabel;
  appState.compactChart.emaFastSpan = cacheEntry.emaFastSpan;
  appState.compactChart.emaSlowSpan = cacheEntry.emaSlowSpan;
  appState.compactChart.htfRefreshToken = cacheEntry.htfRefreshToken;
  appState.compactChart.patterns = cacheEntry.patterns || {};
  appState.compactChart.structureOverlay = cacheEntry.structureOverlay || {};
  appState.compactChart.stateLastUpdate = cacheEntry.stateLastUpdate;
  appState.compactChart.isLoading = false;
  renderSelectedSymbol();
  return bars;
}

function resetCompactChartCache() {
  appState.compactChart.symbol = null;
  appState.compactChart.bars = null;
  appState.compactChart.sourceKey = null;
  appState.compactChart.lastBarTs = null;
  appState.compactChart.timeframeLabel = null;
  appState.compactChart.emaFastSpan = null;
  appState.compactChart.emaSlowSpan = null;
  appState.compactChart.htfRefreshToken = null;
  appState.compactChart.patterns = {};
  appState.compactChart.structureOverlay = {};
  appState.compactChart.stateLastUpdate = null;
  appState.compactChart.isLoading = false;
  pruneCompactChartCache();
}

async function ensureExpandedChartBars(force = false) {
  if (!appState.mainPanelExpanded || !appState.selectedSymbol) return null;
  const symbol = String(appState.selectedSymbol || '').toUpperCase();
  if (!symbol) return null;
  const maxBars = expandedChartMaxBars(appState.data);
  const timeframeMode = expandedChartTimeframeMode();
  const sourceKey = expandedChartSourceKey(symbol, maxBars, appState.data, timeframeMode);
  if (!force && appState.expandedChart.symbol === symbol && appState.expandedChart.sourceKey === sourceKey && Array.isArray(appState.expandedChart.bars) && appState.expandedChart.bars.length && !remoteChartCacheNeedsRefresh(appState.expandedChart, appState.data, timeframeMode)) {
    appState.expandedChart.isLoading = false;
    return appState.expandedChart.bars;
  }
  if (!force && appState.expandedChart.cache.has(sourceKey)) {
    const cached = appState.expandedChart.cache.get(sourceKey);
    if (!remoteChartCacheNeedsRefresh(cached, appState.data, timeframeMode)) {
      writeExpandedChartCache(sourceKey, { ...cached, symbol, maxBars, timeframeMode, timeframeLabel: expandedChartTimeframeLabel(appState.data, timeframeMode), updatedAt: Date.now() });
      appState.expandedChart.symbol = symbol;
      appState.expandedChart.bars = cached.bars;
      appState.expandedChart.timeframeMode = timeframeMode;
      appState.expandedChart.sourceKey = sourceKey;
      appState.expandedChart.lastBarTs = cached.lastBarTs;
      appState.expandedChart.timeframeLabel = cached.timeframeLabel || expandedChartTimeframeLabel(appState.data, timeframeMode);
      appState.expandedChart.emaFastSpan = cached.emaFastSpan ?? null;
      appState.expandedChart.emaSlowSpan = cached.emaSlowSpan ?? null;
      appState.expandedChart.htfRefreshToken = cached.htfRefreshToken || null;
      appState.expandedChart.patterns = cached.patterns || {};
      appState.expandedChart.structureOverlay = cached.structureOverlay || {};
      appState.expandedChart.stateLastUpdate = cached.stateLastUpdate || safe(appState.data?.last_update);
      appState.expandedChart.isLoading = false;
      renderSelectedSymbol();
      return cached.bars;
    }
  }
  const requestSeq = (appState.expandedChart.requestSeq || 0) + 1;
  appState.expandedChart.requestSeq = requestSeq;
  appState.expandedChart.isLoading = true;
  if (appState.data) renderSelectedSymbol();
  let res;
  try {
    res = await fetch(`/api/chart?symbol=${encodeURIComponent(symbol)}&bars=${encodeURIComponent(maxBars)}&timeframe=${encodeURIComponent(timeframeMode)}&ts=${Date.now()}`, { cache: 'no-store' });
  } catch (err) {
    if (appState.expandedChart.requestSeq === requestSeq) appState.expandedChart.isLoading = false;
    throw err;
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const payload = await res.json();
  if (!appState.mainPanelExpanded || appState.expandedChart.requestSeq !== requestSeq || String(appState.selectedSymbol || '').toUpperCase() !== symbol) {
    if (appState.expandedChart.requestSeq === requestSeq) appState.expandedChart.isLoading = false;
    return null;
  }
  const bars = Array.isArray(payload?.bars) ? payload.bars : [];
  const cacheEntry = {
    bars,
    lastBarTs: payload?.last_bar_ts || null,
    symbol,
    maxBars,
    timeframeMode,
    timeframeLabel: String(payload?.timeframe_label || expandedChartTimeframeLabel(appState.data, timeframeMode)),
    // Capture EMA spans from the chart payload so HTF mode renders the
    // strategy's htf_ema_fast_span / htf_ema_slow_span on legend chips
    // (e.g. EMA34 / EMA200) instead of the LTF default 9 / 20.
    emaFastSpan: Number(payload?.ema_fast_span) || null,
    emaSlowSpan: Number(payload?.ema_slow_span) || null,
    htfRefreshToken: String(payload?.htf_refresh_token || currentHtfRefreshToken(appState.data, symbol) || '').trim() || null,
    patterns: payload?.patterns || {},
    structureOverlay: payload?.structure_overlay || {},
    stateLastUpdate: safe(appState.data?.last_update),
    updatedAt: Date.now(),
  };
  writeExpandedChartCache(sourceKey, cacheEntry);
  appState.expandedChart.symbol = symbol;
  appState.expandedChart.bars = bars;
  appState.expandedChart.timeframeMode = timeframeMode;
  appState.expandedChart.sourceKey = sourceKey;
  appState.expandedChart.lastBarTs = cacheEntry.lastBarTs;
  appState.expandedChart.timeframeLabel = cacheEntry.timeframeLabel;
  appState.expandedChart.emaFastSpan = cacheEntry.emaFastSpan;
  appState.expandedChart.emaSlowSpan = cacheEntry.emaSlowSpan;
  appState.expandedChart.htfRefreshToken = cacheEntry.htfRefreshToken;
  appState.expandedChart.patterns = cacheEntry.patterns || {};
  appState.expandedChart.structureOverlay = cacheEntry.structureOverlay || {};
  appState.expandedChart.stateLastUpdate = cacheEntry.stateLastUpdate;
  appState.expandedChart.isLoading = false;
  renderSelectedSymbol();
  return bars;
}

function scheduleExpandedChartRefresh(force = false) {
  if (!appState.mainPanelExpanded) return;
  appState.expandedChart.pendingForceRefresh = !!appState.expandedChart.pendingForceRefresh || !!force;
  if (appState.expandedChart.refreshRafId) return;
  appState.expandedChart.refreshRafId = window.requestAnimationFrame(() => {
    appState.expandedChart.refreshRafId = 0;
    const nextForce = !!appState.expandedChart.pendingForceRefresh;
    appState.expandedChart.pendingForceRefresh = false;
    ensureExpandedChartBars(nextForce).catch(err => console.warn('Expanded chart fetch failed', err));
  });
}

function chooseDefaultSymbol(data) {
  const candidates = [];
  const positions = data?.performance?.positions || [];
  positions.forEach(row => candidates.push(String(row.underlying || row.symbol || '').toUpperCase()));
  (data?.candidates || []).forEach(row => candidates.push(String(row.symbol || '').toUpperCase()));
  (data?.active_watchlist || []).forEach(sym => candidates.push(String(sym || '').toUpperCase()));
  (data?.dashboard_symbols || []).forEach(row => candidates.push(String(row.symbol || '').toUpperCase()));
  return candidates.find(Boolean) || null;
}

function syncSelectedSymbol(data) {
  const map = activeSnapshotMap(data);
  if (appState.selectedSymbol && map.has(appState.selectedSymbol)) return appState.selectedSymbol;
  appState.selectedSymbol = chooseDefaultSymbol(data);
  return appState.selectedSymbol;
}

function setSelectedSymbol(symbol) {
  if (!symbol) return;
  const nextSymbol = String(symbol).toUpperCase();
  if (appState.selectedSymbol === nextSymbol && !appState.mainPanelExpanded) return;
  appState.selectedSymbol = nextSymbol;
  if (appState.expandedChart.symbol && appState.expandedChart.symbol !== nextSymbol) resetExpandedChartCache();
  if (appState.compactChart.symbol && appState.compactChart.symbol !== nextSymbol) resetCompactChartCache();
  if (appState.mainPanelExpanded) {
    appState.expandedChart.isLoading = true;
  } else {
    const timeframeMode = compactChartTimeframeMode(appState.data);
    const maxBars = compactChartMaxBars(appState.data);
    const sourceKey = compactChartSourceKey(nextSymbol, maxBars, timeframeMode);
    const cached = appState.compactChart.cache.get(sourceKey) || null;
    if (cached && !remoteChartCacheNeedsRefresh(cached, appState.data, timeframeMode)) {
      appState.compactChart.symbol = nextSymbol;
      appState.compactChart.bars = Array.isArray(cached.bars) ? cached.bars : null;
      appState.compactChart.timeframeMode = timeframeMode;
      appState.compactChart.sourceKey = sourceKey;
      appState.compactChart.lastBarTs = cached.lastBarTs || null;
      appState.compactChart.timeframeLabel = cached.timeframeLabel || expandedChartTimeframeLabel(appState.data, timeframeMode);
      appState.compactChart.htfRefreshToken = cached.htfRefreshToken || null;
      appState.compactChart.patterns = cached.patterns || {};
      appState.compactChart.structureOverlay = cached.structureOverlay || {};
      appState.compactChart.stateLastUpdate = cached.stateLastUpdate || safe(appState.data?.last_update);
      appState.compactChart.isLoading = false;
    } else {
      appState.compactChart.isLoading = true;
    }
  }
  renderApp();
  if (appState.mainPanelExpanded) scheduleExpandedChartRefresh(true);
  else ensureCompactChartBars(true).catch(err => console.warn('Compact chart fetch failed', err));
}

function mainPanelElement() {
  return document.querySelector('.main-panel.chart-panel');
}

function pointInsideRect(pointX, pointY, rect) {
  if (!rect) return false;
  return pointX >= rect.left && pointX <= rect.right && pointY >= rect.top && pointY <= rect.bottom;
}

function isPointerInsideExpandedPanel(event) {
  const panel = mainPanelElement();
  if (!panel || !event) return false;
  return pointInsideRect(event.clientX, event.clientY, panel.getBoundingClientRect());
}

function scheduleMainPanelChartRerender() {
  window.requestAnimationFrame(() => {
    if (appState.data) renderSelectedSymbol();
  });
}

function lockExpandedSidePanelHeights() {
  const rootStyle = document.documentElement.style;
  const watchlist = document.querySelector('.watchlist-panel');
  const candidates = document.querySelector('.candidates-panel');
  const positionsSlot = document.querySelector('.positions-slot');
  const positionsPanel = document.querySelector('.positions-panel');
  if (watchlist) rootStyle.setProperty('--watchlist-locked-h', `${Math.round(watchlist.getBoundingClientRect().height)}px`);
  if (candidates) rootStyle.setProperty('--candidates-locked-h', `${Math.round(candidates.getBoundingClientRect().height)}px`);
  const positionsHeight = positionsPanel?.getBoundingClientRect().height || positionsSlot?.getBoundingClientRect().height || 0;
  if (positionsHeight > 0) rootStyle.setProperty('--positions-locked-h', `${Math.round(positionsHeight)}px`);
}

function unlockExpandedSidePanelHeights() {
  const rootStyle = document.documentElement.style;
  rootStyle.removeProperty('--watchlist-locked-h');
  rootStyle.removeProperty('--candidates-locked-h');
  rootStyle.removeProperty('--positions-locked-h');
}

function setMainPanelExpanded(expanded) {
  const next = Boolean(expanded);
  if (appState.mainPanelExpanded === next) {
    if (next) scheduleExpandedChartRefresh(false);
    else {
      cancelScheduledExpandedChartRefresh();
      pruneExpandedChartCache();
    }
    return;
  }
  if (next) {
    lockExpandedSidePanelHeights();
    appState.expandedChart.timeframeMode = 'ltf';
    appState.expandedChart.isLoading = true;
    renderChartTimeframeToggle(appState.data);
  } else {
    cancelScheduledExpandedChartRefresh();
    unlockExpandedSidePanelHeights();
  }
  appState.mainPanelExpanded = next;
  document.documentElement.classList.toggle('main-panel-expanded', next);
  window.requestAnimationFrame(() => {
    syncWatchlistViewport();
    syncCandidatesViewport();
    syncPositionsViewport();
    syncDockViewport();
  });
  const tooltip = document.getElementById('chart-tooltip');
  if (tooltip) {
    tooltip.classList.remove('active');
    tooltip.innerHTML = '';
  }
  if (!next) {
    appState.expandedChart.isLoading = false;
    appState.expandedChart.pinnedBarId = null;
    pruneExpandedChartCache();
  }
  if (appState.data) renderSelectedSymbol();
  scheduleMainPanelChartRerender();
  if (next) scheduleExpandedChartRefresh(false);
}

function handleExpandedPanelPointerMove(event) {
  if (!appState.mainPanelExpanded) return;
  if (isPointerInsideExpandedPanel(event)) return;
  setMainPanelExpanded(false);
}

function bindMainPanelHover() {
  const panel = mainPanelElement();
  if (!panel || panel.dataset.expandBound === '1') return;
  panel.dataset.expandBound = '1';
  const chartWrap = panel.querySelector('.chart-wrap');
  if (chartWrap) {
    chartWrap.addEventListener('click', (event) => {
      if (appState.mainPanelExpanded) return;
      event.preventDefault();
      event.stopPropagation();
      appState.expandedChart.pinnedBarId = null;
      setMainPanelExpanded(true);
    });
  }
  window.addEventListener('pointermove', handleExpandedPanelPointerMove, true);
}

function setFilter(filter) {
  appState.filter = filter;
  document.querySelectorAll('.toggle-btn[data-filter]').forEach(btn => btn.classList.toggle('active', btn.dataset.filter === filter));
  renderWatchlist();
}

function activeDockScroller() {
  const page = document.querySelector('.dock-pane.active');
  if (!page) return null;
  return page.querySelector('.dock-scroll, .table-scroll');
}

function wireDockWheel() {
  const dock = document.querySelector('.dock');
  if (dock && dock.dataset.wheelBound !== '1') {
    dock.dataset.wheelBound = '1';
    dock.addEventListener('wheel', (event) => {
      const scroller = activeDockScroller();
      if (!scroller || scroller.scrollHeight <= scroller.clientHeight) return;
      scroller.scrollBy({ top: event.deltaY, left: event.deltaX, behavior: 'auto' });
      event.preventDefault();
    }, { passive: false });
  }
  document.querySelectorAll('.dock .dock-scroll, .dock .table-scroll').forEach(node => {
    if (node.dataset.wheelBound === '1') return;
    node.dataset.wheelBound = '1';
    node.addEventListener('wheel', (event) => {
      if (node.scrollHeight <= node.clientHeight && Math.abs(event.deltaX) < Math.abs(event.deltaY)) return;
      node.scrollBy({ top: event.deltaY, left: event.deltaX, behavior: 'auto' });
      event.preventDefault();
    }, { passive: false });
  });
}

function setDockTab(tab) {
  appState.dockTab = tab;
  document.querySelectorAll('.tab-btn[data-tab]').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
  document.querySelectorAll('.dock-pane').forEach(page => page.classList.toggle('active', page.dataset.page === tab));
  wireDockWheel();
}

// scorePct moved to helpers.js so both desktop + mobile candidate
// renderers can use the same log-scaled mapping. Kept here as a
// reference so a future reader knows the function exists; the
// definition is in helpers.js.

function rangePct(price, support, resistance) {
  const p = positiveOrNull(price); const s = positiveOrNull(support); const r = positiveOrNull(resistance);
  if (p === null || s === null || r === null || r <= s) return null;
  return clamp(((p - s) / (r - s)) * 100, 0, 100);
}

function getDashboardNonStreamableSymbols(data) {
  const raw = Array.isArray(data?.data?.non_streamable_symbols) ? data.data.non_streamable_symbols : [];
  return raw.map(sym => String(sym || '').toUpperCase()).filter(Boolean);
}

function getDashboardTradableSymbols(data) {
  const raw = Array.isArray(data?.data?.tradable_symbols) ? data.data.tradable_symbols : [];
  return raw.map(sym => String(sym || '').toUpperCase()).filter(Boolean);
}

function getDashboardIndexSymbols(data) {
  const raw = Array.isArray(data?.data?.index_symbols) ? data.data.index_symbols : [];
  return raw.map(sym => String(sym || '').toUpperCase()).filter(Boolean);
}

function buildWatchlistRows(data) {
  const snapshotMap = buildSnapshotMap(data);
  const activeOrder = (data?.active_watchlist || []).map(sym => String(sym || '').toUpperCase()).filter(Boolean);
  const rows = activeOrder
    .map(sym => snapshotMap.get(sym))
    .filter(Boolean);
  if (appState.filter === 'all') return rows;
  return rows.filter(item => {
    const tone = selectedSymbolTone(item);
    return appState.filter === 'long' ? tone === 'tone-long' : tone === 'tone-short';
  });
}

function renderWatchlist() {
  const data = appState.data;
  const activeSymbols = (data?.active_watchlist || []).map(sym => String(sym || '').toUpperCase()).filter(Boolean);
  const rows = buildWatchlistRows(data);
  document.getElementById('watchlist-meta').textContent = `${activeSymbols.length} symbols`;
  const exchangeMap = data?.symbol_exchanges || {};
  const nonStreamSet = new Set(getDashboardNonStreamableSymbols(data));
  const tradableSet = new Set(getDashboardTradableSymbols(data));
  const indexSet = new Set(getDashboardIndexSymbols(data));
  const html = rows.length ? rows.map(item => {
    const tone = selectedSymbolTone(item);
    const q = item.quote || {};
    const bars = item.bars || [];
    const values = bars.map(bar => numOrNull(bar.close)).filter(v => v !== null);
    const last = q.last ?? (values.length ? values[values.length - 1] : null);
    // "Day %" display priority: live Schwab percent_change (prior-close) →
    // screener `change` (prior-close, emitted by top_tier_adaptive) →
    // screener `change_from_open` (session-relative, for strategies that
    // don't emit `change`). Preserves prior-close semantic in the fallback
    // when both are available; falls through to session-relative as last
    // resort for strategies that only ship change_from_open.
    const change = numOrNull(q.percent_change) ?? numOrNull(item?.candidate?.change) ?? numOrNull(item?.candidate?.change_from_open);
    const warmup = item?.warmup || null;
    const lowerBase = item.description || `${safe(item?.candidate?.directional_bias || item?.position?.side || item?.support_resistance?.state || 'watchlist')}`;
    const lower = warmup && !warmup.ready ? `${lowerBase} · ${warmupLabel(warmup)}` : lowerBase;
    const isActive = appState.selectedSymbol === item.symbol;
    const symbolKey = String(item?.symbol || '').toUpperCase();
    const isNonStreamable = nonStreamSet.has(symbolKey);
    const isTradable = tradableSet.has(symbolKey);
    const isIndexSymbol = indexSet.has(symbolKey);
    const tradableChip = isTradable ? '<span class="tradeable-chip" title="Tradeable: configured as an eligible entry symbol for this strategy">TR</span>' : '';
    const nonStreamChip = isNonStreamable ? '<span class="ns-chip" title="Non-streamable: included in the active watchlist but not in the Schwab equity stream">NS</span>' : '';
    const indexChip = isIndexSymbol && !isTradable ? '<span class="index-chip" title="Index ETF: used for directional confirmation via sector_index_map / index_symbols (not a tradable entry symbol)">IX</span>' : '';
    return `<div class="symbol-card ${tone} ${isActive ? 'active' : ''}" data-symbol="${escapeHtml(item.symbol)}">
      <div class="symbol-top">
        <div>
          <div class="symbol-title-row"><div class="symbol-name">${escapeHtml(item.symbol)}</div>${tradableChip}${indexChip}${nonStreamChip}</div>
          <div class="symbol-sub">${escapeHtml(lower)}</div>
        </div>
        <div class="price-stack">
          <div class="price-main">${fmtNum(last, 2)}</div>
          <div class="price-change ${pnlClass(change)}">${fmtPct(change, 2)}</div>
        </div>
      </div>
      <div class="sparkline-wrap">${sparklineSVG(values, change > 0 ? 'tone-good' : (change < 0 ? 'tone-bad' : 'tone-neutral'))}</div>
      <div class="card-bottom">
        <div class="mini-meta">${symbolLink(item.symbol, exchangeMap, item.symbol, item.exchange)}</div>
        <div style="display:flex; gap:8px; align-items:center;">${iconForState(item?.support_resistance?.trend_state, item?.support_resistance?.trend, 'Trend')}${structureEventChip(item?.support_resistance?.structure_event || '—')}</div>
      </div>
    </div>`;
  }).join('') : `<div class="empty-state">No watchlist symbols are available for the current filter.</div>`;
  const target = document.getElementById('watchlist-list');
  target.innerHTML = html;
  target.querySelectorAll('.symbol-card[data-symbol]').forEach(card => card.addEventListener('click', () => setSelectedSymbol(card.dataset.symbol)));
}

function renderCandidates() {
  const data = appState.data;
  const snapshots = buildSnapshotMap(data);
  const rows = data?.candidates || [];
  document.getElementById('candidate-meta').textContent = `${rows.length} shown · ${safe(data?.candidates?.length || 0)} ranked`;
  const html = rows.length ? rows.map(row => {
    const snap = snapshots.get(String(row.symbol || '').toUpperCase());
    const values = (snap?.bars || []).map(bar => numOrNull(bar.close)).filter(v => v !== null);
    const pct = scorePct(row.activity_score);
    const ringPctNum = pct * 100;
    // Mirror the detail-score-ring tone logic: only apply a tone class when
    // we actually have a score; otherwise leave the ring toneless so the
    // default accent track shows instead of painting missing data red.
    const hasScore = row.activity_score !== null && row.activity_score !== undefined && Number.isFinite(Number(row.activity_score));
    const ringTone = hasScore ? (ringPctNum >= 70 ? 'good' : (ringPctNum >= 40 ? 'warn' : 'bad')) : '';
    const bias = String(row.directional_bias || '').toUpperCase();
    const tone = bias === 'SHORT' ? 'tone-short' : (bias === 'LONG' ? 'tone-long' : 'tone-neutral');
    const isActive = appState.selectedSymbol === String(row.symbol || '').toUpperCase();
    const warmup = snap?.warmup || null;
    const candidateSub = `Rank #${safe(row.rank)} · ${escapeHtml(row.directional_bias || 'neutral')}${warmup ? ` · ${escapeHtml(warmupLabel(warmup))}` : ''}`;
    // Live-first display: prefer the streamed Schwab quote on the symbol's
    // snapshot; fall back to the screener-row values only when the live
    // quote is missing. Screener values are 60s-stale; live quote refreshes
    // ~6s. This keeps candidate display in sync with the watchlist + focus
    // card (which already follow this pattern). Screener data still drives
    // the activity_score / directional_bias / universe filtering above —
    // only the cosmetic Day%/Price/Volume readouts go live-first.
    const liveChange = numOrNull(snap?.quote?.percent_change) ?? numOrNull(row.change) ?? numOrNull(row.change_from_open);
    const liveVolume = numOrNull(snap?.quote?.total_volume) ?? numOrNull(row.volume);
    const liveLast   = numOrNull(snap?.quote?.last) ?? numOrNull(row.close);
    const bottomMeta = `Vol ${fmtCompact(liveVolume)}`;
    return `<div class="candidate-tile ${tone} ${isActive ? 'active' : ''}" data-symbol="${escapeHtml(row.symbol)}">
      <div class="candidate-top">
        <div>
          <div class="candidate-name">${escapeHtml(row.symbol)}</div>
          <div class="candidate-sub">${candidateSub}</div>
        </div>
        ${iconForState(snap?.support_resistance?.trend_state, snap?.support_resistance?.trend, 'Trend')}
      </div>
      <div class="candidate-score">
        <div>
          <div class="tiny-label">Day % / Price</div>
          <div class="score ${pnlClass(liveChange)}">${fmtPct(liveChange)} · ${fmtNum(liveLast, 2)}</div>
        </div>
        <div class="score-ring ${ringTone}" style="--pct:${ringPctNum.toFixed(1)}%;"><span>${Math.round(ringPctNum)}</span></div>
      </div>
      <div class="sparkline-wrap">${sparklineSVG(values, tone === 'tone-short' ? 'tone-bad' : 'tone-good')}</div>
      <div class="card-bottom"><div class="mini-meta">${bottomMeta}</div>${structureEventChip(snap?.support_resistance?.structure_event || '—')}</div>
    </div>`;
  }).join('') : `<div class="empty-state">No candidate data yet.</div>`;
  const target = document.getElementById('candidate-grid');
  target.innerHTML = html;
  target.querySelectorAll('.candidate-tile[data-symbol]').forEach(card => card.addEventListener('click', () => setSelectedSymbol(card.dataset.symbol)));
}

function renderTopbar(data) {
  const perf = data?.performance || {};
  const rawStatus = String(data?.status || 'idle').toLowerCase();
  const botActive = !!(data?.management_active || data?.screening_active || data?.streaming_active || data?.position_monitoring_active);
  const status = rawStatus === 'running' && !botActive ? 'idle' : rawStatus;
  const statusWrap = document.getElementById('status-badge-wrap');
  const dayPnlEl = document.getElementById('metric-daypnl');
  const pfEl = document.getElementById('metric-pf');
  const netLiqLabelEl = document.getElementById('kpi-netliq-label');
  const tradesEl = document.getElementById('metric-trades');
  const wlEl = document.getElementById('metric-wl');
  const winRateEl = document.getElementById('metric-winrate');
  const apiCpmEl = document.getElementById('metric-api-cpm');
  const updatedEl = document.getElementById('metric-updated');
  const warmupEl = document.getElementById('metric-warmup');
  const sublineEl = document.getElementById('top-subline');
  if (statusWrap) statusWrap.innerHTML = `${statusBadge(status)}${modeBadge(!!data?.dry_run)}`;
  if (netLiqLabelEl) netLiqLabelEl.textContent = safe(data?.tracked_capital_label) || (data?.dry_run ? 'Net Liq' : 'Allocated Capital');
  if (dayPnlEl) dayPnlEl.innerHTML = `<span class="${pnlClass((perf.total_equity || 0) - (perf.starting_equity || 0))}">${fmtMoney((perf.total_equity || 0) - (perf.starting_equity || 0))}</span>`;
  if (pfEl) pfEl.textContent = fmtNum(perf.profit_factor, 2);
  const openPositions = Array.isArray(perf.positions) ? perf.positions.length : (Number(perf.open_positions) || 0);
  const totalTrades = Number(perf.total_trades);
  if (tradesEl) tradesEl.textContent = fmtInteger(Number.isFinite(totalTrades) ? totalTrades : ((Number(perf.closed_trades) || 0) + openPositions));
  if (wlEl) wlEl.textContent = `${fmtInteger(perf.wins ?? 0)} / ${fmtInteger(perf.losses ?? 0)}`;
  if (winRateEl) winRateEl.textContent = perf.win_rate == null ? '—' : fmtPctFromRatio(perf.win_rate);
  if (apiCpmEl) apiCpmEl.textContent = fmtNum(data?.api_usage?.calls_per_minute_5m, 1);
  if (updatedEl) updatedEl.textContent = safe(data?.last_update).replace('T', ' ').slice(0, 19);
  const warmup = data?.warmup || {};
  if (warmupEl) warmupEl.textContent = warmup.total ? `${fmtInteger(warmup.ready_count || 0)} / ${fmtInteger(warmup.total || 0)}` : '—';
  if (sublineEl) {
    const blocked = Number(warmup.blocked_count || 0);
    const warmupText = warmup.total ? `ready ${fmtInteger(warmup.ready_count || 0)}/${fmtInteger(warmup.total || 0)}${blocked ? ` · loading ${fmtInteger(blocked)}` : ''}` : 'ready —';
    sublineEl.textContent = `${safe(data?.strategy)} · ${safe(data?.message)} · ${warmupText} · watchlist ${safe(data?.active_watchlist?.length || 0)}`;
  }
}

function renderKpiAndGauges(data) {
  const perf = data?.performance || {};
  const positions = Array.isArray(perf.positions) ? perf.positions : [];
  const totalEquity = numOrNull(perf.total_equity) || 0;
  const starting = numOrNull(perf.starting_equity) || 0;
  const grossExposure = numOrNull(perf.gross_market_value) ?? positions.reduce((acc, pos) => acc + Math.abs(numOrNull(pos?.market_value) || 0), 0);
  const grossMaxRisk = numOrNull(perf.gross_max_risk) ?? positions.reduce((acc, pos) => acc + Math.abs(numOrNull(pos?.max_risk) || 0), 0);
  // ``Pct`` (clamped 0-100) drives the ring's visual fill; ``PctTrue``
  // (uncapped) drives the text readout so over-leverage (e.g. 128% on a
  // long+short portfolio) is honestly visible instead of pinned to 100%.
  // ``warn`` tone fires when the ratio exceeds 100% so the ring colors
  // up as an alert.
  const exposurePctTrue = totalEquity > 0 ? (grossExposure / totalEquity) * 100 : 0;
  const riskPctTrue = totalEquity > 0 ? (grossMaxRisk / totalEquity) * 100 : 0;
  const ddPctTrue = totalEquity > 0 ? ((numOrNull(perf.max_drawdown) || numOrNull(perf.drawdown) || 0) / totalEquity) * 100 : 0;
  const exposurePct = clamp(exposurePctTrue, 0, 100);
  const riskPct = clamp(riskPctTrue, 0, 100);
  const ddPct = clamp(ddPctTrue, 0, 100);
  const dayPnl = totalEquity - starting;

  document.getElementById('kpi-netliq').textContent = fmtMoney(totalEquity);
  document.getElementById('kpi-realized').innerHTML = `<span class="${pnlClass(perf.realized_pnl)}">${fmtMoney(perf.realized_pnl)}</span>`;
  document.getElementById('kpi-unrealized').innerHTML = `<span class="${pnlClass(perf.unrealized_pnl)}">${fmtMoney(perf.unrealized_pnl)}</span>`;
  const drawdownTone = numOrNull(perf.drawdown) ? 'warn' : '';
  document.getElementById('kpi-drawdown').innerHTML = `<span class="${drawdownTone}">${fmtMoney(perf.drawdown)}</span>`;
  const winrateEl = document.getElementById('kpi-winrate');
  if (winrateEl) winrateEl.textContent = perf.win_rate == null ? '—' : fmtPctFromRatio(perf.win_rate);
  document.getElementById('kpi-meta').textContent = `Day PnL ${fmtMoney(dayPnl)} · cash ${fmtMoney(perf.cash)}`;

  // Day change pill: percent change from starting equity, color-coded.
  const chgEl = document.getElementById('kpi-day-chg');
  const chgText = document.getElementById('kpi-day-chg-text');
  if (chgEl && chgText) {
    const dayPct = starting > 0 ? (dayPnl / starting) * 100 : 0;
    const tone = dayPnl > 0 ? 'good' : (dayPnl < 0 ? 'bad' : 'neutral');
    const arrow = dayPnl > 0 ? '▲' : (dayPnl < 0 ? '▼' : '—');
    chgEl.className = `kpi-hero-chg ${tone}`;
    // Defensive null check on the .arrow child — element should always
    // be present in dashboard.html (line 226), but guard against mid-
    // render DOM state or layout refactors that could remove the class.
    // Mirrors mobile.js's pattern (mobile.js:142-143).
    const arrowEl = chgEl.querySelector('.arrow');
    if (arrowEl) arrowEl.textContent = arrow;
    chgText.textContent = starting > 0 ? `${fmtPct(dayPct, 2)} today` : '— today';
  }

  const kpiSpark = document.getElementById('kpi-spark');
  if (kpiSpark) {
    const equityValues = (Array.isArray(perf.equity_curve) ? perf.equity_curve : [])
      .map(point => numOrNull(point?.equity))
      .filter(v => v !== null);
    if (equityValues.length < 2) {
      // Bot just started or no equity points yet — let :empty CSS rule collapse the strip.
      kpiSpark.innerHTML = '';
    } else {
      const first = equityValues[0];
      const last = equityValues[equityValues.length - 1];
      const tone = last > first ? 'tone-good' : (last < first ? 'tone-bad' : 'tone-neutral');
      kpiSpark.innerHTML = sparklineSVG(equityValues, tone);
    }
  }

  const exposureRing = document.getElementById('gauge-exposure-ring');
  const winRing = document.getElementById('gauge-win-ring');
  const ddRing = document.getElementById('gauge-dd-ring');
  // Defensive null checks — gauge ring elements exist in dashboard.html
  // (lines 244, 249, 254) but a hot reload that interrupts JS before
  // DOM is fully constructed, or a theme refactor that swaps the IDs,
  // would null-deref the style.setProperty calls and break the entire
  // KPI render. Mirrors mobile.js's pattern (mobile.js:171-177).
  if (exposureRing) exposureRing.style.setProperty('--pct', `${exposurePct}%`);
  if (winRing) winRing.style.setProperty('--pct', `${riskPct}%`);
  if (ddRing) ddRing.style.setProperty('--pct', `${ddPct}%`);
  // Warn tone when over 100% — signals over-leverage (mixed long/short
  // positions inflate gross_market_value without inflating net liq).
  if (exposureRing) exposureRing.className = `gauge-ring${exposurePctTrue > 100 ? ' warn' : ''}`;
  // Show true (unclamped) % in the text so 128% reads as "128%" instead
  // of "100%". Ring still caps visually at 100% fill — the warn tone
  // is the over-100% signal.
  document.getElementById('gauge-exposure-text').textContent = fmtPctSmart(exposurePctTrue);
  document.getElementById('gauge-win-text').textContent = fmtPctSmart(riskPctTrue);
  document.getElementById('gauge-dd-text').textContent = fmtPctSmart(ddPctTrue);

  // Dollar values shown under each gauge ring. Tight currency format
  // (no decimals) so they fit in the narrow gauge-card column.
  const fmtGauge = (v) => {
    const n = numOrNull(v);
    if (n === null) return '—';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
  };
  const ddDollars = numOrNull(perf.max_drawdown) || numOrNull(perf.drawdown) || 0;
  document.getElementById('gauge-exposure-value').textContent = fmtGauge(grossExposure);
  document.getElementById('gauge-win-value').textContent = fmtGauge(grossMaxRisk);
  document.getElementById('gauge-dd-value').textContent = fmtGauge(ddDollars);
}

function renderPositions(data) {
  const perf = data?.performance || {};
  const positions = perf.positions || [];
  const exchangeMap = data?.symbol_exchanges || {};
  document.getElementById('positions-meta').textContent = `${positions.length} open positions`;
  const html = positions.length ? positions.map(pos => {
    const baseSymbol = String(pos.underlying || pos.symbol || '').toUpperCase();
    const active = appState.selectedSymbol === baseSymbol;
    const tone = String(pos.side || '').toUpperCase() === 'SHORT' ? 'tone-short' : 'tone-long';
    const rr = numOrNull(pos.max_reward) && numOrNull(pos.max_risk) ? (Number(pos.max_reward) / Math.max(Number(pos.max_risk), 0.0001)) : null;
    const rangeMarkup = positionRangeMarkup(pos);
    return `<div class="position-card ${tone} ${active ? 'active' : ''}" data-symbol="${escapeHtml(baseSymbol)}">
      <div class="position-top">
        <div>
          <div class="position-name">${escapeHtml(baseSymbol)}</div>
          <div class="position-sub">${escapeHtml(fmtSide(pos))} · ${escapeHtml(pos.asset_type || '—')} · Qty ${escapeHtml(pos.qty)}</div>
        </div>
        <div class="price-stack">
          <div class="price-main ${pnlClass(pos.unrealized_pnl)}">${fmtMoney(pos.unrealized_pnl)}</div>
          <div class="price-change ${pnlClass(pos.return_pct)}">${fmtPct(pos.return_pct)}</div>
        </div>
      </div>
      <div class="position-stats">
        <div class="tiny-kv"><div class="tiny-label">Entry</div><div class="v">${fmtNum(pos.entry_price, 2)}</div></div>
        <div class="tiny-kv"><div class="tiny-label">Last</div><div class="v">${fmtNum(pos.last_price, 2)}</div></div>
        <div class="tiny-kv"><div class="tiny-label">R/R</div><div class="v">${fmtNum(rr, 2)}</div></div>
      </div>
      ${rangeMarkup}
    </div>`;
  }).join('') : `<div class="empty-state">No open positions right now.</div>`;
  const target = document.getElementById('positions-cards');
  target.innerHTML = html;
  target.querySelectorAll('.position-card[data-symbol]').forEach(card => card.addEventListener('click', () => setSelectedSymbol(card.dataset.symbol)));
}

function latestBar(snapshot) {
  const bars = currentChartBars(snapshot);
  return bars.length ? bars[bars.length - 1] : null;
}

function renderSelectedSymbol() {
  const data = appState.data;
  const map = activeSnapshotMap(data);
  const snapshot = map.get(appState.selectedSymbol) || null;
  const exchangeMap = data?.symbol_exchanges || {};
  if (!snapshot) {
    document.getElementById('selected-symbol').textContent = '—';
    document.getElementById('selected-description').textContent = 'No symbol selected.';
    document.getElementById('selected-trend-icon').innerHTML = iconForState('neutral', null, 'Trend');
    document.getElementById('selected-structure-icon').innerHTML = iconForState('neutral', null, 'Structure');
    document.getElementById('selected-price').className = 'tiny-chip tone-neutral';
    document.getElementById('selected-price').textContent = 'Last —';
    document.getElementById('selected-change').className = 'tiny-chip tone-neutral';
    document.getElementById('selected-change').textContent = 'Change —';
    // Defensive null check — selected-spread is queried+guarded later
    // in the populated-snapshot path, mirror the safety here.
    const __spreadEarly = document.getElementById('selected-spread');
    if (__spreadEarly) __spreadEarly.classList.add('hidden');
    document.getElementById('selected-volume').textContent = 'Vol —';
    renderChartTimeframeToggle(data);
    drawSelectedChart(null);
    return;
  }

  const q = snapshot.quote || {};
  const sr = snapshot.support_resistance || {};
  const cand = snapshot.candidate || {};
  const pos = snapshot.position || {};
  const bar = latestBar(snapshot) || {};
  const nearestSupport = positiveOrNull(sr.nearest_support);
  const nearestResistance = positiveOrNull(sr.nearest_resistance);
  const supportDistancePct = numOrNull(snapshot?.chart?.levels?.support_distance_pct ?? sr.support_distance_pct);
  const resistanceDistancePct = numOrNull(snapshot?.chart?.levels?.resistance_distance_pct ?? sr.resistance_distance_pct);
  const spread = numOrNull(q.ask) !== null && numOrNull(q.bid) !== null ? Number(q.ask) - Number(q.bid) : null;
  const rgPct = rangePct(q.last ?? bar.close ?? sr.price, nearestSupport, nearestResistance);
  const extension = numOrNull(bar.vwap) !== null && numOrNull(q.last ?? bar.close) !== null && Number(bar.vwap) !== 0
    ? Math.abs(((Number(q.last ?? bar.close) - Number(bar.vwap)) / Number(bar.vwap)) * 100)
    : null;

  document.getElementById('selected-symbol').textContent = snapshot.symbol;
  const decision = entryDecisionForSnapshot(snapshot);
  // Full label (used in scoreSub below) carries the parameter detail;
  // compact label (used in focus-meta next to the symbol name) drops it
  // so long ETF-options skip reasons don't push the live-data chips off
  // the right edge.
  const decisionLabel = entryDecisionLabel(decision);
  const decisionLabelCompact = entryDecisionLabelCompact(decision);
  const warmup = snapshot.warmup || null;
  const selectedDescriptionBase = snapshot.description || `${safe(cand.directional_bias || pos.side || sr.regime_hint || 'watchlist')} · ${safe(data?.strategy)}`;
  const selectedDescription = [selectedDescriptionBase, (!warmup || warmup.ready) ? '' : warmupLabel(warmup), decisionLabelCompact].filter(Boolean).join(' · ');
  document.getElementById('selected-description').textContent = selectedDescription || selectedDescriptionBase;
  document.getElementById('selected-trend-icon').innerHTML = iconForState(sr.trend_state, sr.trend, 'Trend');
  document.getElementById('selected-structure-icon').innerHTML = iconForState(sr.structure_bias, sr.structure_bias, 'Structure');
  const selectedLast = numOrNull(q.last ?? bar.close ?? sr.price);
  const selectedClose = numOrNull(q.close ?? sr.price);
  const selectedNetChange = numOrNull(q.net_change) ?? ((selectedLast !== null && selectedClose !== null) ? (selectedLast - selectedClose) : null);
  document.getElementById('selected-price').className = `tiny-chip ${pnlTone(selectedNetChange)}`;
  document.getElementById('selected-price').textContent = `Last ${fmtNum(selectedLast, 2)}`;
  const selectedChange = numOrNull(q.percent_change) ?? numOrNull(cand.change) ?? numOrNull(cand.change_from_open);
  document.getElementById('selected-change').className = `tiny-chip ${pnlClass(selectedChange) === 'good' ? 'tone-good' : (pnlClass(selectedChange) === 'bad' ? 'tone-bad' : 'tone-neutral')}`;
  document.getElementById('selected-change').textContent = `Change ${fmtPct(selectedChange)}`;
  // Spread pill stays visible across renders to match the sibling pills
  // (selected-price, selected-change, selected-volume) which always show
  // their `—` placeholder. Toggling `.hidden` between renders caused the
  // pill to flicker on/off whenever ask/bid went transiently stale
  // between stream ticks.
  const spreadEl = document.getElementById('selected-spread');
  spreadEl.classList.remove('hidden');
  spreadEl.textContent = (spread !== null && Number.isFinite(spread) && spread > 0)
    ? `Spread ${fmtNum(spread, 3)}`
    : 'Spread —';
  document.getElementById('selected-volume').textContent = `Vol ${fmtCompact(q.total_volume)}`;
  renderChartTimeframeToggle(data);
  const selectedTvMeta = tradingViewSymbolMeta(snapshot.symbol, exchangeMap, snapshot.exchange);
  document.getElementById('selected-link').href = `https://www.tradingview.com/symbols/${encodeURIComponent(selectedTvMeta.exchange || 'NASDAQ')}-${encodeURIComponent(selectedTvMeta.normalizedSymbol || selectedTvMeta.rawSymbol)}/`;

  const strip = [
    stateChip(sr.state || 'neutral'),
    structureEventChip(sr.structure_event || '—'),
    tinyChip(`Trend ${safe(sr.trend || sr.trend_state || 'neutral')}`, pnlTone(String(sr.trend_state || '').toLowerCase().includes('bear') ? -1 : (String(sr.trend_state || '').toLowerCase().includes('bull') ? 1 : 0))),
    tinyChip(`Structure ${safe(sr.structure_bias || 'neutral')}`, pnlTone(String(sr.structure_bias || '').toLowerCase().includes('bear') ? -1 : (String(sr.structure_bias || '').toLowerCase().includes('bull') ? 1 : 0))),
    tinyChip(`Bias ${safe(cand.directional_bias || pos.side || 'neutral')}`, pnlTone(String(cand.directional_bias || pos.side || '').toUpperCase() === 'SHORT' ? -1 : (String(cand.directional_bias || pos.side || '').toUpperCase() === 'LONG' ? 1 : 0))),
    warmupChip(warmup),
  ].filter(Boolean);
  document.getElementById('selected-structure-strip').innerHTML = strip.join('');

  const levelStrip = [];
  if (nearestSupport !== null) levelStrip.push(`<span class="sr-chip support">S ${fmtNum(nearestSupport, 2)}</span>`);
  if (nearestResistance !== null) levelStrip.push(`<span class="sr-chip resistance">R ${fmtNum(nearestResistance, 2)}</span>`);
  levelStrip.push(tinyChip(`Support Δ ${fmtPctFromRatio(nearestSupport === null ? null : supportDistancePct)}`, 'tone-neutral'));
  levelStrip.push(tinyChip(`Res Δ ${fmtPctFromRatio(nearestResistance === null ? null : resistanceDistancePct)}`, 'tone-neutral'));
  // Intentionally keep the selected-level strip focused on the generic S/R ladder and distance chips.
  // Key-level zones remain visible on the chart itself, but we do not duplicate them here as extra chips.
  if (!levelStrip.length) levelStrip.push(tinyChip('S/R unavailable', 'tone-neutral'));
  document.getElementById('selected-level-strip').innerHTML = levelStrip.join('');

  const scoreLabelEl = document.getElementById('detail-score-label');
  const scoreValue = numOrNull(cand.activity_score);
  const changeValue = numOrNull(q.percent_change);
  let scoreLabel = 'Activity Score';
  let scoreText = '—';
  let scoreBasis = scoreValue;
  const liveVolume = numOrNull(q.total_volume);
  let scoreSub = cand.rank ? `Strategy screener rank #${cand.rank}${liveVolume !== null ? ` · live volume ${fmtCompact(liveVolume)}` : ''}` : `Live quote and structure snapshot`;
  if (decisionLabel) scoreSub = `${scoreSub} · ${decisionLabel}`;
  if (scoreValue !== null) {
    scoreText = fmtNum(scoreValue, 1);
  } else if (changeValue !== null) {
    scoreLabel = 'Day Change';
    scoreText = fmtPct(changeValue, 1);
    scoreBasis = changeValue;
    scoreSub = decisionLabel ? `No candidate activity score available; showing current day change. · ${decisionLabel}` : 'No candidate activity score available; showing current day change.';
  } else {
    scoreLabel = 'Activity Score';
    scoreSub = decisionLabel ? `No candidate activity score available for this symbol. · ${decisionLabel}` : 'No candidate activity score available for this symbol.';
  }
  scoreLabelEl.textContent = scoreLabel;
  document.getElementById('detail-score').textContent = scoreText;
  const ringEl = document.getElementById('detail-score-ring');
  const ringPct = scorePct(scoreBasis) * 100;
  ringEl.style.setProperty('--pct', `${ringPct.toFixed(1)}%`);
  // Tone class: clear all three first, then apply one based on the %.
  // When no score data is available (scoreBasis is null), leave the ring
  // toneless so the default accent track shows — avoids painting a missing
  // value red just because scorePct's fallback is 18%.
  ringEl.classList.remove('good', 'warn', 'bad');
  if (scoreBasis !== null && scoreBasis !== undefined && Number.isFinite(Number(scoreBasis))) {
    ringEl.classList.add(ringPct >= 70 ? 'good' : (ringPct >= 40 ? 'warn' : 'bad'));
  }
  ringEl.innerHTML = `<span>${Math.round(ringPct)}</span>`;
  document.getElementById('detail-score-sub').textContent = scoreSub;
  document.getElementById('detail-bias').textContent = safe(cand.directional_bias || pos.side || 'neutral');
  document.getElementById('detail-state').textContent = safe(sr.state || 'neutral').replace(/_/g, ' ');
  document.getElementById('detail-regime').textContent = safe(sr.regime_hint || '—');
  document.getElementById('detail-support').textContent = fmtNum(nearestSupport, 2);
  document.getElementById('detail-resistance').textContent = fmtNum(nearestResistance, 2);
  document.getElementById('detail-vwap').textContent = fmtNum(bar.vwap, 2);
  document.getElementById('detail-bias-score').textContent = fmtNum(sr.bias_score, 2);
  // EMA labels are dynamic — chart-endpoint payload's ema_fast_span /
  // ema_slow_span tell us whether we're rendering the strategy's HTF EMAs
  // (e.g. 34/200 for peer_confirmed_key_levels in HTF mode) or the default
  // 9/20. The spans live on appState.expandedChart / compactChart (captured
  // when /api/chart payloads arrive); snapshot.chart is the levels meta
  // payload built in dashboard_cache.py:1086 and never carries them.
  const activeEmaSource = appState.mainPanelExpanded ? appState.expandedChart : appState.compactChart;
  const emaFastSpan = Math.max(1, Number(activeEmaSource?.emaFastSpan) || 9);
  const emaSlowSpan = Math.max(1, Number(activeEmaSource?.emaSlowSpan) || 20);
  const emaFastLabel = `EMA${emaFastSpan}`;
  const emaSlowLabel = `EMA${emaSlowSpan}`;
  document.getElementById('detail-ema-fast-label').textContent = emaFastLabel;
  document.getElementById('detail-ema-slow-label').textContent = emaSlowLabel;
  document.getElementById('detail-ema9').textContent = fmtNum(bar.ema9, 2);
  document.getElementById('detail-ema20').textContent = fmtNum(bar.ema20, 2);
  const bidValue = numOrNull(q.bid);
  const askValue = numOrNull(q.ask);
  const midValue = numOrNull(q.mid);
  const markValue = numOrNull(q.mark);
  const lastValue = numOrNull(q.last ?? bar.close ?? sr.price);
  const hasBidAsk = bidValue !== null && askValue !== null && bidValue > 0 && askValue > 0;
  document.getElementById('detail-quote-left-label').textContent = hasBidAsk ? 'Bid' : 'Last';
  document.getElementById('detail-quote-right-label').textContent = hasBidAsk ? 'Ask' : 'Mark';
  document.getElementById('detail-bid').textContent = hasBidAsk ? fmtNum(bidValue, 2) : fmtNum(lastValue, 2);
  document.getElementById('detail-ask').textContent = hasBidAsk ? fmtNum(askValue, 2) : fmtNum(markValue ?? midValue ?? lastValue, 2);
  document.getElementById('detail-range-fill').style.width = `${rgPct === null ? 0 : rgPct}%`;
  document.getElementById('detail-range-text').textContent = rgPct === null ? 'Range position unavailable.' : `Price sits at ${fmtNum(rgPct, 1)}% of the active S/R range.`;
  document.getElementById('detail-momentum-fill').style.width = `${extension === null ? 0 : clamp(extension * 12, 0, 100)}%`;
  document.getElementById('detail-momentum-text').textContent = extension === null ? 'VWAP extension unavailable.' : `VWAP extension ${fmtPct(extension, 2)} · ${emaFastLabel} ${fmtNum(bar.ema9, 2)} / ${emaSlowLabel} ${fmtNum(bar.ema20, 2)}.`;

  drawSelectedChart(snapshot);
}

function drawSelectedChart(snapshot) {
  const canvas = document.getElementById('market-chart');
  const legend = document.getElementById('chart-legend');
  const tooltip = document.getElementById('chart-tooltip');
  const loadingOverlay = document.getElementById('chart-loading');
  const wrap = canvas?.parentElement || document.getElementById('chart-wrap') || document.querySelector('.chart-wrap') || canvas;
  if (tooltip && tooltip.parentElement !== document.body) {
    document.body.appendChild(tooltip);
  }
  let lastTooltipLeft = null;
  let lastTooltipTop = null;
  // Hoist hover state to the top of drawSelectedChart so renderEmpty
  // (defined below at ~line 1763) can read/write them on early-return
  // paths. Previously declared further down — caused a TDZ
  // ReferenceError when the chart payload had no bars and renderEmpty
  // ran before the original `let` line was reached.
  let hoverFrameRequest = 0;
  let pendingHoverState = null;
  const chartCfg = currentChartProfile(appState.data);
  const isExpandedView = !!appState.mainPanelExpanded;
  const activeViewMode = isExpandedView ? 'expanded' : 'compact';
  const activeConfiguredMaxBars = Math.max(1, Number(chartCfg?.max_bars) || chartMaxBarsForMode(activeViewMode, appState.data));
  const chartTimeframeMode = isExpandedView ? expandedChartTimeframeMode() : compactChartTimeframeMode(appState.data);
  const isLtfChart = chartTimeframeMode === 'ltf';
  const isHtfChart = chartTimeframeMode === 'htf';
  const show = (key, fallback = true) => {
    if (isLtfChart && (key === 'show_htf_fair_value_gaps' || key === 'show_htf_order_blocks')) {
      return false;
    }
    if (isHtfChart && (
      key === 'show_ltf_fair_value_gaps'
      || key === 'show_ltf_order_blocks'
    )) {
      return false;
    }
    return chartCfg[key] === undefined ? fallback : !!chartCfg[key];
  };
  const ratio = Math.max(window.devicePixelRatio || 1, 1);
  const width = Math.max(640, Math.floor(wrap.clientWidth));
  const height = Math.max(340, Math.floor(wrap.clientHeight || 360));
  canvas.width = Math.floor(width * ratio);
  canvas.height = Math.floor(height * ratio);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  const ctx = canvas.getContext('2d');
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  legend.innerHTML = '';

  function setChartLoading(active, message = 'Loading chart…') {
    if (!loadingOverlay) return;
    const textEl = loadingOverlay.querySelector('.chart-loading-text');
    if (textEl) textEl.textContent = message;
    loadingOverlay.classList.toggle('active', !!active);
    loadingOverlay.setAttribute('aria-hidden', active ? 'false' : 'true');
  }

  function hideTooltip() {
    if (!tooltip) return;
    tooltip.classList.remove('active');
    tooltip.innerHTML = '';
    lastTooltipLeft = null;
    lastTooltipTop = null;
  }

  function renderEmpty(message, loading = false) {
    ctx.clearRect(0, 0, width, height);
    setChartLoading(loading, message || 'Loading chart…');
    if (!loading) {
      ctx.fillStyle = '#92a0bf';
      ctx.font = '14px sans-serif';
      ctx.fillText(message, 22, 30);
    }
    // Cancel any pending hover-RAF queued by the previous chart's
    // pointer handler. Without this, the queued RAF fires after we've
    // cleared the canvas and detached handlers, calling the stale
    // closure's paint/updateTooltip and drawing ghost data over the
    // new chart's blank state. Mirrors clearPointerActivity but runs
    // even when the cancel didn't come from a leave gesture.
    if (hoverFrameRequest) {
      window.cancelAnimationFrame(hoverFrameRequest);
      hoverFrameRequest = 0;
    }
    pendingHoverState = null;
    hideTooltip();
    // Detach pointer/mouse handlers so a stale chart's idx mapping
    // doesn't fire while the new chart's bars are still loading.
    // hideTooltip stays wired on leave so dragging off the canvas
    // dismisses any lingering tooltip during the transition.
    canvas.onpointermove = null;
    canvas.onpointerdown = null;
    canvas.onpointerleave = hideTooltip;
    canvas.onpointercancel = hideTooltip;
  }

  function prettyLabel(value) {
    // 2026-05-21: the second regex was previously /\\b\\w/g — a regex
    // literal where the double backslashes mean LITERAL backslash + 'b'
    // and LITERAL backslash + 'w', not the word-boundary + word-character
    // pair the original intent required. As a result every prettyLabel
    // call returned its input lowercased (e.g. tooltip state read
    // "bullish trend" instead of "Bullish Trend"). Single backslashes
    // here are the correct regex escapes for \b and \w.
    return safe(value).replace(/_/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
  }

  function lineValueAt(line, absIndex) {
    if (!line || numOrNull(line.slope) === null || numOrNull(line.intercept) === null) return null;
    return Number(line.slope) * Number(absIndex) + Number(line.intercept);
  }

  function nearestIndexForTs(ts, barsInput) {
    if (!ts || !barsInput.length) return null;
    const target = Date.parse(ts);
    if (!Number.isFinite(target)) return null;
    let bestIdx = null;
    let bestGap = Number.POSITIVE_INFINITY;
    barsInput.forEach((bar, idx) => {
      const barTs = Date.parse(bar.ts);
      if (!Number.isFinite(barTs)) return;
      const gap = Math.abs(barTs - target);
      if (gap < bestGap) {
        bestGap = gap;
        bestIdx = idx;
      }
    });
    return bestIdx;
  }

  function uniqPatternList(values) {
    const out = [];
    const seen = new Set();
    (Array.isArray(values) ? values : []).forEach(value => {
      const token = String(value || '').trim();
      if (!token) return;
      const key = token.toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      out.push(token);
    });
    return out;
  }

  function tagHtml(values, toneClass = '') {
    const items = uniqPatternList(values).slice(0, 8);
    if (!items.length) return '<span class="tt-tag">—</span>';
    return items.map(item => `<span class="tt-tag ${toneClass}">${escapeHtml(prettyLabel(item))}</span>`).join('');
  }

  function signedBiasToken(value) {
    const token = String(value || '').toLowerCase();
    if (!token) return 0;
    if (token.includes('bull') || token.includes('up') || token.includes('breakout') || token.includes('support_hold')) return 1;
    if (token.includes('bear') || token.includes('down') || token.includes('breakdown') || token.includes('resistance')) return -1;
    return 0;
  }

  function deriveCandleFallback(idx) {
    const start = Math.max(0, Number(idx || 0) - 2);
    const slice = bars.slice(start, Number(idx || 0) + 1);
    let score = 0;
    let bullishCount = 0;
    let bearishCount = 0;
    const bullish = [];
    const bearish = [];
    slice.forEach(item => {
      const open = numOrNull(item.open);
      const high = numOrNull(item.high);
      const low = numOrNull(item.low);
      const close = numOrNull(item.close);
      if ([open, high, low, close].some(v => v === null)) return;
      const range = Math.max(Number(high) - Number(low), 0.000001);
      const bodyScore = (Number(close) - Number(open)) / range;
      score += bodyScore;
      if (bodyScore > 0.15) bullishCount += 1;
      if (bodyScore < -0.15) bearishCount += 1;
    });
    if (bullishCount >= 2) bullish.push('bullish_3bar_flow');
    if (bearishCount >= 2) bearish.push('bearish_3bar_flow');
    if (score >= 0.45) bullish.push('positive_body_bias');
    if (score <= -0.45) bearish.push('negative_body_bias');
    let regime = 'neutral';
    if (score >= 0.60 || (bullishCount >= 2 && score > 0.20)) regime = 'bullish';
    else if (score <= -0.60 || (bearishCount >= 2 && score < -0.20)) regime = 'bearish';
    else if (bullishCount > 0 && bearishCount > 0) regime = 'mixed';
    return { score, regime, bullish, bearish };
  }

  function deriveChartFallback(idx) {
    const bar = bars[idx] || {};
    const close = numOrNull(bar.close);
    const ema9 = numOrNull(bar.ema9);
    const ema20 = numOrNull(bar.ema20);
    const vwap = numOrNull(bar.vwap);
    const ret15 = numOrNull(bar.ret15);
    let score = 0;
    const bullish = [];
    const bearish = [];

    if (close !== null && vwap !== null) {
      if (close >= vwap) {
        score += 0.75;
        bullish.push('above_vwap');
      } else {
        score -= 0.75;
        bearish.push('below_vwap');
      }
    }
    if (ema9 !== null && ema20 !== null) {
      if (ema9 >= ema20) {
        score += 0.90;
        bullish.push('ema_stack_bullish');
      } else {
        score -= 0.90;
        bearish.push('ema_stack_bearish');
      }
    }

    // Per-bar bias reads. Only ``dmi_bias`` and ``obv_bias`` are emitted by
    // ``dashboard_bars_from_frame`` per-bar; the other reads (trend_state /
    // structure_bias / anchored_vwap_bias / breakout_above_resistance /
    // breakdown_below_support / near_support / near_resistance) were dead
    // code — those fields live on the snapshot's structure / SR sections,
    // not on individual bars. Cleaned up 2026-05-13 so the heuristic is
    // honest about what it actually reads.
    const dmiBias = signedBiasToken(bar.dmi_bias);
    const obvBias = signedBiasToken(bar.obv_bias);

    if (dmiBias > 0) bullish.push('dmi_bullish');
    if (dmiBias < 0) bearish.push('dmi_bearish');
    if (obvBias > 0) bullish.push('obv_bullish');
    if (obvBias < 0) bearish.push('obv_bearish');

    score += dmiBias * 0.50;
    score += obvBias * 0.35;
    if (ret15 !== null) score += Math.max(-0.50, Math.min(0.50, Number(ret15) * 20));

    let regime = 'neutral';
    if (score >= 1.00) regime = 'bullish';
    else if (score <= -1.00) regime = 'bearish';
    else if (bullish.length && bearish.length) regime = 'mixed';
    return { score, regime, bullish, bearish };
  }

  if (!snapshot || !(snapshot.bars || []).length) {
    setChartLoading(false);
    renderEmpty('No recent chart bars available for the selected symbol yet.');
    return;
  }

  const bars = currentChartBars(snapshot)
    .filter(bar => [bar.open, bar.high, bar.low, bar.close].every(v => numOrNull(v) !== null))
    .map((bar, idx) => ({ ...bar, abs_index: numOrNull(bar.abs_index) ?? idx }))
    .slice(-activeConfiguredMaxBars);
  if (!bars.length) {
    const loadingState = chartLoadingState(snapshot);
    renderEmpty(loadingState.active ? loadingState.message : 'Chart bars are present but could not be rendered.', loadingState.active);
    return;
  }
  setChartLoading(false);

  const sr = snapshot.support_resistance || {};
  const chart = snapshot.chart || {};
  const levels = chart.levels || {};
  const technicals = chart.technicals || {};
  const keyLevelZones = Array.isArray(levels.key_level_zones) ? levels.key_level_zones : [];
  const normalizeDashboardFvgs = (gaps, maxPerDirection = 1) => {
    const source = Array.isArray(gaps) ? gaps : [];
    const kept = [];
    const counts = { bullish: 0, bearish: 0 };
    source.forEach(gap => {
      const direction = String(gap?.direction || '').toLowerCase();
      if (direction !== 'bullish' && direction !== 'bearish') return;
      const lower = numOrNull(gap?.lower);
      const upper = numOrNull(gap?.upper);
      const filledPct = numOrNull(gap?.filled_pct);
      if (lower === null || upper === null || upper <= lower) return;
      if (filledPct !== null && filledPct >= 0.90) return;
      if ((counts[direction] || 0) >= maxPerDirection) return;
      counts[direction] = (counts[direction] || 0) + 1;
      kept.push(gap);
    });
    return kept;
  };
  const visibleAbsStart = Number(bars[0].abs_index || 0);
  const visibleAbsEnd = Number(bars[bars.length - 1].abs_index || (bars.length - 1));
  // 1m FVG/OB anchor_abs_index is computed against the 1m frame. When the
  // chart renders at a non-1m LTF (e.g. peer_confirmed_key_levels uses
  // 5-min trigger candles), the chart's bar abs_index space differs from
  // the 1m anchor space and abs-index filtering rejects valid FVGs/OBs.
  // Use timestamp comparison in that case so 1m micro-structure overlays
  // still render at their correct visual position.
  //
  // Source priority: snapshot.support_resistance.ltf_timeframe is server
  // -emitted truth ("5m" / "1m"). Fall back to the active chart cache's
  // timeframeLabel, then the snapshot.bars-implied 1m default. snapshot.chart
  // is the levels/technicals meta-payload (dashboard_cache.py:1086) and never
  // carries timeframe_minutes — reading from it would always resolve to 1
  // and silently drop LTF FVG/OB overlays for non-1m strategies.
  const chartTimeframeMinutesRaw = (() => {
    const srLabel = String(snapshot?.support_resistance?.ltf_timeframe || '').trim();
    if (srLabel) {
      const parsed = parseInt(srLabel, 10);
      if (Number.isFinite(parsed) && parsed > 0) return parsed;
    }
    const cacheLabel = String(
      (isExpandedView ? appState.expandedChart?.timeframeLabel : appState.compactChart?.timeframeLabel) || ''
    ).trim();
    if (cacheLabel) {
      const parsed = parseInt(cacheLabel, 10);
      if (Number.isFinite(parsed) && parsed > 0) return parsed;
    }
    return 1;
  })();
  const chartTimeframeMinutes = Math.max(1, chartTimeframeMinutesRaw);
  const useAbsIndexForLtf = chartTimeframeMinutes === 1;
  const ltfTimeframeLabel = `${chartTimeframeMinutes}m`;
  const firstBarMillis = Date.parse(bars[0]?.ts || '');
  const lastBarMillis = Date.parse(bars[bars.length - 1]?.ts || '');
  const ltfVisibilityFilter = (item) => {
    const timeframe = String(item?.timeframe || '').trim().toLowerCase();
    if (timeframe !== ltfTimeframeLabel) return false;
    if (useAbsIndexForLtf) {
      const anchorAbsIndex = Number(item?.anchor_abs_index);
      if (Number.isFinite(anchorAbsIndex)) return anchorAbsIndex >= visibleAbsStart && anchorAbsIndex <= visibleAbsEnd;
    }
    const startMillis = Date.parse(item?.first_seen || '');
    if (!Number.isFinite(startMillis)) return false;
    if (Number.isFinite(firstBarMillis) && startMillis < firstBarMillis) return false;
    if (Number.isFinite(lastBarMillis) && startMillis > lastBarMillis) return false;
    return true;
  };
  // HTF FVG/OB items are anything whose timeframe label isn't the LTF label
  // (defensive — items in `levels.htf_*` lists are HTF by design, but the
  // filter sanity-checks against accidentally including LTF items).
  const htfFairValueGaps = isLtfChart ? [] : normalizeDashboardFvgs(levels.htf_fair_value_gaps, 1).filter(gap => {
    const timeframe = String(gap?.timeframe || '').trim().toLowerCase();
    return !!timeframe && timeframe !== ltfTimeframeLabel;
  });
  const ltfFairValueGaps = isHtfChart ? [] : normalizeDashboardFvgs(levels.ltf_fair_value_gaps, 1).filter(ltfVisibilityFilter);
  // Order blocks share the FVG payload shape but render with dashed stroke
  // + minimal fill so they're visually distinguishable from FVGs.
  const htfOrderBlocks = isLtfChart ? [] : normalizeDashboardFvgs(levels.htf_order_blocks, 1).filter(ob => {
    const timeframe = String(ob?.timeframe || '').trim().toLowerCase();
    return !!timeframe && timeframe !== ltfTimeframeLabel;
  });
  const ltfOrderBlocks = isHtfChart ? [] : normalizeDashboardFvgs(levels.ltf_order_blocks, 1).filter(ltfVisibilityFilter);
  // Divergence trendlines: LTF lines render only on LTF chart, HTF lines
  // only on HTF chart. Each line is a {pivot_a, pivot_b, kind, direction,
  // indicator, age_bars, timeframe} payload from DivergenceMatch.to_payload().
  const ltfDivergenceLines = isHtfChart ? [] : (Array.isArray(levels.ltf_divergence_lines) ? levels.ltf_divergence_lines : []);
  const htfDivergenceLines = isLtfChart ? [] : (Array.isArray(levels.htf_divergence_lines) ? levels.htf_divergence_lines : []);
  // Patterns + structure overlay only ever come from /api/chart payloads
  // stored on appState.expandedChart / appState.compactChart. snapshot.chart
  // is the levels/technicals meta-payload built in dashboard_cache.py:1086
  // and never carries `patterns` or `structure_overlay` — so falling back to
  // it would always yield {}. Pick the correct cache for the current view
  // and require a symbol+mode match to avoid showing stale data after a
  // symbol or mode flip.
  const snapshotSymbolUpper = String(snapshot?.symbol || '').toUpperCase();
  const compactCacheMatchesSnapshot = !isExpandedView
    && String(appState.compactChart?.symbol || '').toUpperCase() === snapshotSymbolUpper
    && normalizedExpandedChartTimeframeMode(appState.compactChart?.timeframeMode) === chartTimeframeMode;
  const expandedCacheMatchesSnapshot = isExpandedView
    && String(appState.expandedChart?.symbol || '').toUpperCase() === snapshotSymbolUpper;
  const compactPatterns = compactCacheMatchesSnapshot ? (appState.compactChart.patterns || {}) : {};
  const expandedPatterns = expandedCacheMatchesSnapshot ? (appState.expandedChart.patterns || {}) : {};
  const patterns = Object.keys(expandedPatterns).length
    ? expandedPatterns
    : (Object.keys(compactPatterns).length ? compactPatterns : {});
  const compactStructureOverlay = compactCacheMatchesSnapshot ? (appState.compactChart.structureOverlay || {}) : {};
  const expandedStructureOverlay = expandedCacheMatchesSnapshot ? (appState.expandedChart.structureOverlay || {}) : {};
  const activeStructureOverlay = Object.keys(expandedStructureOverlay).length
    ? expandedStructureOverlay
    : (Object.keys(compactStructureOverlay).length ? compactStructureOverlay : {});
  const positionMarkers = chart.position_markers || {};
  const recentTrades = Array.isArray(chart.recent_trades) ? chart.recent_trades : [];
  const highs = bars.map(bar => Number(bar.high));
  const lows = bars.map(bar => Number(bar.low));

  // Backend tells us which EMA spans the bars carry. In HTF mode the chart
  // values are the strategy's htf_ema_fast/slow (e.g. 34/200 for
  // peer_confirmed_key_levels); in LTF mode they're the default 9/20.
  // The spans live on the chart-endpoint payload (appState.expandedChart /
  // compactChart), NOT on snapshot.chart — `snapshot.chart` is the
  // levels/technicals meta-payload built in dashboard_cache.py:1086 and
  // never carries ema_fast_span/ema_slow_span. Reading from the active
  // chart cache is what makes the HTF legend show EMA34 / EMA200 instead
  // of the LTF default 9 / 20.
  const activeChartCache = isExpandedView ? appState.expandedChart : appState.compactChart;
  const chartEmaFastSpan = Math.max(1, Number(activeChartCache?.emaFastSpan) || 9);
  const chartEmaSlowSpan = Math.max(1, Number(activeChartCache?.emaSlowSpan) || 20);
  const seriesDefs = [];
  if (show('show_moving_averages', true)) {
    seriesDefs.push({ key: 'ema9', label: `EMA${chartEmaFastSpan}`, color: '#44e7ff', width: 2.0 });
    seriesDefs.push({ key: 'ema20', label: `EMA${chartEmaSlowSpan}`, color: '#7b7dff', width: 2.0 });
  }
  if (show('show_vwap', true)) {
    seriesDefs.push({ key: 'vwap', label: 'VWAP', color: '#ffbf3c', width: 2.0 });
  }
  if (show('show_bollinger_bands', false)) {
    seriesDefs.push({ key: 'bb_upper', label: 'BB Upper', color: '#ff4fa3', width: 1.5 });
    seriesDefs.push({ key: 'bb_mid', label: 'BB Mid', color: '#c98cff', width: 1.2 });
    seriesDefs.push({ key: 'bb_lower', label: 'BB Lower', color: '#24d6b2', width: 1.5 });
  }

  const seriesValueMap = new Map();
  seriesDefs.forEach(def => {
    seriesValueMap.set(def.key, bars.map(bar => numOrNull(bar[def.key])));
  });
  const bbUpperValues = seriesValueMap.get('bb_upper') || [];
  const bbLowerValues = seriesValueMap.get('bb_lower') || [];

  const horizontalLines = [];
  const nearestSupport = positiveOrNull(levels.nearest_support ?? sr.nearest_support);
  const nearestResistance = positiveOrNull(levels.nearest_resistance ?? sr.nearest_resistance);
  const supportDistancePct = numOrNull(levels.support_distance_pct ?? sr.support_distance_pct);
  const resistanceDistancePct = numOrNull(levels.resistance_distance_pct ?? sr.resistance_distance_pct);
  if (show('show_support_resistance', true)) {
    if (nearestSupport !== null) horizontalLines.push({ value: nearestSupport, label: 'Support', shortLabel: 'S', color: '#2fdc8c', dash: [8, 6] });
    if (nearestResistance !== null) horizontalLines.push({ value: nearestResistance, label: 'Resistance', shortLabel: 'R', color: '#ff5269', dash: [8, 6] });
  }
  if (show('show_next_support_resistance', true)) {
    const nextSupport = positiveOrNull(levels.next_support);
    const nextResistance = positiveOrNull(levels.next_resistance);
    if (nextSupport !== null) horizontalLines.push({ value: nextSupport, label: 'Next Support', shortLabel: 'S2', color: 'rgba(13, 192, 143, 0.82)', dash: [4, 6] });
    if (nextResistance !== null) horizontalLines.push({ value: nextResistance, label: 'Next Resistance', shortLabel: 'R2', color: 'rgba(255, 82, 105, 0.82)', dash: [4, 6] });
  }
  if (show('show_full_support_resistance_ladder', false)) {
    (levels.supports || []).forEach(value => {
      const v = positiveOrNull(value);
      if (v !== null && (nearestSupport === null || Math.abs(v - nearestSupport) > 1e-9) && (numOrNull(levels.next_support) === null || Math.abs(v - Number(levels.next_support)) > 1e-9)) {
        horizontalLines.push({ value: v, label: 'Support Ladder', shortLabel: 'SUP', color: 'rgba(18, 178, 124, 0.40)', dash: [2, 6], labelMode: 'inline' });
      }
    });
    (levels.resistances || []).forEach(value => {
      const v = positiveOrNull(value);
      if (v !== null && (nearestResistance === null || Math.abs(v - nearestResistance) > 1e-9) && (numOrNull(levels.next_resistance) === null || Math.abs(v - Number(levels.next_resistance)) > 1e-9)) {
        horizontalLines.push({ value: v, label: 'Resistance Ladder', shortLabel: 'RES', color: 'rgba(255, 82, 105, 0.40)', dash: [2, 6], labelMode: 'inline' });
      }
    });
  }
  if (show('show_anchored_vwap', false)) {
    [
      { value: technicals.anchored_vwap_open, label: 'AVWAP Open', shortLabel: 'AVO', color: '#17c8ff' },
      { value: technicals.anchored_vwap_bullish_impulse, label: 'AVWAP Bull', shortLabel: 'AVB', color: '#47db72' },
      { value: technicals.anchored_vwap_bearish_impulse, label: 'AVWAP Bear', shortLabel: 'AVA', color: '#ff5b9a' },
    ].forEach(item => {
      const v = positiveOrNull(item.value);
      if (v !== null) horizontalLines.push({ value: v, label: item.label, shortLabel: item.shortLabel, color: item.color, dash: [3, 5] });
    });
  }
  if (show('show_fib_extensions', false)) {
    [
      { value: technicals.fib_bullish_1272, label: 'Fib 127.2%↑', shortLabel: '127.2%↑', color: '#a76bff' },
      { value: technicals.fib_bullish_1618, label: 'Fib 161.8%↑', shortLabel: '161.8%↑', color: '#6d47ff' },
      { value: technicals.fib_bearish_1272, label: 'Fib 127.2%↓', shortLabel: '127.2%↓', color: '#ffb000' },
      { value: technicals.fib_bearish_1618, label: 'Fib 161.8%↓', shortLabel: '161.8%↓', color: '#ff7a00' },
    ].forEach(item => {
      const v = positiveOrNull(item.value);
      if (v !== null) horizontalLines.push({ value: v, label: item.label, shortLabel: item.shortLabel, color: item.color, dash: [5, 5], labelMode: 'inline' });
    });
  }
  if (show('show_fib_retracements', false)) {
    // Retracement levels: pullback support within a bullish impulse range
    // (drawn from impulse high toward low) and bounce resistance within a
    // bearish impulse range. Same dash style as extensions but slightly
    // muted color tones so the eye can distinguish "extension target"
    // from "retracement pullback" at a glance.
    [
      { value: technicals.fib_bullish_382, label: 'Fib 38.2%↑', shortLabel: '38.2%↑', color: '#7d5cd1' },
      { value: technicals.fib_bullish_500, label: 'Fib 50.0%↑', shortLabel: '50.0%↑', color: '#5a3eb8' },
      { value: technicals.fib_bullish_618, label: 'Fib 61.8%↑', shortLabel: '61.8%↑', color: '#4128a0' },
      { value: technicals.fib_bullish_786, label: 'Fib 78.6%↑', shortLabel: '78.6%↑', color: '#2c1a73' },
      { value: technicals.fib_bearish_382, label: 'Fib 38.2%↓', shortLabel: '38.2%↓', color: '#d99500' },
      { value: technicals.fib_bearish_500, label: 'Fib 50.0%↓', shortLabel: '50.0%↓', color: '#b87a00' },
      { value: technicals.fib_bearish_618, label: 'Fib 61.8%↓', shortLabel: '61.8%↓', color: '#965e00' },
      { value: technicals.fib_bearish_786, label: 'Fib 78.6%↓', shortLabel: '78.6%↓', color: '#6e4400' },
    ].forEach(item => {
      const v = positiveOrNull(item.value);
      if (v !== null) horizontalLines.push({ value: v, label: item.label, shortLabel: item.shortLabel, color: item.color, dash: [3, 6], labelMode: 'inline' });
    });
  }
  // Channels and trendlines are computed against the LTF frame in
  // dashboard_cache.py (build_technical_levels_context fed by tech_frame
  // at _active_ltf_minutes). The line.slope/intercept were fit against
  // LTF abs_index values. On the HTF chart the bars carry HTF abs_index
  // values, so lineValueAt(line, bars[i].abs_index) projects to garbage
  // prices — the line ends up "in empty space" detached from the bars.
  // Gate the rendering to LTF-only (mirrors the divergence-lines
  // isLtfChart/isHtfChart gating at lines 2144-2145).
  const diagonalLines = [];
  if (isLtfChart && show('show_channel', false) && technicals.channel && technicals.channel.valid) {
    const lowerLine = technicals.channel.lower_line || null;
    const midLine = technicals.channel.mid_line || null;
    const upperLine = technicals.channel.upper_line || null;
    if (lowerLine) diagonalLines.push({ line: lowerLine, label: 'Channel Low', color: '#4a9bff', dash: [], width: 1.7, useChannelRange: true });
    if (midLine) diagonalLines.push({ line: midLine, label: 'Channel Mid', color: 'rgba(74, 155, 255, 0.82)', dash: [5, 6], width: 1.2, useChannelRange: true });
    if (upperLine) diagonalLines.push({ line: upperLine, label: 'Channel High', color: '#4a9bff', dash: [], width: 1.7, useChannelRange: true });
  }
  if (isLtfChart && show('show_trendlines', false)) {
    const supportLine = technicals.support_trendline || null;
    const resistanceLine = technicals.resistance_trendline || null;
    if (supportLine) diagonalLines.push({ line: supportLine, label: 'Support TL', color: '#69c779', dash: [10, 4, 2, 4] });
    if (resistanceLine) diagonalLines.push({ line: resistanceLine, label: 'Resistance TL', color: '#d96a78', dash: [10, 4, 2, 4] });
  }

  const markerLines = [];
  if (show('show_trade_markers', true) && positionMarkers) {
    const approxEqual = (left, right) => {
      const a = numOrNull(left);
      const b = numOrNull(right);
      if (a === null || b === null) return false;
      const scale = Math.max(Math.abs(a), Math.abs(b), 1);
      return Math.abs(a - b) <= Math.max(0.0005 * scale, 0.01);
    };
    const pushMarkerLine = (value, label, shortLabel, color, dash) => {
      const numericValue = positiveOrNull(value);
      if (numericValue === null) return;
      // When this marker lands at the same price as a previously-pushed
      // line, MERGE its label into the existing marker instead of
      // dropping it silently. The common case: ``adaptive_breakeven_rr``
      // ratchets the stop up to the entry price, so Stop and Entry
      // overlap — dropping Stop made it look like the position had no
      // stop. Merged form ("Entry / Stop", "E·ST") keeps both readouts
      // visible on one rendered line.
      const existing = markerLines.find(m => approxEqual(m.value, numericValue));
      if (existing) {
        existing.label = `${existing.label} / ${label}`;
        existing.shortLabel = `${existing.shortLabel}·${shortLabel}`;
        return;
      }
      markerLines.push({ value: numericValue, label, shortLabel, color, dash });
    };
    const entryValue = positionMarkers.show_underlying_lines ? positiveOrNull(positionMarkers.entry) : null;
    const stopValue = positionMarkers.show_underlying_lines ? positiveOrNull(positionMarkers.stop) : null;
    const targetValue = positionMarkers.show_underlying_lines ? positiveOrNull(positionMarkers.target) : null;
    // Breakeven is in underlying-price units for both stocks and options, so
    // it's drawn regardless of show_underlying_lines (which only gates stock's
    // entry/stop/target that are stock-price units).
    const breakevenValue = positiveOrNull(positionMarkers.breakeven);
    pushMarkerLine(entryValue, 'Entry', 'E', '#8cf4ff', [3, 3]);
    pushMarkerLine(stopValue, 'Stop', 'ST', '#ff365f', [2, 4]);
    pushMarkerLine(targetValue, 'Target', 'TG', '#7eff64', [2, 4]);
    if (!approxEqual(breakevenValue, entryValue)) {
      pushMarkerLine(breakevenValue, 'Breakeven', 'BE', '#ffe268', [1, 5]);
    }
    // Option position strikes — the bot's stop/target are in option-price
    // units and can't be drawn on the underlying chart. Strikes + breakeven
    // give the "profit zone" view that matters for verticals and singles.
    if (String(positionMarkers?.asset_type || '').startsWith('OPTION')) {
      const optType = String(positionMarkers?.option_type || '').toUpperCase();
      const longStrike = positiveOrNull(positionMarkers.long_strike ?? positionMarkers.option_strike);
      const shortStrike = positiveOrNull(positionMarkers.short_strike);
      const longLabel = optType === 'PUT' ? 'Long Put Strike' : (optType === 'CALL' ? 'Long Call Strike' : 'Long Strike');
      const shortLabel = optType === 'PUT' ? 'Short Put Strike' : (optType === 'CALL' ? 'Short Call Strike' : 'Short Strike');
      pushMarkerLine(longStrike, longLabel, 'LK', '#44e7ff', [6, 4]);
      pushMarkerLine(shortStrike, shortLabel, 'SK', '#ff7a00', [6, 4]);
    }
  }

  const coreRangeValues = [];
  bars.forEach(bar => {
    coreRangeValues.push(Number(bar.high), Number(bar.low));
    seriesDefs.forEach(def => {
      const v = numOrNull(bar[def.key]);
      if (v !== null) coreRangeValues.push(v);
    });
  });
  const lastClose = Number(bars[bars.length - 1].close);
  const coreMaxY = Math.max(...coreRangeValues);
  const coreMinY = Math.min(...coreRangeValues);
  const coreSpan = Math.max(coreMaxY - coreMinY, Math.max(Math.abs(lastClose) * 0.0025, 0.01));
  const overlayVisibilityPad = Math.max(coreSpan * 0.75, Math.abs(lastClose) * 0.0035, 0.05);
  const overlayMinY = coreMinY - overlayVisibilityPad;
  const overlayMaxY = coreMaxY + overlayVisibilityPad;

  function isValueInFocus(value) {
    const v = numOrNull(value);
    return v !== null && Number(v) >= overlayMinY && Number(v) <= overlayMaxY;
  }

  function isZoneInFocus(lowerValue, upperValue) {
    const lower = numOrNull(lowerValue);
    const upper = numOrNull(upperValue);
    if (lower === null || upper === null) return false;
    const lo = Math.min(lower, upper);
    const hi = Math.max(lower, upper);
    return hi >= overlayMinY && lo <= overlayMaxY;
  }

  function isDiagonalLineInFocus(line) {
    if (!line) return false;
    const startValue = lineValueAt(line, visibleAbsStart);
    const endValue = lineValueAt(line, visibleAbsEnd);
    if (numOrNull(startValue) === null || numOrNull(endValue) === null) return false;
    const lo = Math.min(Number(startValue), Number(endValue));
    const hi = Math.max(Number(startValue), Number(endValue));
    return hi >= overlayMinY && lo <= overlayMaxY;
  }

  function firstIndexAtOrAfterAbs(absIndex) {
    const target = numOrNull(absIndex);
    if (target === null) return null;
    for (let idx = 0; idx < bars.length; idx += 1) {
      const abs = numOrNull(bars[idx]?.abs_index);
      if (abs !== null && Number(abs) >= Number(target)) return idx;
    }
    return null;
  }

  function lastIndexAtOrBeforeAbs(absIndex) {
    const target = numOrNull(absIndex);
    if (target === null) return null;
    for (let idx = bars.length - 1; idx >= 0; idx -= 1) {
      const abs = numOrNull(bars[idx]?.abs_index);
      if (abs !== null && Number(abs) <= Number(target)) return idx;
    }
    return null;
  }

  function resolveChannelRenderRange(channelCtx) {
    const upperLine = channelCtx?.upper_line || null;
    const lowerLine = channelCtx?.lower_line || null;
    if (!upperLine || !lowerLine || !bars.length) return null;
    const startCandidates = [numOrNull(upperLine.start_pos), numOrNull(lowerLine.start_pos), visibleAbsStart]
      .filter(value => value !== null)
      .map(value => Number(value));
    const endCandidates = [numOrNull(upperLine.end_pos), numOrNull(lowerLine.end_pos), visibleAbsEnd]
      .filter(value => value !== null)
      .map(value => Number(value));
    if (!startCandidates.length || !endCandidates.length) return null;
    const startAbs = Math.max(...startCandidates);
    let endAbs = Math.min(...endCandidates);
    if (!Number.isFinite(startAbs) || !Number.isFinite(endAbs) || endAbs < startAbs) return null;
    for (let idx = 0; idx < bars.length; idx += 1) {
      const bar = bars[idx];
      const abs = numOrNull(bar?.abs_index);
      if (abs === null) continue;
      const absNum = Number(abs);
      if (absNum < startAbs || absNum > visibleAbsEnd) continue;
      const upperValue = lineValueAt(upperLine, absNum);
      const lowerValue = lineValueAt(lowerLine, absNum);
      const closeValue = numOrNull(bar?.close);
      if (numOrNull(upperValue) === null || numOrNull(lowerValue) === null || closeValue === null) continue;
      const upperBound = Math.max(Number(upperValue), Number(lowerValue));
      const lowerBound = Math.min(Number(upperValue), Number(lowerValue));
      if (Number(closeValue) > upperBound || Number(closeValue) < lowerBound) {
        endAbs = Math.min(endAbs, absNum);
        break;
      }
    }
    const startIdx = firstIndexAtOrAfterAbs(startAbs);
    const endIdx = lastIndexAtOrBeforeAbs(endAbs);
    if (startIdx === null || endIdx === null || endIdx < startIdx) return null;
    return { startAbs, endAbs, startIdx, endIdx };
  }

  const visibleHorizontalLines = horizontalLines.filter(line => isValueInFocus(line?.value));
  const visibleMarkerLines = markerLines.filter(line => isValueInFocus(line?.value));
  const visibleKeyLevelZones = keyLevelZones.filter(zone => isZoneInFocus(zone?.lower, zone?.upper));
  const visibleDiagonalLines = diagonalLines.filter(item => isDiagonalLineInFocus(item?.line));
  const keyLevelFocusPrice = numOrNull(snapshot?.quote?.last ?? bars[bars.length - 1]?.close ?? snapshot?.support_resistance?.price);
  const prioritizedVisibleKeyLevelZones = visibleKeyLevelZones.slice().sort((a, b) => {
    const selectedDelta = Number(!!b?.selected_for_entry) - Number(!!a?.selected_for_entry);
    if (selectedDelta !== 0) return selectedDelta;
    const passingDelta = Number(!!b?.passes_min_level_score) - Number(!!a?.passes_min_level_score);
    if (passingDelta !== 0) return passingDelta;
    const aPrice = numOrNull(a?.price);
    const bPrice = numOrNull(b?.price);
    const aDist = keyLevelFocusPrice === null || aPrice === null ? Number.POSITIVE_INFINITY : Math.abs(Number(aPrice) - Number(keyLevelFocusPrice));
    const bDist = keyLevelFocusPrice === null || bPrice === null ? Number.POSITIVE_INFINITY : Math.abs(Number(bPrice) - Number(keyLevelFocusPrice));
    if (aDist !== bDist) return aDist - bDist;
    return Number(aPrice ?? 0) - Number(bPrice ?? 0);
  });
  const channelUpperLine = technicals.channel?.upper_line || null;
  const channelLowerLine = technicals.channel?.lower_line || null;
  const channelRenderRange = resolveChannelRenderRange(technicals.channel);
  const channelUpperValues = channelUpperLine && channelRenderRange
    ? bars.map((bar, idx) => (idx >= channelRenderRange.startIdx && idx <= channelRenderRange.endIdx)
      ? lineValueAt(channelUpperLine, Number(bar.abs_index))
      : null)
    : [];
  const channelLowerValues = channelLowerLine && channelRenderRange
    ? bars.map((bar, idx) => (idx >= channelRenderRange.startIdx && idx <= channelRenderRange.endIdx)
      ? lineValueAt(channelLowerLine, Number(bar.abs_index))
      : null)
    : [];

  const rangeValues = [...coreRangeValues];
  visibleHorizontalLines.forEach(line => { if (numOrNull(line.value) !== null) rangeValues.push(Number(line.value)); });
  visibleMarkerLines.forEach(line => { if (numOrNull(line.value) !== null) rangeValues.push(Number(line.value)); });
  visibleKeyLevelZones.forEach(zone => {
    const lower = numOrNull(zone?.lower);
    const upper = numOrNull(zone?.upper);
    if (lower !== null) rangeValues.push(Number(lower));
    if (upper !== null) rangeValues.push(Number(upper));
  });
  visibleDiagonalLines.forEach(item => {
    const startValue = lineValueAt(item.line, visibleAbsStart);
    const endValue = lineValueAt(item.line, visibleAbsEnd);
    if (numOrNull(startValue) !== null) rangeValues.push(startValue);
    if (numOrNull(endValue) !== null) rangeValues.push(endValue);
  });
  const maxY = Math.max(...rangeValues);
  const minY = Math.min(...rangeValues);
  const span = Math.max(maxY - minY, 0.01);
  const pad = { left: 62, right: 84, top: 26, bottom: 48 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const slotW = plotW / Math.max(bars.length, 1);
  const rawVolumes = bars
    .map(bar => Number(bar.volume || 0))
    .filter(value => Number.isFinite(value) && value > 0)
    .sort((a, b) => a - b);
  const volumeMax = Math.max(...rawVolumes, 1);
  const volumeRenderMax = Math.max(volumeMax, 1);
  const candleW = Math.max(4, slotW * 0.58);

  function yFor(value) {
    return pad.top + (1 - ((Number(value) - minY) / span)) * plotH;
  }

  function xFor(idx) {
    return pad.left + (idx + 0.5) * slotW;
  }

  function tooltipAnchorForIndex(idx) {
    if (idx === null || idx < 0 || idx >= bars.length) return null;
    const rect = canvas.getBoundingClientRect();
    return {
      clientX: rect.left + xFor(idx),
      clientY: rect.top + clamp(yFor(bars[idx].close), pad.top + 12, height - pad.bottom - 12),
    };
  }
  const tooltipHtmlCache = new Map();
  // hoverFrameRequest / pendingHoverState are hoisted to the top of
  // drawSelectedChart (around line ~1721) so renderEmpty can access
  // them on early-return paths without hitting the TDZ.
  let pinnedIndex = -1;

  function formatTimeAxisLabel(value) {
    if (!value) return '';
    const dt = new Date(value);
    if (!Number.isFinite(dt.getTime())) return '';
    return TIME_AXIS_FMT.format(dt);
  }

  function formatDayAxisLabel(value) {
    if (!value) return '';
    const dt = new Date(value);
    if (!Number.isFinite(dt.getTime())) return '';
    return DAY_AXIS_FMT.format(dt);
  }

  function inferredBarMinutes() {
    if (bars.length < 2) return 1;
    const deltas = [];
    for (let i = 1; i < Math.min(bars.length, 12); i += 1) {
      const prev = Date.parse(bars[i - 1]?.ts);
      const curr = Date.parse(bars[i]?.ts);
      if (!Number.isFinite(prev) || !Number.isFinite(curr)) continue;
      const diffMinutes = Math.round((curr - prev) / 60000);
      if (diffMinutes > 0) deltas.push(diffMinutes);
    }
    if (!deltas.length) return 1;
    deltas.sort((a, b) => a - b);
    return Math.max(1, deltas[Math.floor(deltas.length / 2)] || deltas[0] || 1);
  }

  function timeAxisStepBars() {
    const barMinutes = inferredBarMinutes();
    const totalMinutes = Math.max(barMinutes * Math.max(bars.length - 1, 1), barMinutes);
    const targetMinutes = Math.max(barMinutes, totalMinutes / 6);
    const niceMinuteSteps = [5, 10, 15, 30, 60, 120, 240, 390];
    const stepMinutes = niceMinuteSteps.find(value => value >= targetMinutes)
      || (Math.ceil(targetMinutes / barMinutes) * barMinutes);
    return Math.max(1, Math.round(stepMinutes / barMinutes));
  }

  const timeAxisTickData = (() => {
    const stepBars = timeAxisStepBars();
    const lastIdx = bars.length - 1;
    const anchorOffset = stepBars > 0 ? (lastIdx % stepBars) : 0;
    const tickIndexes = new Set([0, lastIdx]);
    for (let idx = anchorOffset; idx <= lastIdx; idx += stepBars) tickIndexes.add(idx);
    let lastX = Number.NEGATIVE_INFINITY;
    const ticks = [];
    Array.from(tickIndexes).sort((a, b) => a - b).forEach(idx => {
      if (idx < 0 || idx >= bars.length) return;
      const label = formatTimeAxisLabel(bars[idx]?.ts);
      if (!label) return;
      const x = xFor(idx);
      if ((x - lastX) < 38) return;
      ticks.push({ idx, label, x });
      lastX = x;
    });
    return ticks;
  })();

  const dayAxisLabelData = (() => {
    const labels = [];
    const seen = new Set();
    for (let idx = 1; idx < bars.length; idx += 1) {
      const prev = new Date(bars[idx - 1]?.ts || '');
      const curr = new Date(bars[idx]?.ts || '');
      if (!Number.isFinite(prev.getTime()) || !Number.isFinite(curr.getTime())) continue;
      // Day-boundary keys must use the same timezone as the labels —
      // DAY_AXIS_FMT renders ET, so a browser-local prev.getDate() vs
      // curr.getDate() comparison would put the rollover marker at the
      // wrong x for any viewer outside ET. DAY_KEY_FMT yields ISO
      // YYYY-MM-DD via the en-CA locale, perfect for string equality.
      const prevKey = DAY_KEY_FMT.format(prev);
      const currKey = DAY_KEY_FMT.format(curr);
      if (prevKey === currKey || seen.has(currKey)) continue;
      const label = formatDayAxisLabel(bars[idx]?.ts);
      if (!label) continue;
      labels.push({ idx, label, x: (xFor(idx - 1) + xFor(idx)) / 2 });
      seen.add(currKey);
    }
    return labels;
  })();

  function drawShadedBand(upperValues, lowerValues, fillStyle) {
    if (!Array.isArray(upperValues) || !Array.isArray(lowerValues)) return;
    const points = [];
    upperValues.forEach((value, idx) => {
      if (numOrNull(value) === null || numOrNull(lowerValues[idx]) === null) return;
      points.push({ idx, upper: Number(value), lower: Number(lowerValues[idx]) });
    });
    if (points.length < 2) return;
    ctx.save();
    ctx.fillStyle = fillStyle;
    ctx.beginPath();
    ctx.moveTo(xFor(points[0].idx), yFor(points[0].upper));
    for (let i = 1; i < points.length; i += 1) ctx.lineTo(xFor(points[i].idx), yFor(points[i].upper));
    for (let i = points.length - 1; i >= 0; i -= 1) ctx.lineTo(xFor(points[i].idx), yFor(points[i].lower));
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawHorizontalZone(upperValue, lowerValue, fillStyle, strokeStyle = null, lineWidth = 1) {
    if (numOrNull(upperValue) === null || numOrNull(lowerValue) === null) return;
    const clampedUpper = clamp(Math.max(upperValue, lowerValue), minY, maxY);
    const clampedLower = clamp(Math.min(upperValue, lowerValue), minY, maxY);
    const topY = yFor(clampedUpper);
    const bottomY = yFor(clampedLower);
    const zoneHeight = bottomY - topY;
    const zoneWidth = width - pad.left - pad.right;
    ctx.save();
    ctx.fillStyle = fillStyle;
    ctx.fillRect(pad.left, topY, zoneWidth, zoneHeight);
    if (strokeStyle) {
      ctx.strokeStyle = strokeStyle;
      ctx.lineWidth = lineWidth;
      ctx.strokeRect(pad.left + 0.5, topY + 0.5, Math.max(zoneWidth - 1, 0), Math.max(zoneHeight - 1, 0));
    }
    ctx.restore();
  }

  function drawTimedZone(startIdx, endIdx, upperValue, lowerValue, fillStyle) {
    if (numOrNull(upperValue) === null || numOrNull(lowerValue) === null) return;
    const start = Math.max(0, Math.min(bars.length - 1, Number(startIdx)));
    const end = Math.max(start, Math.min(bars.length - 1, Number(endIdx)));
    if (!Number.isFinite(start) || !Number.isFinite(end)) return;
    const clampedUpper = clamp(Math.max(upperValue, lowerValue), minY, maxY);
    const clampedLower = clamp(Math.min(upperValue, lowerValue), minY, maxY);
    const topY = yFor(clampedUpper);
    const bottomY = yFor(clampedLower);
    const leftX = xFor(start) - (slotW / 2);
    const rightX = xFor(end) + (slotW / 2);
    const zoneLeft = clamp(leftX, pad.left, width - pad.right);
    const zoneRight = clamp(rightX, pad.left, width - pad.right);
    if (zoneRight <= zoneLeft) return;
    ctx.save();
    ctx.fillStyle = fillStyle;
    ctx.fillRect(zoneLeft, topY, zoneRight - zoneLeft, bottomY - topY);
    ctx.restore();
  }

  // Order-block rendering helper. Visually distinct from `drawTimedZone`
  // (which is solid filled) — OBs render with a dashed-line border around
  // a very faint fill so the two zone types (FVG vs OB) don't collapse
  // into a single visual at a glance.
  function drawTimedDashedZone(startIdx, endIdx, upperValue, lowerValue, fillStyle, strokeStyle, lineWidth = 1.2, dashPattern = [5, 4]) {
    if (numOrNull(upperValue) === null || numOrNull(lowerValue) === null) return;
    const start = Math.max(0, Math.min(bars.length - 1, Number(startIdx)));
    const end = Math.max(start, Math.min(bars.length - 1, Number(endIdx)));
    if (!Number.isFinite(start) || !Number.isFinite(end)) return;
    const clampedUpper = clamp(Math.max(upperValue, lowerValue), minY, maxY);
    const clampedLower = clamp(Math.min(upperValue, lowerValue), minY, maxY);
    const topY = yFor(clampedUpper);
    const bottomY = yFor(clampedLower);
    const leftX = xFor(start) - (slotW / 2);
    const rightX = xFor(end) + (slotW / 2);
    const zoneLeft = clamp(leftX, pad.left, width - pad.right);
    const zoneRight = clamp(rightX, pad.left, width - pad.right);
    if (zoneRight <= zoneLeft) return;
    ctx.save();
    if (fillStyle) {
      ctx.fillStyle = fillStyle;
      ctx.fillRect(zoneLeft, topY, zoneRight - zoneLeft, bottomY - topY);
    }
    if (strokeStyle) {
      ctx.strokeStyle = strokeStyle;
      ctx.lineWidth = lineWidth;
      ctx.setLineDash(dashPattern);
      ctx.strokeRect(zoneLeft, topY, zoneRight - zoneLeft, bottomY - topY);
      ctx.setLineDash([]);
    }
    ctx.restore();
  }

  function resolveTimedZoneRange(startTs, endTs = null, spanBars = 15, maxSpanBars = null, options = {}) {
    const span = Math.max(1, Number(spanBars) || 15);
    const maxSpan = Math.max(1, Number(maxSpanBars) || span);
    const requireVisibleStart = !!options?.requireVisibleStart;
    const startMillis = Date.parse(startTs || '');
    if (!Number.isFinite(startMillis)) return null;
    const firstBarMillis = Date.parse(bars[0]?.ts || '');
    const lastBarMillis = Date.parse(bars[bars.length - 1]?.ts || '');
    if (requireVisibleStart && Number.isFinite(firstBarMillis) && startMillis < firstBarMillis) return null;
    if (Number.isFinite(lastBarMillis) && startMillis > lastBarMillis) return null;
    let startIdx = -1;
    for (let i = 0; i < bars.length; i += 1) {
      const barTs = Date.parse(bars[i]?.ts || '');
      if (!Number.isFinite(barTs)) continue;
      if (barTs >= startMillis) {
        startIdx = i;
        break;
      }
    }
    if (startIdx < 0) return null;
    const endMillis = Date.parse(endTs || '');
    if (Number.isFinite(endMillis) && endMillis >= startMillis) {
      let endIdx = bars.length - 1;
      for (let i = startIdx; i < bars.length; i += 1) {
        const barTs = Date.parse(bars[i]?.ts || '');
        if (!Number.isFinite(barTs)) continue;
        if (barTs >= endMillis) {
          endIdx = i;
          break;
        }
      }
      endIdx = Math.min(endIdx, startIdx + maxSpan - 1);
      return { startIdx, endIdx: Math.max(startIdx, endIdx) };
    }
    const endIdx = Math.min(bars.length - 1, startIdx + span - 1);
    return { startIdx, endIdx };
  }

  function resolveIndexedZoneRange(anchorAbsIndex, spanBars = 15, maxSpanBars = null) {
    const anchor = Number(anchorAbsIndex);
    if (!Number.isFinite(anchor)) return null;
    if (anchor < visibleAbsStart || anchor > visibleAbsEnd) return null;
    const span = Math.max(1, Number(spanBars) || 15);
    const maxSpan = Math.max(1, Number(maxSpanBars) || span);
    let startIdx = bars.findIndex(bar => Number(bar?.abs_index) >= anchor);
    if (startIdx < 0) return null;
    let endIdx = Math.min(bars.length - 1, startIdx + span - 1);
    const boundedMax = Math.min(bars.length - 1, startIdx + maxSpan - 1);
    endIdx = Math.min(endIdx, boundedMax);
    if (endIdx < startIdx) return null;
    return { startIdx, endIdx };
  }

  let pendingHorizontalLabels = [];

  function drawHorizontalLabel(text, value, color) {
    if (numOrNull(value) === null) return;
    const y = yFor(value);
    const labelText = `${text} ${fmtNum(value, 2)}`;
    ctx.save();
    ctx.font = '11px sans-serif';
    const measured = ctx.measureText(labelText).width;
    ctx.restore();
    const boxX = width - pad.right + 6;
    const boxW = clamp(Math.ceil(measured) + 10, 52, 128);
    const boxH = 20;
    const desiredBoxY = clamp(Math.round(y - (boxH / 2)), pad.top, height - pad.bottom - boxH);
    pendingHorizontalLabels.push({
      labelText,
      color,
      value: Number(value),
      targetY: clamp(Number(y), pad.top + (boxH / 2), height - pad.bottom - (boxH / 2)),
      desiredBoxY,
      boxX,
      boxW,
      boxH,
    });
  }
  function renderHorizontalLabels() {
    if (!pendingHorizontalLabels.length) return;
    const topLimit = pad.top;
    const bottomLimit = height - pad.bottom;
    const minGap = 4;
    const labels = pendingHorizontalLabels
      .slice()
      .sort((a, b) => (a.targetY - b.targetY) || String(a.labelText).localeCompare(String(b.labelText)));

    labels.forEach((label, idx) => {
      const maxBoxY = bottomLimit - label.boxH;
      let boxY = clamp(label.desiredBoxY, topLimit, maxBoxY);
      if (idx > 0) {
        const prev = labels[idx - 1];
        boxY = Math.max(boxY, prev.boxY + prev.boxH + minGap);
      }
      label.boxY = clamp(boxY, topLimit, maxBoxY);
    });

    for (let idx = labels.length - 2; idx >= 0; idx -= 1) {
      const label = labels[idx];
      const next = labels[idx + 1];
      const maxBoxY = next.boxY - label.boxH - minGap;
      label.boxY = clamp(Math.min(label.boxY, maxBoxY), topLimit, bottomLimit - label.boxH);
    }

    ctx.save();
    ctx.font = '11px sans-serif';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = 1;
    labels.forEach(label => {
      const boxCenterY = label.boxY + (label.boxH / 2);
      const connectorStartX = width - pad.right;
      const connectorEndX = label.boxX - 3;
      ctx.strokeStyle = label.color;
      ctx.beginPath();
      ctx.moveTo(connectorStartX, label.targetY);
      ctx.lineTo(connectorEndX, boxCenterY);
      ctx.stroke();
      ctx.fillStyle = label.color;
      ctx.fillRect(label.boxX, label.boxY, label.boxW, label.boxH);
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim() || '#09111f';
      ctx.fillText(label.labelText, label.boxX + 4, boxCenterY + 0.5);
    });
    ctx.restore();
  }

  function zoneLabelText(zone) {
    const rawLabels = Array.isArray(zone?.labels) ? zone.labels : [];
    const labels = rawLabels
      .map(value => String(value || '').trim())
      .filter(Boolean)
      .slice(0, 3);
    const kind = String(zone?.kind || '').toLowerCase();
    const sideBase = kind === 'support' ? 'Support Zone' : 'Resistance Zone';
    const genericLabels = new Set(['s', 's2', 'r', 'r2', 'support', 'resistance', 'support zone', 'resistance zone']);
    const meaningfulLabels = labels.filter(label => !genericLabels.has(label.toLowerCase()));
    const pendingState = String(zone?.pending_state || '').toLowerCase();
    const flipState = String(zone?.flip_state || 'original').toLowerCase();
    const originalKind = String(zone?.original_kind || '').toLowerCase();
    let base = labels.length ? labels.join(' · ') : sideBase;
    if (pendingState === 'pending_break' || pendingState === 'pending_reclaim') {
      base = meaningfulLabels.length
        ? `${sideBase} · ${meaningfulLabels.join(' · ')}`
        : sideBase;
      if (pendingState === 'pending_break') {
        base += ' · Pending Break';
      } else {
        base += ' · Pending Reclaim';
      }
      return base;
    }
    const originalBase = originalKind === 'support'
      ? 'Support Zone'
      : (originalKind === 'resistance' ? 'Resistance Zone' : sideBase);
    if (flipState === 'confirmed_flip' && originalKind && originalKind !== kind) {
      const flipText = originalKind === 'support' ? 'Flipped from Support' : 'Flipped from Resistance';
      base = meaningfulLabels.length
        ? `${sideBase} · ${meaningfulLabels.join(' · ')} · ${flipText}`
        : `${sideBase} · ${flipText}`;
    } else if (originalKind && originalKind === kind) {
      const originText = originalBase === sideBase ? 'Original' : `Original ${originalBase}`;
      base = meaningfulLabels.length
        ? `${sideBase} · ${meaningfulLabels.join(' · ')} · ${originText}`
        : `${sideBase} · ${originText}`;
    }
    return base;
  }

  function fitTextToWidth(text, maxWidth) {
    const source = String(text || '').trim();
    if (!source) return '';
    if (maxWidth <= 0) return '';
    if (ctx.measureText(source).width <= maxWidth) return source;
    const ellipsis = '…';
    if (ctx.measureText(ellipsis).width > maxWidth) return '';
    let lo = 0;
    let hi = source.length;
    let best = ellipsis;
    while (lo <= hi) {
      const mid = Math.floor((lo + hi) / 2);
      const candidate = `${source.slice(0, mid).trimEnd()}${ellipsis}`;
      if (ctx.measureText(candidate).width <= maxWidth) {
        best = candidate;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return best;
  }

  function drawKeyLevelZoneLabel(zone) {
    const lower = numOrNull(zone?.lower);
    const upper = numOrNull(zone?.upper);
    if (lower === null || upper === null) return;
    const labelText = zoneLabelText(zone);
    if (!labelText) return;
    const clampedUpper = clamp(Math.max(upper, lower), minY, maxY);
    const clampedLower = clamp(Math.min(upper, lower), minY, maxY);
    const topY = yFor(clampedUpper);
    const bottomY = yFor(clampedLower);
    const zoneCenterY = (topY + bottomY) / 2;
    const boxH = 18;
    const textPadX = 7;
    ctx.save();
    ctx.font = '600 11px sans-serif';
    const plotWidth = Math.max(0, width - pad.left - pad.right);
    const plotInnerMargin = 10;
    const maxBoxWTarget = clamp(Math.round(plotWidth * 0.34), 88, 192);
    const maxBoxWCanvas = Math.max(44, Math.floor(plotWidth - (plotInnerMargin * 2)));
    const maxBoxW = Math.max(44, Math.min(maxBoxWTarget, maxBoxWCanvas));
    const maxTextW = Math.max(0, maxBoxW - (textPadX * 2));
    const fittedText = fitTextToWidth(labelText, maxTextW);
    if (!fittedText) {
      ctx.restore();
      return;
    }
    const measured = ctx.measureText(fittedText).width;
    const boxW = Math.max(44, Math.min(Math.round(measured + (textPadX * 2)), maxBoxW));
    const isSupport = String(zone?.kind || '').toLowerCase() === 'support';
    const minBoxX = pad.left + plotInnerMargin;
    const maxBoxX = Math.max(minBoxX, width - pad.right - boxW - plotInnerMargin);
    const boxX = isSupport
      ? minBoxX
      : maxBoxX;
    const boxY = clamp(Math.round(zoneCenterY - (boxH / 2)), pad.top + 2, height - pad.bottom - boxH - 2);
    ctx.fillStyle = isSupport ? 'rgba(10, 48, 28, 0.78)' : 'rgba(58, 18, 24, 0.80)';
    ctx.strokeStyle = isSupport ? 'rgba(76, 214, 128, 0.85)' : 'rgba(255, 92, 92, 0.85)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxW, boxH, 7);
    ctx.fill();
    ctx.stroke();
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(boxX + 1, boxY + 1, Math.max(0, boxW - 2), Math.max(0, boxH - 2), 6);
    ctx.clip();
    ctx.fillStyle = isSupport ? '#baf5cd' : '#ffd0d5';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(fittedText, boxX + textPadX, boxY + 12.5);
    ctx.restore();
    ctx.restore();
  }

  function paint(hoverIndex = null) {
    const activeIndex = hoverIndex !== null && hoverIndex !== undefined ? hoverIndex : pinnedIndex;
    pendingHorizontalLabels = [];
    ctx.clearRect(0, 0, width, height);
    // Read the theme-aware --tint-rgb at paint time. Canvas strokeStyle
    // can't parse `var(...)` directly the way CSS can, so we resolve it
    // once per paint and template it into rgba() strings below (used by
    // the time-axis tick marks further down). Falls back to white tint
    // if the variable isn't set (e.g. when the page loads before any
    // theme stylesheet attaches).
    //
    // 2026-05-19: removed the canvas-drawn plot-area grid (5 horizontals
    // + 6 verticals at fixed proportions). It collided with the CSS
    // `.chart-wrap::before` radial-masked grid, and its outermost lines
    // doubled as a fake inner border that read like a duplicate panel
    // frame against the new gradient chart background. CSS handles the
    // grid + outer border now; canvas only draws data, axes, and
    // overlays.
    const tintRgb = (getComputedStyle(document.documentElement).getPropertyValue('--tint-rgb') || '255, 255, 255').trim();

    if (activeIndex !== null && activeIndex >= 0 && activeIndex < bars.length) {
      const x = xFor(activeIndex);
      ctx.fillStyle = 'rgba(121,212,255,0.08)';
      ctx.fillRect(x - slotW / 2, pad.top, slotW, plotH);
    }

    function drawVolumeBars() {
      if (!show('show_volume', true)) return;
      const volumeBottomInset = 8;
      const volumeTopInset = 4;
      const volumeBaseY = height - pad.bottom - volumeBottomInset;
      const maxVolumeHeight = Math.max((plotH * 0.19) - volumeTopInset, 10);
      const sqrtVolumeMax = Math.sqrt(Math.max(volumeRenderMax, 1));
      bars.forEach((bar, idx) => {
        const x = xFor(idx);
        const rising = Number(bar.close) >= Number(bar.open);
        // `Number(bar.volume || 0)` would coerce the string "NaN"
        // (truthy) to NaN, which then propagates through Math.sqrt and
        // skips the bar silently. Use parseFinite (defined near the top)
        // to convert non-numeric / null / "NaN" to a safe 0.
        const rawVolume = parseFinite(bar.volume);
        const volumeValue = Math.max(rawVolume === null ? 0 : rawVolume, 0);
        const scaledVolume = volumeValue > 0 ? (Math.sqrt(volumeValue) / sqrtVolumeMax) : 0;
        const volH = volumeValue > 0 ? Math.max(1.5, scaledVolume * maxVolumeHeight) : 0;
        ctx.fillStyle = rising ? 'rgba(108,227,162,0.34)' : 'rgba(255,107,130,0.36)';
        if (volH > 0) ctx.fillRect(x - candleW / 2, volumeBaseY - volH, candleW, volH);
      });
    }

    function drawPriceAxisLabels() {
      ctx.save();
      ctx.fillStyle = '#92a0bf';
      ctx.font = '11px sans-serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      for (let i = 0; i <= 4; i += 1) {
        const value = maxY - (span / 4) * i;
        const y = pad.top + (plotH / 4) * i;
        const labelY = clamp(y, pad.top + 1, height - pad.bottom - 1);
        ctx.fillText(fmtNum(value, 2), pad.left - 8, labelY);
      }
      ctx.restore();
    }

    function drawTimeAxisLabels() {
      ctx.save();
      ctx.fillStyle = '#92a0bf';
      ctx.font = '11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      const tickY = height - pad.bottom;
      const labelY = tickY + 8;
      const occupiedRanges = [];
      timeAxisTickData.forEach(tick => {
        ctx.strokeStyle = `rgba(${tintRgb}, 0.12)`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(tick.x, tickY);
        ctx.lineTo(tick.x, tickY + 5);
        ctx.stroke();
        ctx.fillText(tick.label, tick.x, labelY);
        const width = ctx.measureText(tick.label).width;
        occupiedRanges.push([tick.x - (width / 2) - 6, tick.x + (width / 2) + 6]);
      });
      ctx.fillStyle = '#7483a6';
      ctx.font = '600 10px sans-serif';
      dayAxisLabelData.forEach(dayTick => {
        const width = ctx.measureText(dayTick.label).width;
        const range = [dayTick.x - (width / 2) - 6, dayTick.x + (width / 2) + 6];
        const overlaps = occupiedRanges.some(([start, end]) => !(range[1] < start || range[0] > end));
        if (overlaps) return;
        ctx.fillText(dayTick.label, dayTick.x, labelY);
        occupiedRanges.push(range);
      });
      ctx.restore();
    }

    if (show('show_bollinger_bands', false)) {
      drawShadedBand(bbUpperValues, bbLowerValues, 'rgba(184, 109, 255, 0.08)');
    }

    // Channel shaded band — LTF-only for the same reason the diagonal
    // channel lines are LTF-only (see comment above diagonalLines):
    // line.slope/intercept were fit against LTF abs_index, so projecting
    // against HTF bars yields detached/floating render values.
    if (isLtfChart && show('show_channel', false) && technicals.channel && technicals.channel.valid) {
      if (channelUpperLine && channelLowerLine) {
        drawShadedBand(channelUpperValues, channelLowerValues, 'rgba(74, 155, 255, 0.07)');
      }
    }

    if (show('show_htf_fair_value_gaps', false)) {
      htfFairValueGaps.forEach(gap => {
        const lower = numOrNull(gap?.lower);
        const upper = numOrNull(gap?.upper);
        if (lower === null || upper === null) return;
        const fill = String(gap?.direction || '').toLowerCase() === 'bullish'
          ? 'rgba(76, 214, 128, 0.14)'
          : 'rgba(255, 92, 92, 0.14)';
        const timedRange = resolveTimedZoneRange(gap?.first_seen, null, 8, 8);
        if (!timedRange) return;
        drawTimedZone(timedRange.startIdx, timedRange.endIdx, upper, lower, fill);
      });
    }

    if (show('show_ltf_fair_value_gaps', false)) {
      ltfFairValueGaps.forEach(gap => {
        const lower = numOrNull(gap?.lower);
        const upper = numOrNull(gap?.upper);
        if (lower === null || upper === null) return;
        const fill = String(gap?.direction || '').toLowerCase() === 'bullish'
          ? 'rgba(76, 214, 128, 0.18)'
          : 'rgba(255, 92, 92, 0.18)';
        const timedRange = Number.isFinite(Number(gap?.anchor_abs_index))
          ? resolveIndexedZoneRange(gap?.anchor_abs_index, 15, 15)
          : resolveTimedZoneRange(gap?.first_seen, null, 15, 15, { requireVisibleStart: true });
        if (!timedRange) return;
        drawTimedZone(timedRange.startIdx, timedRange.endIdx, upper, lower, fill);
      });
    }

    // Order blocks render after FVGs so any overlapping zones show the OB
    // dashed-border on top, making both visible. Bullish=green / bearish=red
    // matches the FVG color semantics; the dashed stroke + low fill opacity
    // is what differentiates OBs from FVGs visually.
    if (show('show_htf_order_blocks', false)) {
      htfOrderBlocks.forEach(ob => {
        const lower = numOrNull(ob?.lower);
        const upper = numOrNull(ob?.upper);
        if (lower === null || upper === null) return;
        const isBullish = String(ob?.direction || '').toLowerCase() === 'bullish';
        const fill = isBullish ? 'rgba(76, 214, 128, 0.06)' : 'rgba(255, 92, 92, 0.06)';
        const stroke = isBullish ? 'rgba(76, 214, 128, 0.85)' : 'rgba(255, 92, 92, 0.85)';
        const timedRange = resolveTimedZoneRange(ob?.first_seen, null, 8, 8);
        if (!timedRange) return;
        drawTimedDashedZone(timedRange.startIdx, timedRange.endIdx, upper, lower, fill, stroke, 1.4, [6, 4]);
      });
    }

    if (show('show_ltf_order_blocks', false)) {
      ltfOrderBlocks.forEach(ob => {
        const lower = numOrNull(ob?.lower);
        const upper = numOrNull(ob?.upper);
        if (lower === null || upper === null) return;
        const isBullish = String(ob?.direction || '').toLowerCase() === 'bullish';
        const fill = isBullish ? 'rgba(76, 214, 128, 0.07)' : 'rgba(255, 92, 92, 0.07)';
        const stroke = isBullish ? 'rgba(76, 214, 128, 0.90)' : 'rgba(255, 92, 92, 0.90)';
        const timedRange = Number.isFinite(Number(ob?.anchor_abs_index))
          ? resolveIndexedZoneRange(ob?.anchor_abs_index, 15, 15)
          : resolveTimedZoneRange(ob?.first_seen, null, 15, 15, { requireVisibleStart: true });
        if (!timedRange) return;
        drawTimedDashedZone(timedRange.startIdx, timedRange.endIdx, upper, lower, fill, stroke, 1.2, [5, 4]);
      });
    }

    // RSI / OBV divergence trendlines. Each `line` is a DivergenceMatch
    // payload: {pivot_a:{ts,price,...}, pivot_b:{ts,price,...}, kind, direction,
    // indicator, age_bars}. Draw a line connecting pivot_a -> pivot_b on the
    // price chart, color-coded by direction (green=bullish/red=bearish), with
    // dashed stroke for hidden divergence vs solid for regular. Small label
    // at midpoint identifies indicator + kind.
    function drawDivergenceLine(line, opts = {}) {
      if (!line || !line.pivot_a || !line.pivot_b) return;
      const tsA = line.pivot_a.ts;
      const tsB = line.pivot_b.ts;
      const priceA = numOrNull(line.pivot_a.price);
      const priceB = numOrNull(line.pivot_b.price);
      if (priceA === null || priceB === null) return;
      const millisA = Date.parse(tsA || '');
      const millisB = Date.parse(tsB || '');
      if (!Number.isFinite(millisA) || !Number.isFinite(millisB)) return;
      // Find bar index for each pivot by walking bars[] and matching ts.
      // Both pivots must be within the visible window for the line to render
      // (otherwise the line goes off-screen at one end).
      let idxA = -1;
      let idxB = -1;
      for (let i = 0; i < bars.length; i += 1) {
        const barTs = Date.parse(bars[i]?.ts || '');
        if (!Number.isFinite(barTs)) continue;
        if (idxA < 0 && barTs >= millisA) idxA = i;
        if (idxB < 0 && barTs >= millisB) { idxB = i; break; }
      }
      if (idxA < 0 || idxB < 0) return;
      const direction = String(line?.direction || '').toLowerCase();
      const kind = String(line?.kind || '').toLowerCase();
      const indicator = String(line?.indicator || '').toLowerCase();
      const isBullish = direction === 'bullish';
      const isHidden = kind === 'hidden';
      const baseAlpha = indicator === 'obv' ? 0.65 : 0.95;
      const stroke = isBullish
        ? `rgba(76, 214, 128, ${baseAlpha})`
        : `rgba(255, 92, 92, ${baseAlpha})`;
      const xA = xFor(idxA);
      const yA = yFor(clamp(priceA, minY, maxY));
      const xB = xFor(idxB);
      const yB = yFor(clamp(priceB, minY, maxY));
      ctx.save();
      ctx.strokeStyle = stroke;
      ctx.lineWidth = opts.lineWidth || (indicator === 'obv' ? 1.0 : 1.5);
      if (isHidden) ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.moveTo(xA, yA);
      ctx.lineTo(xB, yB);
      ctx.stroke();
      if (isHidden) ctx.setLineDash([]);
      // Label at midpoint, if there's room
      const midX = (xA + xB) / 2;
      const midY = (yA + yB) / 2;
      const labelText = indicator === 'rsi'
        ? (isHidden ? 'RSI hid' : 'RSI ÷')
        : (isHidden ? 'OBV hid' : 'OBV ÷');
      ctx.fillStyle = stroke;
      ctx.font = '10px ui-sans-serif, system-ui';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      // Tiny offset above the line for bullish (lower-pivot lines), below for bearish
      const labelOffset = isBullish ? -8 : 8;
      ctx.fillText(labelText, midX, midY + labelOffset);
      ctx.restore();
    }

    if (show('show_rsi_divergence', true) || show('show_obv_divergence', false)) {
      const showRsi = show('show_rsi_divergence', true);
      const showObv = show('show_obv_divergence', false);
      const lines = isHtfChart ? htfDivergenceLines : ltfDivergenceLines;
      lines.forEach(line => {
        const ind = String(line?.indicator || '').toLowerCase();
        if (ind === 'rsi' && !showRsi) return;
        if (ind === 'obv' && !showObv) return;
        drawDivergenceLine(line);
      });
    }

    if (show('show_key_level_zones', true)) {
      visibleKeyLevelZones.forEach(zone => {
        const lower = numOrNull(zone?.lower);
        const upper = numOrNull(zone?.upper);
        if (lower === null || upper === null) return;
        const isSupport = String(zone?.kind || '').toLowerCase() === 'support';
        const selected = !!zone?.selected_for_entry;
        const passes = !!zone?.passes_min_level_score;
        const fill = isSupport
          ? (selected ? 'rgba(76, 214, 128, 0.26)' : (passes ? 'rgba(76, 214, 128, 0.16)' : 'rgba(76, 214, 128, 0.10)'))
          : (selected ? 'rgba(255, 92, 92, 0.26)' : (passes ? 'rgba(255, 92, 92, 0.16)' : 'rgba(255, 92, 92, 0.10)'));
        const stroke = isSupport
          ? (selected ? 'rgba(150, 255, 191, 0.92)' : (passes ? 'rgba(76, 214, 128, 0.62)' : 'rgba(76, 214, 128, 0.34)'))
          : (selected ? 'rgba(255, 186, 193, 0.94)' : (passes ? 'rgba(255, 92, 92, 0.66)' : 'rgba(255, 92, 92, 0.34)'));
        drawHorizontalZone(upper, lower, fill, stroke, selected ? 1.5 : 1.0);
      });
      if (show('show_key_level_zone_labels', true)) {
        prioritizedVisibleKeyLevelZones.forEach(zone => drawKeyLevelZoneLabel(zone));
      }
    }

    drawVolumeBars();

    bars.forEach((bar, idx) => {
      const x = xFor(idx);
      const openY = yFor(bar.open);
      const closeY = yFor(bar.close);
      const highY = yFor(bar.high);
      const lowY = yFor(bar.low);
      const rising = Number(bar.close) >= Number(bar.open);
      const isHover = idx === activeIndex;
      ctx.strokeStyle = rising ? '#6ce3a2' : '#ff6b82';
      ctx.lineWidth = isHover ? 2.2 : 1.4;
      ctx.beginPath();
      ctx.moveTo(x, highY);
      ctx.lineTo(x, lowY);
      ctx.stroke();
      ctx.fillStyle = rising ? 'rgba(108,227,162,0.82)' : 'rgba(255,107,130,0.84)';
      const bodyTop = Math.min(openY, closeY);
      const bodyH = Math.max(2, Math.abs(closeY - openY));
      ctx.fillRect(x - candleW / 2, bodyTop, candleW, bodyH);
      if (isHover) {
        ctx.strokeStyle = '#cfe8ff';
        ctx.lineWidth = 1.1;
        ctx.strokeRect(x - candleW / 2 - 1, bodyTop - 1, candleW + 2, bodyH + 2);
      }
    });

    const legendChips = [`<span class="legend-chip"><span class="swatch" style="background:${appState.mainPanelExpanded ? '#79d4ff' : '#6ce3a2'};"></span>${bars.length} bars</span>`];
    // Compact chart has no on-canvas timeframe toggle (the expanded chart's
    // chart-timeframe-toggle covers that), so surface the active timeframe
    // as a legend chip. expandedChartTimeframeLabel resolves to either the
    // LTF label (e.g. "5m") or HTF label (e.g. "60m") depending on the
    // current chart mode.
    if (!isExpandedView) {
      const compactTfLabel = String(expandedChartTimeframeLabel(appState.data, chartTimeframeMode) || '').trim();
      if (compactTfLabel) {
        legendChips.unshift(`<span class="legend-chip"><span class="swatch" style="background:#9c8cff;"></span>${escapeHtml(compactTfLabel)} ${isHtfChart ? 'HTF' : 'LTF'}</span>`);
      }
    }
    const lastBar = bars[bars.length - 1];

    seriesDefs.forEach(def => {
      const vals = seriesValueMap.get(def.key) || [];
      if (!vals.some(v => v !== null)) return;
      ctx.strokeStyle = def.color;
      ctx.lineWidth = def.width || 2;
      ctx.beginPath();
      let started = false;
      vals.forEach((value, idx) => {
        if (value === null) return;
        const x = xFor(idx);
        const y = yFor(value);
        if (!started) {
          ctx.moveTo(x, y);
          started = true;
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();
      if (activeIndex !== null && activeIndex >= 0 && vals[activeIndex] !== null) {
        const hx = xFor(activeIndex);
        const hy = yFor(vals[activeIndex]);
        ctx.fillStyle = def.color;
        ctx.beginPath();
        ctx.arc(hx, hy, 3.4, 0, Math.PI * 2);
        ctx.fill();
      }
      legendChips.push(`<span class="legend-chip"><span class="swatch" style="background:${def.color};"></span>${def.label} ${fmtNum(vals[vals.length - 1], 2)}</span>`);
    });

    visibleHorizontalLines.forEach((line, idx) => {
      if (numOrNull(line.value) === null) return;
      const y = yFor(line.value);
      ctx.setLineDash(line.dash || [6, 6]);
      ctx.strokeStyle = line.color;
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(width - pad.right, y);
      ctx.stroke();
      ctx.setLineDash([]);
      if (line.labelMode === 'inline' && line.shortLabel) {
        // Draw label inline on the line, anchored to the left
        ctx.save();
        ctx.font = '10px sans-serif';
        const text = line.shortLabel;
        const tw = ctx.measureText(text).width;
        const lx = pad.left + 6;
        const ly = Math.round(y) - 5;
        ctx.fillStyle = line.color;
        ctx.globalAlpha = 0.85;
        ctx.fillRect(lx - 3, ly - 9, tw + 6, 13);
        ctx.globalAlpha = 1.0;
        ctx.fillStyle = '#000000';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, lx, ly - 2.5);
        ctx.restore();
      } else if (line.shortLabel) {
        drawHorizontalLabel(line.shortLabel, line.value, line.color);
      }
    });

    visibleMarkerLines.forEach(line => {
      if (numOrNull(line.value) === null) return;
      const y = yFor(line.value);
      ctx.setLineDash(line.dash || [3, 4]);
      ctx.strokeStyle = line.color;
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(width - pad.right, y);
      ctx.stroke();
      ctx.setLineDash([]);
      drawHorizontalLabel(line.shortLabel || line.label, line.value, line.color);
    });

    visibleDiagonalLines.forEach(item => {
      const line = item.line;
      if (!line) return;
      const startAbs = item.useChannelRange && channelRenderRange
        ? channelRenderRange.startAbs
        : Math.max(visibleAbsStart, numOrNull(line.start_pos) ?? visibleAbsStart);
      const endAbs = item.useChannelRange && channelRenderRange
        ? channelRenderRange.endAbs
        : Math.max(startAbs, Math.min(visibleAbsEnd, numOrNull(line.end_pos) ?? visibleAbsEnd));
      const startIdx = item.useChannelRange && channelRenderRange
        ? channelRenderRange.startIdx
        : clamp(Math.round(startAbs - visibleAbsStart), 0, bars.length - 1);
      const endIdx = item.useChannelRange && channelRenderRange
        ? channelRenderRange.endIdx
        : clamp(Math.round(endAbs - visibleAbsStart), 0, bars.length - 1);
      const startVal = lineValueAt(line, Number(bars[startIdx].abs_index));
      const endVal = lineValueAt(line, Number(bars[endIdx].abs_index));
      if (numOrNull(startVal) === null || numOrNull(endVal) === null) return;
      ctx.setLineDash(item.dash || [7, 5]);
      ctx.strokeStyle = item.color;
      ctx.lineWidth = item.width || 1.4;
      ctx.beginPath();
      ctx.moveTo(xFor(startIdx), yFor(startVal));
      ctx.lineTo(xFor(endIdx), yFor(endVal));
      ctx.stroke();
      ctx.setLineDash([]);
      // On-chart label at the right end of the diagonal line
      const diagLabelText = item.label || '';
      if (diagLabelText) {
        ctx.save();
        ctx.font = '10px sans-serif';
        const diagTw = ctx.measureText(diagLabelText).width;
        const diagX = xFor(endIdx) - diagTw - 8;
        const diagY = Math.round(yFor(endVal)) - 5;
        ctx.fillStyle = item.color;
        ctx.globalAlpha = 0.85;
        ctx.fillRect(diagX - 3, diagY - 9, diagTw + 6, 13);
        ctx.globalAlpha = 1.0;
        ctx.fillStyle = '#000000';
        ctx.textBaseline = 'middle';
        ctx.fillText(diagLabelText, diagX, diagY - 2.5);
        ctx.restore();
      }
      legendChips.push(`<span class="legend-chip"><span class="swatch" style="background:${item.color};"></span>${item.label}</span>`);
    });
    // Key-level zones stay on-chart only; omit their extra legend chips to reduce clutter.

    if (show('show_trade_markers', true)) {
      const eventMarkers = [];
      const entryIdx = nearestIndexForTs(positionMarkers.entry_time, bars);
      if (entryIdx !== null) {
        eventMarkers.push({ idx: entryIdx, kind: 'entry', side: safe(positionMarkers.side).toUpperCase(), color: '#8cf4ff' });
      }
      recentTrades.slice(0, 6).forEach(trade => {
        const entryTradeIdx = nearestIndexForTs(trade.entry_time, bars);
        const exitTradeIdx = nearestIndexForTs(trade.exit_time, bars);
        if (entryTradeIdx !== null) eventMarkers.push({ idx: entryTradeIdx, kind: 'entry', side: safe(trade.side).toUpperCase() });
        if (exitTradeIdx !== null) eventMarkers.push({ idx: exitTradeIdx, kind: 'exit', side: safe(trade.side).toUpperCase(), y: yFor(bars[exitTradeIdx].close) });
      });
      const drawDiamondMarker = (marker) => {
        const bar = bars[marker.idx] || null;
        if (!bar) return;
        const x = xFor(marker.idx);
        const isShort = String(marker.side || '').toUpperCase() === 'SHORT';
        const isExit = marker.kind === 'exit';
        const anchorY = isExit ? numOrNull(marker.y) ?? yFor(bar.close) : (isShort ? yFor(bar.high) : yFor(bar.low));
        const markerOffset = 12;
        const stemLength = 6;
        const markerY = isExit ? anchorY : (isShort ? anchorY - markerOffset : anchorY + markerOffset);
        const stemStartY = isShort ? anchorY - 1 : anchorY + 1;
        const stemEndY = isShort ? markerY + stemLength : markerY - stemLength;
        const outline = isExit ? '#ff365f' : (isShort ? '#ff6f86' : '#56d98a');
        const fill = isExit ? 'rgba(255, 54, 95, 0.18)' : (isShort ? 'rgba(255, 111, 134, 0.18)' : 'rgba(86, 217, 138, 0.18)');
        const half = 5;
        ctx.save();
        ctx.lineWidth = 1.1;
        ctx.strokeStyle = outline;
        ctx.shadowColor = outline;
        ctx.shadowBlur = 7;
        if (!isExit) {
          ctx.beginPath();
          ctx.moveTo(x, stemStartY);
          ctx.lineTo(x, stemEndY);
          ctx.stroke();
        }
        ctx.beginPath();
        ctx.moveTo(x, markerY - half);
        ctx.lineTo(x + half, markerY);
        ctx.lineTo(x, markerY + half);
        ctx.lineTo(x - half, markerY);
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = outline;
        ctx.stroke();
        ctx.restore();
      };
      eventMarkers.forEach(marker => {
        drawDiamondMarker(marker);
      });
    }

    if (activeIndex !== null && activeIndex >= 0 && activeIndex < bars.length) {
      // Use activeIndex (resolved from hoverIndex || pinnedIndex above)
      // for both the bar reference and the x-coordinate. Today
      // pinnedIndex is declared at line ~2337 but never reassigned, so
      // activeIndex always equals hoverIndex in practice — but if a
      // future change wires bar-pinning, paint(null) with a pinned bar
      // would dereference bars[null]/xFor(null) and crash here. Keep
      // the references symmetrically on activeIndex so that landmine
      // is closed before pinning lands.
      const hoverBar = bars[activeIndex];
      const hoverX = xFor(activeIndex);
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = 'rgba(207,232,255,0.28)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(hoverX, pad.top);
      ctx.lineTo(hoverX, height - pad.bottom);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#cfe8ff';
      ctx.font = '11px sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(fmtNum(hoverBar.close, 2), 8, clamp(yFor(hoverBar.close), pad.top + 6, height - pad.bottom - 6));
    }

    drawPriceAxisLabels();
    drawTimeAxisLabels();
    renderHorizontalLabels();
    legend.innerHTML = legendChips.join('');
  }

  function updateTooltip(idx, clientX = null, clientY = null) {
    if (!tooltip || idx === null || idx < 0 || idx >= bars.length) {
      hideTooltip();
      return;
    }
    const bar = bars[idx];
    const delta = numOrNull(bar.close) !== null && numOrNull(bar.open) !== null ? Number(bar.close) - Number(bar.open) : null;
    const deltaPct = delta !== null && Number(bar.open) ? (delta / Number(bar.open)) * 100 : null;
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
    // Structure-section values are ALL global snapshot state — the bars
    // payload doesn't carry per-bar trend_state, so the previous
    // ``bar.trend_state ??`` fallback was unreachable. Drop it; the section
    // title is already labeled "(current)" so the global semantic is honest.
    const structureState = sr.state || 'neutral';
    const structureTrend = sr.trend ?? sr.trend_state ?? 'neutral';
    const structureBias = sr.structure_bias || 'neutral';
    const structureEvent = sr.structure_event || '—';
    const sections = [];
    if (show('tooltip_show_returns', true)) {
      sections.push(`
        <div class="tt-section">
          <div class="tt-section-title">Returns</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>Ret1</span><strong>${fmtPctFromRatio(bar.ret1, 2)}</strong></div>
            <div class="tt-kv"><span>Ret5</span><strong>${fmtPctFromRatio(bar.ret5, 2)}</strong></div>
            <div class="tt-kv"><span>Ret15</span><strong>${fmtPctFromRatio(bar.ret15, 2)}</strong></div>
            <div class="tt-kv"><span>ATR14</span><strong>${fmtNum(bar.atr14, 2)}</strong></div>
          </div>
        </div>
      `);
    }
    if (show('tooltip_show_support_resistance', true)) {
      // S/R levels are global snapshot state, not per-bar history. The
      // ``(current)`` suffix in the section title makes that explicit so
      // users hovering older bars don't read these as that bar's levels.
      const supportValue = sr.nearest_support;
      const resistanceValue = sr.nearest_resistance;
      const nextSupportValue = levels.next_support;
      const nextResistanceValue = levels.next_resistance;
      sections.push(`
        <div class="tt-section">
          <div class="tt-section-title">S/R Levels (current)</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>Support</span><strong>${fmtNum(supportValue, 2)}</strong></div>
            <div class="tt-kv"><span>Resistance</span><strong>${fmtNum(resistanceValue, 2)}</strong></div>
            <div class="tt-kv"><span>Next Support</span><strong>${fmtNum(nextSupportValue, 2)}</strong></div>
            <div class="tt-kv"><span>Next Resistance</span><strong>${fmtNum(nextResistanceValue, 2)}</strong></div>
          </div>
        </div>
      `);
    }
    if (show('tooltip_show_structure', true)) {
      // Structure section: ``state``, ``bias``, ``event`` are global
      // snapshot values (not bar-indexed). Only ``trend`` is per-bar
      // when bar.trend_state is populated (currently rare on chart bars
      // payload), otherwise it falls back to the global snapshot. The
      // ``(current)`` suffix is explicit about the global nature.
      sections.push(`
        <div class="tt-section">
          <div class="tt-section-title">Structure (current)</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>State</span><strong>${escapeHtml(prettyLabel(structureState || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>Trend</span><strong>${escapeHtml(prettyLabel(structureTrend || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>Bias</span><strong>${escapeHtml(prettyLabel(structureBias || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>Event</span><strong>${escapeHtml(structureEvent || '—')}</strong></div>
          </div>
        </div>
      `);
    }
    if (show('tooltip_show_volatility', true)) {
      // Per-bar honest display: no silent fallback to ``technicals.*``
      // (the latest-snapshot global value). When ``bar.adx`` etc. is
      // null (e.g. early-session warmup bars, HTF bars without the
      // column, or a stale frame), the tooltip shows ``—`` instead of
      // misleadingly reporting the current state as the hovered bar's
      // state. Bars payload now carries adx/plus_di/minus_di/dmi_bias
      // per-bar (see dashboard_bars_from_frame), so honest values
      // appear whenever the data exists.
      sections.push(`
        <div class="tt-section">
          <div class="tt-section-title">Volatility / Trend</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>ATR %</span><strong>${fmtPctFromRatio(bar.atr_pct, 2)}</strong></div>
            <div class="tt-kv"><span>ADX</span><strong>${fmtNum(bar.adx, 2)}</strong></div>
            <div class="tt-kv"><span>+DI / -DI</span><strong>${fmtNum(bar.plus_di, 1)} / ${fmtNum(bar.minus_di, 1)}</strong></div>
            <div class="tt-kv"><span>DMI Bias</span><strong>${escapeHtml(prettyLabel(bar.dmi_bias || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>BB Width</span><strong>${fmtPctFromRatio(bar.bb_width_pct, 2)}</strong></div>
            <div class="tt-kv"><span>%B / Z</span><strong>${fmtNum(bar.bb_percent_b, 2)} / ${fmtNum(bar.bb_zscore, 2)}</strong></div>
          </div>
        </div>
      `);
    }
    if (show('tooltip_show_orderflow', true)) {
      // Per-bar honest display: same no-silent-fallback rule as the
      // Volatility / Trend section above. Bars payload now carries obv,
      // obv_ema, and the derived obv_bias per-bar. ``anchored_vwap_bias``
      // is computed in tech_ctx (single-snapshot) and is intentionally
      // omitted from the bars payload — the tooltip just doesn't show
      // it anymore rather than silently reporting the global value as
      // bar-specific.
      sections.push(`
        <div class="tt-section">
          <div class="tt-section-title">Orderflow / Context</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>OBV Bias</span><strong>${escapeHtml(prettyLabel(bar.obv_bias || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>OBV</span><strong>${fmtCompact(bar.obv)}</strong></div>
            <div class="tt-kv"><span>OBV EMA</span><strong>${fmtCompact(bar.obv_ema)}</strong></div>
          </div>
        </div>
      `);
    }
    if (show('tooltip_show_patterns', true)) {
      // Patterns are split into two sections:
      //   1. "Candle Patterns (this bar)" — per-bar from bar.candles_bullish/
      //      bearish (populated by detect_per_bar_candle_patterns in
      //      dashboard_cache.py, completion-bar only, with tier cascade).
      //      Multi-bar patterns appear ONLY on their completion bar.
      //   2. "Chart Patterns (latest)" — global from patterns.chart_*
      //      (single detection across the latest 30 bars in the frame).
      //      Same payload regardless of which bar is hovered.
      // The candleFallback / chartFallback heuristics are indicator-derived
      // body-flow / EMA-stack reads (not formal patterns), included
      // alongside their per-bar / global counterparts to preserve the
      // previous information density without re-mixing the categories.
      const barCandlesBullish = Array.isArray(bar.candles_bullish) ? bar.candles_bullish : [];
      const barCandlesBearish = Array.isArray(bar.candles_bearish) ? bar.candles_bearish : [];
      const candleFallback = deriveCandleFallback(idx);
      const chartFallback = deriveChartFallback(idx);

      const candleBullishTags = uniqPatternList([...barCandlesBullish, ...candleFallback.bullish]);
      const candleBearishTags = uniqPatternList([...barCandlesBearish, ...candleFallback.bearish]);
      // Per-bar candle regime: derive from the bar's actual matches when
      // present, otherwise fall back to the body-flow heuristic. Skips
      // the global ``patterns.candle_regime_hint`` which is latest-only.
      let candleRegime;
      let candleBias;
      if (barCandlesBullish.length && barCandlesBearish.length) {
        candleRegime = 'mixed';
        candleBias = 0;
      } else if (barCandlesBullish.length) {
        candleRegime = 'bullish_reversal';
        candleBias = Math.min(1.25, 0.7 + 0.1 * (barCandlesBullish.length - 1));
      } else if (barCandlesBearish.length) {
        candleRegime = 'bearish_reversal';
        candleBias = -Math.min(1.25, 0.7 + 0.1 * (barCandlesBearish.length - 1));
      } else {
        candleRegime = candleFallback.regime;
        candleBias = candleFallback.score;
      }

      const explicitChartBullish = uniqPatternList([
        ...(patterns.chart_bullish_continuation || []),
        ...(patterns.chart_bullish_reversal || []),
        ...(patterns.chart_bullish || []),
      ]);
      const explicitChartBearish = uniqPatternList([
        ...(patterns.chart_bearish_continuation || []),
        ...(patterns.chart_bearish_reversal || []),
        ...(patterns.chart_bearish || []),
      ]);
      const rawChartRegime = String((patterns.chart_regime_hint) || 'neutral').toLowerCase();
      const rawChartBias = numOrNull(patterns.chart_bias_score);
      const useExplicitChart = explicitChartBullish.length > 0 || explicitChartBearish.length > 0 || rawChartRegime !== 'neutral' || (rawChartBias !== null && Math.abs(rawChartBias) > 0.0001);
      const chartRegime = useExplicitChart ? ((patterns.chart_regime_hint) || 'neutral') : chartFallback.regime;
      const chartBias = useExplicitChart ? patterns.chart_bias_score : chartFallback.score;
      const chartBullishTags = uniqPatternList([...explicitChartBullish, ...chartFallback.bullish]);
      const chartBearishTags = uniqPatternList([...explicitChartBearish, ...chartFallback.bearish]);

      sections.push(`
        <div class="tt-section">
          <div class="tt-section-title">Candle Patterns (this bar)</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>Candle Regime</span><strong>${escapeHtml(prettyLabel(candleRegime || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>Candle Bias</span><strong>${fmtNum(candleBias, 2)}</strong></div>
          </div>
          <div class="tt-section-title" style="margin-top:8px;">Bullish</div>
          <div class="tt-tags">${tagHtml(candleBullishTags, 'good')}</div>
          <div class="tt-section-title" style="margin-top:8px;">Bearish</div>
          <div class="tt-tags">${tagHtml(candleBearishTags, 'bad')}</div>
        </div>
        <div class="tt-section">
          <div class="tt-section-title">Chart Patterns (latest)</div>
          <div class="tt-grid">
            <div class="tt-kv"><span>Chart Regime</span><strong>${escapeHtml(prettyLabel(chartRegime || 'neutral'))}</strong></div>
            <div class="tt-kv"><span>Chart Bias</span><strong>${fmtNum(chartBias, 2)}</strong></div>
          </div>
          <div class="tt-section-title" style="margin-top:8px;">Bullish</div>
          <div class="tt-tags">${tagHtml(chartBullishTags, 'good')}</div>
          <div class="tt-section-title" style="margin-top:8px;">Bearish</div>
          <div class="tt-tags">${tagHtml(chartBearishTags, 'bad')}</div>
        </div>
      `);
    }
    const tooltipCacheKey = `${idx}|${bar.ts}`;
    let tooltipHtml = tooltipHtmlCache.get(tooltipCacheKey);
    if (!tooltipHtml) {
      tooltipHtml = `
      <div class="tt-head">
        <span>${escapeHtml(snapshot.symbol)} · ${escapeHtml(fmtChartTs(bar.ts))}</span>
        <span class="${delta === null ? '' : (delta >= 0 ? 'good' : 'bad')}">${delta === null ? '—' : fmtPct(deltaPct, 2)}</span>
      </div>
      <div class="tt-grid">
        <div class="tt-kv"><span>Open</span><strong>${fmtNum(bar.open, 2)}</strong></div>
        <div class="tt-kv"><span>High</span><strong>${fmtNum(bar.high, 2)}</strong></div>
        <div class="tt-kv"><span>Low</span><strong>${fmtNum(bar.low, 2)}</strong></div>
        <div class="tt-kv"><span>Close</span><strong>${fmtNum(bar.close, 2)}</strong></div>
        <div class="tt-kv"><span>Change</span><strong>${delta === null ? '—' : fmtNum(delta, 2)}</strong></div>
        <div class="tt-kv"><span>Volume</span><strong>${fmtInteger(bar.volume)}</strong></div>
        <div class="tt-kv"><span>EMA${chartEmaFastSpan}</span><strong>${fmtNum(bar.ema9, 2)}</strong></div>
        <div class="tt-kv"><span>EMA${chartEmaSlowSpan}</span><strong>${fmtNum(bar.ema20, 2)}</strong></div>
        <div class="tt-kv"><span>VWAP</span><strong>${fmtNum(bar.vwap, 2)}</strong></div>
        <div class="tt-kv"><span>Range</span><strong>${numOrNull(bar.high) !== null && numOrNull(bar.low) !== null ? fmtNum(Number(bar.high) - Number(bar.low), 2) : '—'}</strong></div>
      </div>
      ${sections.join('')}
    `;
      tooltipHtmlCache.set(tooltipCacheKey, tooltipHtml);
    }
    tooltip.innerHTML = tooltipHtml;
    tooltip.classList.add('active');
    const anchor = tooltipAnchorForIndex(idx);
    const resolvedClientX = Number.isFinite(clientX) ? clientX : (anchor?.clientX ?? lastTooltipLeft ?? 0);
    const resolvedClientY = Number.isFinite(clientY) ? clientY : (anchor?.clientY ?? lastTooltipTop ?? 0);
    const margin = 14;
    const cursorGapX = 28;
    const cursorGapY = 22;
    const ttRect = tooltip.getBoundingClientRect();
    const canvasRect = canvas.getBoundingClientRect();
    const leftAxisSafeRight = canvasRect.left + pad.left + 12;
    let left = resolvedClientX - ttRect.width - cursorGapX;
    let top = resolvedClientY + cursorGapY;
    if (left < leftAxisSafeRight) left = resolvedClientX + cursorGapX;
    if (left < margin) left = resolvedClientX + cursorGapX;
    if (left + ttRect.width > viewportWidth - margin) left = viewportWidth - margin - ttRect.width;
    if (left < margin) left = margin;
    if (top + ttRect.height > viewportHeight - margin) top = resolvedClientY - ttRect.height - cursorGapY;
    if (top < margin) top = margin;
    left = Math.round(left);
    top = Math.round(top);
    lastTooltipLeft = left;
    lastTooltipTop = top;
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  }

  paint(null);

  canvas.onclick = null;
  // Unified pointer-driven hover: single handler covers mouse, pen, and
  // touch. `pointermove` fires on mouse motion AND on dragging-finger;
  // for taps we also wire `pointerdown` so the tooltip appears
  // immediately on first contact (instead of only after movement).
  // `pointerleave` mirrors the legacy mouseleave semantics. Touch events
  // are gated to events with pointerType === 'touch' so we don't double-
  // process the synthetic mouse events that follow a tap on some browsers.
  const handlePointerActivity = (clientX, clientY) => {
    pendingHoverState = { clientX, clientY };
    if (hoverFrameRequest) return;
    hoverFrameRequest = window.requestAnimationFrame(() => {
      hoverFrameRequest = 0;
      const latest = pendingHoverState;
      pendingHoverState = null;
      if (!latest) return;
      const rect = canvas.getBoundingClientRect();
      const x = latest.clientX - rect.left;
      if (x < pad.left || x > width - pad.right) {
        paint(null);
        hideTooltip();
        return;
      }
      const idx = clamp(Math.floor((x - pad.left) / slotW), 0, bars.length - 1);
      paint(idx);
      updateTooltip(idx, latest.clientX, latest.clientY);
    });
  };
  const clearPointerActivity = () => {
    if (hoverFrameRequest) {
      window.cancelAnimationFrame(hoverFrameRequest);
      hoverFrameRequest = 0;
    }
    pendingHoverState = null;
    paint(null);
    hideTooltip();
  };
  canvas.onpointermove = (event) => handlePointerActivity(event.clientX, event.clientY);
  canvas.onpointerdown = (event) => {
    // Only react to touch/pen down — mouse hover is already covered by
    // pointermove. This avoids a redundant repaint on every mouse click.
    if (event.pointerType === 'mouse') return;
    handlePointerActivity(event.clientX, event.clientY);
  };
  canvas.onpointerleave = (event) => {
    // For touch/pen, lifting the finger fires pointerleave/pointercancel
    // immediately — clearing the tooltip would create a flash on every
    // tap. Keep the tooltip visible until the next gesture (which will
    // either redraw it via pointerdown or move it via pointermove).
    // Mouse cursors leaving the canvas should still clear immediately.
    if (event && event.pointerType && event.pointerType !== 'mouse') return;
    clearPointerActivity();
  };
  canvas.onpointercancel = (event) => {
    // pointercancel fires for touch interrupted by scroll, pinch, or
    // multi-touch. Apply the same touch-keeps-tooltip rule so a stray
    // gesture interruption doesn't blank a deliberately tapped bar.
    if (event && event.pointerType && event.pointerType !== 'mouse') return;
    clearPointerActivity();
  };
}

function buildEvents(data, snapshot) {
  const events = [];
  if (snapshot) {
    const sr = snapshot.support_resistance || {};
    if (snapshot.position) {
      events.push({
        tone: pnlTone(snapshot.position.unrealized_pnl),
        title: `${snapshot.symbol} ${safe(snapshot.position.side)} position`,
        time: safe(snapshot.position.entry_time).replace('T', ' ').slice(0, 16),
        text: `${safe(snapshot.position.side)} · qty ${safe(snapshot.position.qty)} · entry ${fmtNum(snapshot.position.entry_price, 2)} · last ${fmtNum(snapshot.position.last_price, 2)} · unrealized ${fmtMoney(snapshot.position.unrealized_pnl)}.`
      });
    }
    if (snapshot.candidate) {
      events.push({
        tone: (() => { const bias = String(snapshot.candidate.directional_bias || '').toUpperCase(); return bias === 'SHORT' ? 'tone-bad' : (bias === 'LONG' ? 'tone-good' : 'tone-neutral'); })(),
        title: `${snapshot.symbol} candidate rank #${safe(snapshot.candidate.rank)}`,
        time: safe(data?.last_update).replace('T', ' ').slice(0, 16),
        text: `Activity ${fmtNum(snapshot.candidate.activity_score, 2)} · day ${fmtPct(snapshot.quote?.percent_change ?? snapshot.candidate.change ?? snapshot.candidate.change_from_open)} · volume ${fmtCompact(snapshot.quote?.total_volume ?? snapshot.candidate.volume)}.`
      });
    }
    if (sr.structure_event && sr.structure_event !== '—') {
      events.push({
        tone: eventTone(sr.structure_event),
        title: `${snapshot.symbol} market structure`,
        time: safe(data?.last_update).replace('T', ' ').slice(0, 16),
        text: `${safe(sr.structure_event)} · ${safe(sr.structure_bias)} bias · ${safe(sr.state)} state · regime ${safe(sr.regime_hint)}.`
      });
    }
    const nearestSupport = positiveOrNull(sr.nearest_support);
    const nearestResistance = positiveOrNull(sr.nearest_resistance);
    const supportDistancePct = numOrNull(snapshot?.chart?.levels?.support_distance_pct ?? sr.support_distance_pct);
    const resistanceDistancePct = numOrNull(snapshot?.chart?.levels?.resistance_distance_pct ?? sr.resistance_distance_pct);
    if (nearestSupport !== null || nearestResistance !== null) {
      events.push({
        tone: 'tone-accent',
        title: `${snapshot.symbol} support / resistance`,
        time: safe(data?.last_update).replace('T', ' ').slice(0, 16),
        text: `Support ${fmtNum(nearestSupport, 2)} (${fmtPctFromRatio(nearestSupport === null ? null : supportDistancePct)}) · resistance ${fmtNum(nearestResistance, 2)} (${fmtPctFromRatio(nearestResistance === null ? null : resistanceDistancePct)}).`
      });
    }
  }
  const trades = (data?.performance?.recent_trades || []).filter(item => !snapshot || String(item.symbol || '').toUpperCase() === snapshot.symbol).slice(0, 4);
  trades.forEach(trade => {
    events.push({
      tone: pnlTone(trade.realized_pnl),
      title: `${trade.symbol} ${trade.strategy}`,
      time: safe(trade.exit_time).replace('T', ' ').slice(0, 16),
      text: `${fmtSide(trade)} · closed ${safe(trade.qty)} @ ${fmtNum(trade.exit_price, 2)} · realized ${fmtMoney(trade.realized_pnl)} · return ${fmtPct(trade.return_pct)} · ${safe(trade.reason)}.`
    });
  });
  events.push({
    tone: String(data?.status || '').toLowerCase() === 'running' ? 'tone-good' : 'tone-bad',
    title: `Bot ${safe(data?.status)}`,
    time: safe(data?.last_update).replace('T', ' ').slice(0, 16),
    text: `${safe(data?.message)} · streaming ${data?.streaming_active ? 'on' : 'off'} · screening ${data?.screening_active ? 'on' : 'off'}.`
  });
  return events;
}

function renderEventsAndDock() {
  const data = appState.data;
  const snapshot = activeSnapshotMap(data).get(appState.selectedSymbol) || null;
  const events = buildEvents(data, snapshot);
  document.getElementById('dock-meta').textContent = snapshot ? `${snapshot.symbol} focus · ${events.length} generated events` : 'Global bot view';
  document.getElementById('events-list').innerHTML = events.length ? events.map(event => `
    <div class="event-card">
      <div class="event-top">
        <div class="event-title ${event.tone === 'tone-good' ? 'good' : (event.tone === 'tone-bad' ? 'bad' : '')}">${escapeHtml(event.title)}</div>
        <div class="event-time">${escapeHtml(event.time)}</div>
      </div>
      <div class="event-text">${escapeHtml(event.text)}</div>
    </div>
  `).join('') : `<div class="empty-state">No event context available yet.</div>`;

  const exchangeMap = data?.symbol_exchanges || {};
  const trades = data?.performance?.recent_trades || [];
  document.getElementById('trades-table-body').innerHTML = trades.length ? trades.map(trade => `
    <tr>
      <td>${escapeHtml(safe(trade.exit_time).replace('T',' ').slice(0,16))}</td>
      <td>${tradeSymbolCell(trade, exchangeMap)}</td>
      <td>${escapeHtml(safe(trade.regime) || safe(trade.strategy) || '—')}</td>
      <td>${escapeHtml(fmtSide(trade))}</td>
      <td>${escapeHtml(safe(trade.qty))}</td>
      <td>${fmtNum(trade.entry_price, 2)}</td>
      <td>${fmtNum(trade.exit_price, 2)}</td>
      <td><span class="${pnlClass(trade.realized_pnl)}">${fmtMoney(trade.realized_pnl)}</span></td>
      <td>${fmtPct(trade.return_pct)}</td>
      <td>${fmtNum(trade.hold_minutes, 1)}</td>
      <td>${escapeHtml(safe(trade.reason))}</td>
    </tr>
  `).join('') : `<tr><td colspan="11"><div class="empty-state" style="min-height:96px;">No closed trades yet.</div></td></tr>`;

  const perf = data?.performance || {};
  const diag = [
    ['Strategy', safe(data?.strategy)],
    ['Bot Uptime', fmtUptime(data?.started_at)],
    ['Started At', safe(data?.started_at).replace('T', ' ').slice(0, 19)],
    ['Message', safe(data?.message)],
    ['Trading Block', safe(data?.trading_blocked_reason)],
    ['Management Active', data?.management_active ? 'Yes' : 'No'],
    ['Screening Active', data?.screening_active ? 'Yes' : 'No'],
    ['Streaming Active', data?.streaming_active ? 'Yes' : 'No'],
    ['History Symbols', safe(data?.data?.history_symbols)],
    ['Stream Symbols', safe((data?.data?.stream_symbols || []).join(', '))],
    ['Quote Symbols', safe((data?.data?.quote_symbols || []).length)],
    ['Schwabdev Calls / Min (5m)', fmtNum(data?.api_usage?.calls_per_minute_5m, 1)],
    ['Schwabdev Calls Total', safe(data?.api_usage?.total_calls)],
    ['Last Schwabdev Call', safe(data?.api_usage?.last_call_at).replace('T', ' ').slice(0, 19)],
    ['Closed Trades', safe(perf.closed_trades)],
    ['Wins / Losses', `${safe(perf.wins)} / ${safe(perf.losses)}`],
    ['Average Trade', fmtMoney(perf.average_trade)],
    ['Max Drawdown', fmtMoney(perf.max_drawdown)],
  ];
  document.getElementById('diagnostics-grid').innerHTML = diag.map(([k, v]) => `
    <div class="detail-card">
      <div class="tiny-label">${escapeHtml(k)}</div>
      <div class="value-big" style="font-size:22px; margin-top:8px;">${escapeHtml(v)}</div>
    </div>
  `).join('');
  syncDockViewport();
  wireDockWheel();
}

function syncDockViewport() {
  const dock = document.querySelector('.dock');
  const body = dock?.querySelector('.dock-body');
  const head = dock?.querySelector('.panel-head');
  if (!dock || !body || !head) return;
  const innerHeight = dock.clientHeight;
  const headHeight = head.offsetHeight + 12;
  const bodyHeight = Math.max(0, innerHeight - 32 - headHeight);
  body.style.height = `${bodyHeight}px`;
  body.style.maxHeight = `${bodyHeight}px`;
}

function initDockAutoResize() {
  const dock = document.querySelector('.dock');
  if (!dock) return;
  if (dock.dataset.hoverSyncBound !== '1') {
    dock.dataset.hoverSyncBound = '1';
    const resync = () => window.requestAnimationFrame(() => syncDockViewport());
    dock.addEventListener('mouseenter', resync);
    dock.addEventListener('mouseleave', resync);
  }
  if (dock.dataset.resizeObserverBound !== '1' && 'ResizeObserver' in window) {
    dock.dataset.resizeObserverBound = '1';
    const observer = new ResizeObserver(() => syncDockViewport());
    observer.observe(dock);
  }
}

function syncWatchlistViewport() {
  const panel = document.querySelector('.watchlist-panel');
  const rail = panel?.closest('.rail');
  if (!panel || !rail || window.innerWidth <= 1400) {
    if (panel) {
      panel.style.removeProperty('--watchlist-base-h');
      panel.style.removeProperty('--watchlist-hover-h');
    }
    return;
  }
  if (appState.mainPanelExpanded && getComputedStyle(document.documentElement).getPropertyValue('--watchlist-locked-h').trim()) {
    return;
  }
  const railStyles = getComputedStyle(rail);
  const gap = parseFloat(railStyles.rowGap || railStyles.gap || '0') || 0;
  const baseHeight = Math.max(0, (rail.clientHeight - gap) / 2);
  const rect = panel.getBoundingClientRect();
  const hoverHeight = appState.mainPanelExpanded
    ? baseHeight
    : Math.max(baseHeight, window.innerHeight - rect.top - 14);
  panel.style.setProperty('--watchlist-base-h', `${Math.round(baseHeight)}px`);
  panel.style.setProperty('--watchlist-hover-h', `${Math.round(hoverHeight)}px`);
}

function initWatchlistAutoResize() {
  const panel = document.querySelector('.watchlist-panel');
  const rail = panel?.closest('.rail');
  if (!panel || !rail) return;
  if (panel.dataset.hoverSyncBound !== '1') {
    panel.dataset.hoverSyncBound = '1';
    let collapseUnlockTimer = null;
    const root = document.documentElement;
    const clearCollapseState = () => {
      window.clearTimeout(collapseUnlockTimer);
      collapseUnlockTimer = null;
      root.classList.remove('watchlist-collapsing');
    };
    panel.addEventListener('mouseenter', () => {
      clearCollapseState();
      window.requestAnimationFrame(syncWatchlistViewport);
    });
    panel.addEventListener('mouseleave', () => {
      root.classList.add('watchlist-collapsing');
      window.requestAnimationFrame(syncWatchlistViewport);
      window.clearTimeout(collapseUnlockTimer);
      collapseUnlockTimer = window.setTimeout(() => {
        root.classList.remove('watchlist-collapsing');
        collapseUnlockTimer = null;
      }, 220);
    });
  }
  if (panel.dataset.resizeObserverBound !== '1' && 'ResizeObserver' in window) {
    panel.dataset.resizeObserverBound = '1';
    const observer = new ResizeObserver(() => syncWatchlistViewport());
    observer.observe(rail);
  }
  syncWatchlistViewport();
}

function syncCandidatesViewport() {
  const panel = document.querySelector('.candidates-panel');
  const rail = panel?.closest('.rail');
  if (!panel || !rail || window.innerWidth <= 1400) {
    if (panel) {
      panel.style.removeProperty('--candidates-base-h');
      panel.style.removeProperty('--candidates-hover-h');
    }
    return;
  }
  if (appState.mainPanelExpanded && getComputedStyle(document.documentElement).getPropertyValue('--candidates-locked-h').trim()) {
    return;
  }
  const railStyles = getComputedStyle(rail);
  const gap = parseFloat(railStyles.rowGap || railStyles.gap || '0') || 0;
  const baseHeight = Math.max(0, (rail.clientHeight - gap) / 2);
  const railRect = rail.getBoundingClientRect();
  const rect = panel.getBoundingClientRect();
  const hoverHeight = appState.mainPanelExpanded
    ? baseHeight
    : Math.max(baseHeight, rect.bottom - railRect.top);
  panel.style.setProperty('--candidates-base-h', `${Math.round(baseHeight)}px`);
  panel.style.setProperty('--candidates-hover-h', `${Math.round(hoverHeight)}px`);
}

function initCandidatesAutoResize() {
  const panel = document.querySelector('.candidates-panel');
  const rail = panel?.closest('.rail');
  if (!panel || !rail) return;
  if (panel.dataset.hoverSyncBound !== '1') {
    panel.dataset.hoverSyncBound = '1';
    panel.addEventListener('mouseenter', () => window.requestAnimationFrame(syncCandidatesViewport));
    panel.addEventListener('mouseleave', () => window.requestAnimationFrame(syncCandidatesViewport));
  }
  if (panel.dataset.resizeObserverBound !== '1' && 'ResizeObserver' in window) {
    panel.dataset.resizeObserverBound = '1';
    const observer = new ResizeObserver(() => syncCandidatesViewport());
    observer.observe(rail);
    observer.observe(panel);
  }
  syncCandidatesViewport();
}

function syncPositionsViewport() {
  const panel = document.querySelector('.positions-panel');
  const slot = document.querySelector('.positions-slot');
  const rail = slot?.closest('.right-rail');
  if (!panel || !slot || !rail || window.innerWidth <= 1400) {
    if (slot) {
      slot.style.removeProperty('--positions-base-h');
      slot.style.removeProperty('--positions-hover-h');
    }
    return;
  }
  if (appState.mainPanelExpanded && getComputedStyle(document.documentElement).getPropertyValue('--positions-locked-h').trim()) {
    return;
  }
  const railRect = rail.getBoundingClientRect();
  const railStyles = getComputedStyle(rail);
  const gap = parseFloat(railStyles.rowGap || railStyles.gap || '0') || 0;
  const prev = slot.previousElementSibling;
  const prevRect = prev ? prev.getBoundingClientRect() : railRect;
  const baseTop = prev === null ? railRect.top : Math.min(railRect.bottom, prevRect.bottom + gap);
  const baseHeight = Math.max(0, Math.min(railRect.height, railRect.bottom - baseTop));
  const hoverHeight = appState.mainPanelExpanded ? baseHeight : Math.max(baseHeight, railRect.height);
  slot.style.setProperty('--positions-base-h', `${Math.round(baseHeight)}px`);
  slot.style.setProperty('--positions-hover-h', `${Math.round(hoverHeight)}px`);
}

function initPositionsAutoResize() {
  const panel = document.querySelector('.positions-panel');
  const slot = document.querySelector('.positions-slot');
  const rail = slot?.closest('.right-rail');
  if (!panel || !slot || !rail) return;
  if (slot.dataset.hoverSyncBound !== '1') {
    slot.dataset.hoverSyncBound = '1';
    slot.addEventListener('mouseenter', () => window.requestAnimationFrame(syncPositionsViewport));
    slot.addEventListener('mouseleave', () => window.requestAnimationFrame(syncPositionsViewport));
  }
  if (slot.dataset.resizeObserverBound !== '1' && 'ResizeObserver' in window) {
    slot.dataset.resizeObserverBound = '1';
    const observer = new ResizeObserver(() => syncPositionsViewport());
    observer.observe(rail);
    Array.from(rail.children).forEach((child) => observer.observe(child));
    observer.observe(panel);
  }
  syncPositionsViewport();
}

function renderDisconnected(message) {
  appState.data = null;
  appState.snapshotMap = new Map();
  resetExpandedChartCache();
  resetCompactChartCache();
  document.getElementById('app-root').classList.add('status-disconnected');
  renderTopbar({ status: 'disconnected', dry_run: true, message: message || 'Dashboard disconnected' });
  renderKpiAndGauges(null);
  document.getElementById('watchlist-list').innerHTML = `<div class="empty-state">${escapeHtml(message || 'Dashboard disconnected.')}</div>`;
  document.getElementById('candidate-grid').innerHTML = `<div class="empty-state">No candidate data.</div>`;
  document.getElementById('positions-cards').innerHTML = `<div class="empty-state">No position data.</div>`;
  document.getElementById('events-list').innerHTML = `<div class="empty-state">${escapeHtml(message || 'Dashboard disconnected.')}</div>`;
  document.getElementById('trades-table-body').innerHTML = `<tr><td colspan="11"><div class="empty-state">No trade data.</div></td></tr>`;
  document.getElementById('diagnostics-grid').innerHTML = `<div class="empty-state">No diagnostics available.</div>`;
  renderSelectedSymbol();
  drawSelectedChart(null);
}

function renderApp() {
  const data = appState.data;
  if (!data) return;
  appState.snapshotMap = buildSnapshotMap(data);
  appState.expandedChart.maxBars = expandedChartMaxBars(data);
  appState.compactChart.maxBars = compactChartMaxBars(data);
  document.getElementById('app-root').classList.remove('status-disconnected');
  syncSelectedSymbol(data);
  syncExpandedChartFromBaseSnapshot(data);
  syncCompactChartFromBaseSnapshot(data);
  renderTopbar(data);
  renderWatchlist();
  renderCandidates();
  renderKpiAndGauges(data);
  renderPositions(data);
  renderSelectedSymbol();
  if (!appState.mainPanelExpanded) ensureCompactChartBars(false).catch(err => console.warn('Compact chart fetch failed', err));
  renderEventsAndDock();
  syncWatchlistViewport();
  syncCandidatesViewport();
  syncPositionsViewport();
}

async function refresh() {
  if (appState.refreshInFlight) return;
  appState.refreshInFlight = true;
  // Without a timeout a stuck backend blocks refresh forever — the
  // refreshInFlight guard becomes a permanent UI freeze with no visual
  // indication. Abort at 5× refresh so a missed tick surfaces as a
  // disconnect state that the user can see.
  const abortCtl = new AbortController();
  const timeoutMs = Math.max(4000, REFRESH_MS * 5);
  const timeoutId = setTimeout(() => abortCtl.abort(), timeoutMs);
  try {
    const res = await fetch('/api/state?ts=' + Date.now(), { cache: 'no-store', signal: abortCtl.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    appState.data = data;
    try {
      renderApp();
      pruneExpandedChartCache();
      if (appState.mainPanelExpanded && (!Array.isArray(appState.expandedChart.bars) || !appState.expandedChart.bars.length)) {
        scheduleExpandedChartRefresh(false);
      }
    } catch (renderErr) {
      console.error('Dashboard render failed', renderErr);
      renderDisconnected('Dashboard render failed: ' + renderErr);
    }
  } catch (err) {
    const isAbort = err && (err.name === 'AbortError' || String(err).includes('abort'));
    renderDisconnected(isAbort ? `Dashboard fetch timed out after ${Math.round(timeoutMs / 1000)}s` : ('Dashboard connection failed: ' + err));
  } finally {
    clearTimeout(timeoutId);
    appState.refreshInFlight = false;
  }
}

document.querySelectorAll('.toggle-btn[data-filter]').forEach(btn =>
  btn.addEventListener('click', () => setFilter(btn.dataset.filter))
);
document.querySelectorAll('.tab-btn[data-tab]').forEach(btn =>
  btn.addEventListener('click', () => setDockTab(btn.dataset.tab))
);
document.querySelectorAll('.chart-timeframe-btn[data-timeframe-mode]').forEach(btn =>
  btn.addEventListener('click', () => setExpandedChartTimeframeMode(btn.dataset.timeframeMode))
);
wireDockWheel();
initDockAutoResize();
initWatchlistAutoResize();
initCandidatesAutoResize();
initPositionsAutoResize();
bindMainPanelHover();
let viewportResizeUnlockTimer = null;
let positionsHoverResumeHandlerBound = false;
let lastPointerClientX = null;
let lastPointerClientY = null;
function recordPointerPosition(event) {
  if (!event) return;
  if (Number.isFinite(event.clientX)) lastPointerClientX = event.clientX;
  if (Number.isFinite(event.clientY)) lastPointerClientY = event.clientY;
}
function pointerIsOutsidePositionsSlot(event = null) {
  const slot = document.querySelector('.positions-slot');
  if (!slot) return true;
  const clientX = Number.isFinite(event?.clientX) ? event.clientX : lastPointerClientX;
  const clientY = Number.isFinite(event?.clientY) ? event.clientY : lastPointerClientY;
  if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return true;
  const rect = slot.getBoundingClientRect();
  return clientX < rect.left || clientX > rect.right || clientY < rect.top || clientY > rect.bottom;
}
function resumePositionsHoverAfterPointerMove(event) {
  const root = document.documentElement;
  if (!root.classList.contains('positions-hover-paused')) {
    window.removeEventListener('pointermove', resumePositionsHoverAfterPointerMove, true);
    positionsHoverResumeHandlerBound = false;
    return;
  }
  if (!event || !pointerIsOutsidePositionsSlot(event)) {
    return;
  }
  root.classList.remove('positions-hover-paused');
  syncPositionsViewport();
  window.removeEventListener('pointermove', resumePositionsHoverAfterPointerMove, true);
  positionsHoverResumeHandlerBound = false;
}
function handleViewportResize() {
  const root = document.documentElement;
  root.classList.add('viewport-resizing');
  root.classList.add('positions-hover-paused');
  if (appState.mainPanelExpanded) {
    unlockExpandedSidePanelHeights();
  }
  syncDockViewport();
  syncWatchlistViewport();
  syncCandidatesViewport();
  syncPositionsViewport();
  if (appState.mainPanelExpanded) {
    window.requestAnimationFrame(() => {
      if (appState.mainPanelExpanded) lockExpandedSidePanelHeights();
    });
  }
  if (appState.data) renderSelectedSymbol();
  window.clearTimeout(viewportResizeUnlockTimer);
  viewportResizeUnlockTimer = window.setTimeout(() => {
    root.classList.remove('viewport-resizing');
    if (appState.mainPanelExpanded) {
      unlockExpandedSidePanelHeights();
      syncWatchlistViewport();
      syncCandidatesViewport();
      syncPositionsViewport();
      window.requestAnimationFrame(() => {
        if (appState.mainPanelExpanded) lockExpandedSidePanelHeights();
      });
    } else {
      syncPositionsViewport();
    }
    if (pointerIsOutsidePositionsSlot()) {
      root.classList.remove('positions-hover-paused');
      syncPositionsViewport();
    } else if (!positionsHoverResumeHandlerBound) {
      window.addEventListener('pointermove', resumePositionsHoverAfterPointerMove, true);
      positionsHoverResumeHandlerBound = true;
    }
  }, 180);
}
window.addEventListener('pointermove', recordPointerPosition, true);
window.addEventListener('resize', handleViewportResize);
setDockTab('events');
syncDockViewport();
syncWatchlistViewport();
syncCandidatesViewport();
syncPositionsViewport();
renderChartTimeframeToggle();
refresh();
setInterval(refresh, REFRESH_MS);
// Force an immediate refresh when the user returns to a hidden tab.
// Browsers throttle setInterval to ~1Hz when hidden; without this,
// users see stale data for up to one full REFRESH_MS cycle on focus.
// `refreshInFlight` already guards against doubling.
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) refresh();
});
